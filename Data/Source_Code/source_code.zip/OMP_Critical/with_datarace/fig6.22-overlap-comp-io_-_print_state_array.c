int DefValN = 6;
int DefValM = 10;
char file_read[] = "fig6.22-file-io.bin";
enum STATUS {UNDEFINED, READ_IN_PROGRESS, READ_FINISHED, PROCESSING_IN_PROGRESS, PROCESSING_FINISHED} *execution_state;
void read_input(int i);
void signal_read(int i);
void wait_read(int i);
void process_data(int i);
void signal_processed(int i);
void wait_processed(int i);
void write_output(int i);
void do_compute(int i, int j);
void get_cmd_line_options(int, char **);
void init_memory();
void init_data();
void generate_input_file();
void compute_reference_results();
void print_header();
int check_results();
void print_state_array(int, char *, int);
double *a;
double *b;
double **c;
double **ref;
FILE *fp_write;
int verbose;
int N;
int M;
void print_state_array(int TID, char *name, int i)
{
  static int first = 1;
  {
    if (first)
    {
      first = 0;
      #pragma omp flush
      printf("Thread ID  Function             Execution Status Array\n");
      printf("                    Value of i:");
      for (int j = 0; j < N; j++)
        printf("%3d", j);

      printf("\n\n");
    }

    printf("%6d     %-20s", TID, name);
    if (i >= 0)
    {
      for (int j = 0; j < i; j++)
      {
        #pragma omp flush
        printf(" %2d", execution_state[j]);
      }

      #pragma omp flush
      printf(" *%1d", execution_state[i]);
    }

    for (int j = i + 1; j < N; j++)
    {
      #pragma omp flush
      printf(" %2d", execution_state[j]);
    }

    printf("\n");
  }
  return;
}

