int main(int argc, char **argv)
{
  double end;
  double start = omp_get_wtime();
  int i;
  int QuesCount = 0;
  double sum = 0.0;
  double Average = 0.0;
  FILE *fp;
  FILE *fpconf;
  char *rawline = 0;
  char *fileLine = 0;
  char removeChar[] = {'\"', '<', '>'};
  size_t len = 0;
  ssize_t read;
  char *filename;
  #pragma omp parallel reduction (+:sum) reduction(+:QuesCount)
  {
    #pragma omp master
    {
      fpconf = fopen(argv[1], "r");
      if (fpconf == 0)
      {
        printf("Can't open input file : Data File !\n");
        exit(1);
      }

      while ((read = getline(&rawline, &len, fpconf)) != (-1))
      {
        char *line = (char *) malloc(len);
        strcpy(line, rawline);
        #pragma omp task shared (sum, QuesCount) firstprivate(line)
        {
          double AnsCount = 0;
          int PostTypeVal;
          char *token;
          if ((token = strstr(line, "PostTypeId")) != 0)
          {
            if ((token[12] == '1') && (token[13] == '"'))
            {
              if ((token = strstr(line, "AnswerCount")) != 0)
              {
                token[0] = token[13];
                i = 13;
                while (token[i] != '"')
                  i++;

                token[i] = '\0';
                sscanf(token, "%lf", &AnsCount);
                {
                  QuesCount++;
                  sum = sum + AnsCount;
                }
              }

            }

          }

        }
        free(line);
      }

      #pragma omp taskwait
      Average = sum / QuesCount;
      printf("Value of sum= %lf and average= %f, omp num threads is %d  \n", sum, Average, omp_get_num_threads());
      fclose(fpconf);
      end = omp_get_wtime();
      printf(" Total execution time = %lf \n", end - start);
    }
  }
  exit(0);
}

