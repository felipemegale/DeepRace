int main(int argc, char *argv[])
{
  double a[8];
  double b[8];
  double localsum;
  double sum = 0.0;
  int i;
  int tid;
  int nthreads;
  #pragma omp parallel shared(a,b,sum) private(i, localsum)
  {
    tid = omp_get_thread_num();
    #pragma omp master
    {
      nthreads = omp_get_num_threads();
      printf("Number of threads = %d\n", nthreads);
    }
    #pragma omp for
    for (i = 0; i < 8; i++)
      a[i] = (b[i] = (double) i);

    localsum = 0.0;
    #pragma omp for
    for (i = 0; i < 8; i++)
      localsum = localsum + (a[i] * b[i]);

    sum = sum + localsum;
  }
  printf("   Sum = %2.1f\n", sum);
  exit(0);
}

