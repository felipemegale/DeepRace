void SRbarrier2(int *count, int *sense, int *local_sense, double *local_arrival_contention_time)
{
  double t_start;
  double t_end;
  *local_sense = !(*local_sense);
  t_start = omp_get_wtime();
  {
    t_end = omp_get_wtime();
    *count = (*count) - 1;
    if ((*count) == 0)
    {
      *count = omp_get_num_threads();
      *sense = *local_sense;
    }

  }
  *local_arrival_contention_time = ((*local_arrival_contention_time) + t_end) - t_start;
  while ((*sense) != (*local_sense))
  {
  }

  ;
}

