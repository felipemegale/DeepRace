void func3(double *x, double *y)
{
  int tid;
  static double *p;
  p = 0;
  tid = omp_get_thread_num();
  printf("tid %d\n", tid);
  #pragma omp barrier
  if (tid == 0)
  {
    p = x;
  }

  #pragma omp barrier
  if (tid == 1)
  {
    p = y;
  }

  #pragma omp barrier
  {
    printf("func2 %d %f\n", tid, p[0]);
  }
}

