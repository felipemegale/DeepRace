void pingpong(int, int, int);
void pingpong(int tid, int var, int local)
{
  #pragma omp parallel private(local) shared(var)
  {
    #pragma omp master
    {
      tid = omp_get_thread_num();
      var = local;
    }
    #pragma omp barrier
    {
      tid = omp_get_thread_num();
      if (tid == 1)
      {
        local = 2;
        var = local;
      }

    }
    #pragma omp barrier
    #pragma omp master
    {
      tid = omp_get_thread_num();
    }
  }
}

