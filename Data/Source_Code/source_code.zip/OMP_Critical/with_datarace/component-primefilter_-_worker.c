int prime[100000000 + 1];
int nextbase;
int worker()
{
  int lim;
  int base;
  lim = sqrt(50000);
  do
  {
    {
      base = (nextbase += 2);
    }
    if (base <= lim)
    {
      if (prime[base])
        crossout(base);

    }
    else
      break;

  }
  while (1);
}

