static char rcsid[] = "$Id$";
int errors = 0;
int thds;
void func1(int magicno, int *prvt, int *prvt2)
{
  int id = omp_get_thread_num();
  if ((*prvt) != magicno)
  {
    errors += 1;
  }

  if ((*prvt2) != (magicno + 1))
  {
    errors += 1;
  }

  *prvt = id;
  *prvt2 = id + magicno;
  #pragma omp barrier
  if ((*prvt) != id)
  {
    errors += 1;
  }

  #pragma omp barrier
  if ((*prvt2) != (id + magicno))
  {
    errors += 1;
  }

}

