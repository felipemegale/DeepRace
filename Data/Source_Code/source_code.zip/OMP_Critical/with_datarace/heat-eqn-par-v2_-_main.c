void initialize(double uk[], double ukp1[], int nx);
int main(int argc, char *argv[])
{
  int nx;
  int maxsteps;
  double threshold;
  FILE *outfile;
  double *uk;
  double *ukp1;
  double *temp;
  double dx;
  double dt;
  double start_time;
  double end_time;
  double maxdiff;
  int step;
  int nthreads;
  parse_arguments(argc, argv, &nx, &maxsteps, &threshold, &outfile);
  start_time = get_time();
  uk = malloc((sizeof(*uk)) * (nx + 2));
  ukp1 = malloc((sizeof(*ukp1)) * (nx + 2));
  if ((uk == 0) || (ukp1 == 0))
  {
    fprintf(stderr, "Unable to allocate memory\n");
    return 1;
  }

  dx = 1.0 / nx;
  dt = (0.5 * dx) * dx;
  maxdiff = threshold;
  #pragma omp parallel
  {
    #pragma omp single
    {
      nthreads = omp_get_num_threads();
    }
  }
  initialize(uk, ukp1, nx);
  for (step = 0; (step < maxsteps) && (maxdiff >= threshold); ++step)
  {
    maxdiff = 0.0;
    #pragma omp parallel
    {
      double maxdiff_local = 0.0;
      double diff;
      #pragma omp for schedule(static)
      for (int i = 1; i <= nx; ++i)
      {
        ukp1[i] = uk[i] + ((dt / (dx * dx)) * ((uk[i + 1] - (2 * uk[i])) + uk[i - 1]));
        diff = fabs(uk[i] - ukp1[i]);
        if (diff > maxdiff_local)
          maxdiff_local = diff;

      }

      {
        if (maxdiff_local > maxdiff)
          maxdiff = maxdiff_local;

      }
    }
    temp = ukp1;
    ukp1 = uk;
    uk = temp;
  }

  end_time = get_time();
  if (outfile != 0)
  {
    print_values(outfile, uk, nx);
    fclose(outfile);
  }

  printf("OpenMP program v2 (%d threads):\n", nthreads);
  printf("nx = %d, maxsteps = %d, threshold = %g\n", nx, maxsteps, threshold);
  if (maxdiff < threshold)
  {
    printf("converged in %d iterations\n", step);
  }
  else
  {
    printf("failed to converge in %d iterations, maxdiff = %g\n", step, maxdiff);
  }

  printf("execution time = %g\n", end_time - start_time);
  free(uk);
  free(ukp1);
  return 0;
}

