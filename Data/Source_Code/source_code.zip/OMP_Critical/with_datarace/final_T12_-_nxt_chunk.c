int i;
int j;
double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
struct Data
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  omp_set_nested(0);
  #pragma omp parallel
  {
    int i;
    #pragma omp for
    for (i = 0; i < thds; i++)
    {
      #pragma omp parallel
      {
        #pragma omp sections
        {
          #pragma omp section
          {
            #pragma omp parallel
            {
              #pragma omp single
              {
                #pragma omp critical
                {
                  sum += 1;
                }
              }
            }
          }
        }
      }
    }

  }
  if (sum != thds)
  {
    ERROR(errors);
  }

  if (errors == 0)
  {
    printf("nesting 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("nesting 004 : FAILED\n");
    return 1;
  }


  int start;
  int end;
  int size;
};
struct Node
{
  struct Data *data;
  struct Node *next;
};
struct Q
{
  struct Node *front;
  struct Node *rear;
};
struct Data *nxt_chunk(struct Q *list[])
{
  struct Data *tempdat;
  struct Data *finaldat;
  int large = 0;
  int pos = -1;
  for (i = 0; i < 12; i++)
  {
    tempdat = peek(list[i]);
    if (tempdat != 0)
    {
      if (tempdat->size > large)
      {
        large = tempdat->size;
        pos = i;
      }

    }

  }

  if (pos != (-1))
  {
    {
      finaldat = deq(list[pos]);
    }
    return finaldat;
  }
  else
  {
    return 0;
  }

}

