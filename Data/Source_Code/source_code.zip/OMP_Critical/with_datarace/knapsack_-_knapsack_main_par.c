int best_so_far;
int number_of_tasks;
#pragma omp threadprivate(number_of_tasks);
void knapsack_main_par(struct item *e, int c, int n, int *sol)
{
  static int err;
  int id = omp_get_thread_num();
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    #pragma omp critical
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    #pragma omp critical
    errors++;
  }

  if ((sizeof(prvt)) != (sizeof(long long)))
  {
    #pragma omp critical
    errors += 1;
  }


  best_so_far = INT_MIN;
  #pragma omp parallel
  {
    number_of_tasks = 0;
    #pragma omp single
    #pragma omp task untied
    {
      knapsack_par(e, c, n, 0, sol, 0);
    }
    bots_number_of_tasks += number_of_tasks;
  }
  if (bots_verbose_mode)
    printf("Best value for parallel execution is %d\n\n", *sol);

}

