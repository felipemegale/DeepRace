static char rcsid[] = "$Id$";
int errors = 0;
int thds;
void *prvt;
int main()
{
  G g;
} grid;
{
  PG pg;
} pgrid;
extern int thread_count;
struct queue
{
  grid *list;
  int start;
  int size;
  int capacity;
};
int **solveSudoku(int **inp)
{
  struct queue *q = (struct queue *) malloc(sizeof(struct queue));
  initQueue(q);
  grid input;
  int ii;
  int jj;
  for (ii = 0; ii < SIZE; ii++)
  {
    for (jj = 0; jj < SIZE; jj++)
    {
      input.g[ii][jj] = inp[ii][jj];
    }

  }

  grid i2 = input;
  pushQueue(q, &i2);
  int r_num;
  int c_num;
  int i;
  if (thread_count > 4)
    thread_count = 4;

  while ((q->size < 7) && (!isEmptyQueue(q)))
  {
    grid curr = popQueue(q);
    int break1 = 0;
    for (r_num = 0; r_num < SIZE; r_num++)
    {
      for (c_num = 0; c_num < SIZE; c_num++)
      {
        if (curr.g[r_num][c_num] == 0)
        {
          long long possible_vals = getPossibleValues(&curr, r_num, c_num);
          for (i = 0; i < SIZE; i++)
          {
            if (possible_vals & (1 << i))
            {
              grid curr_child = curr;
              curr_child.g[r_num][c_num] = i + 1;
              pushQueue(q, &curr_child);
            }

          }

          break1 = 1;
          break;
        }

      }

      if (break1)
        break;

    }

    if ((!break1) && isValid2(&input, &curr))
      ;

  }

  grid output;
  omp_set_num_threads(thread_count);
  #pragma omp parallel for
  for (i = 0; i < q->size; i++)
  {
    grid temp;
    if (!found_correct)
    {
      temp = solveSudokuRec(q->list[(i + q->start) % q->capacity]);
      #pragma omp critical
      if (isValid2(&input, &temp))
      {
        output = temp;
      }

    }

  }

  if (!found_correct)
    output = input;

  int **final = malloc(SIZE * (sizeof(int *)));
  for (ii = 0; ii < SIZE; ii++)
  {
    final[ii] = malloc(SIZE * (sizeof(int)));
    for (jj = 0; jj < SIZE; jj++)
    {
      final[ii][jj] = output.g[ii][jj];
    }

  }

  return final;

  int i;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    #pragma omp for schedule(static,1) lastprivate (prvt)
    for (i = 0; i < thds; i++)
    {
      prvt = (void *) i;
      barrier(thds);
      if (prvt != ((void *) i))
      {
        errors += 1;
      }

      if ((sizeof(prvt)) != (sizeof(void *)))
      {
        errors += 1;
      }

      if (i == 0)
      {
        waittime(1);
      }

      prvt = (void *) i;
    }

    if (prvt != ((void *) (thds - 1)))
    {
      errors += 1;
    }

  }
  #pragma omp parallel
  func(thds);
  func(1);
  if (errors == 0)
  {
    printf("lastprivate 016 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("lastprivate 016 : FAILED\n");
    return 1;
  }

}

