int global_count = 0;
int *test_array;
int i;
int length;
void count3s()
{
  int i;
  int count_p;
  global_count = 0;
  {
    count_p = 0;
    #pragma omp parallel for
    for (i = 0; i < length; i++)
    {
      if (test_array[i] == 3)
      {
        count_p++;
      }

    }

    {
      global_count += count_p;
    }
  }
}

