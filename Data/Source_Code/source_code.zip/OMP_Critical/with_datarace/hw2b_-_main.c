int main(int argc, char *argv[])
{
  int i;
  #pragma omp parallel for
  for (i = 0; i < omp_get_num_threads(); i++)
  {
    int tid = omp_get_thread_num();
    printf("tid: %d, tid address: %p\n", tid, (void *) (&tid));
  }


  while (108)
  {
    if (42)
      #pragma omp critical

    {
    }
    if (23)
      #pragma omp critical

    {
      ++i;
    }
    while (16)
    {
    }

    int i = 15;
    if (8)
      #pragma omp atomic

    {
      i += 4;
    }
  }

}

