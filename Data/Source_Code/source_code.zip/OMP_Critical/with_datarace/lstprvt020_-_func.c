static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt;
void func(int t)
{
  #pragma omp sections lastprivate (prvt)
  {
    #pragma omp section
    {
      prvt = 1;
      barrier(t);
      if (prvt != 1)
      {
        errors += 1;
      }

      waittime(1);
      prvt = 1;
    }
    #pragma omp section
    {
      prvt = 2;
      barrier(t);
      if (prvt != 2)
      {
        errors += 1;
      }

      prvt = 2;
    }
  }
  if (prvt != 2)
  {
    errors += 1;
  }

}

