int main()
{
  double *T = (double *) malloc(((2000 + 2) * (2000 + 2)) * (sizeof(double)));
  init_T(T);
  double tol = pow(10, -3);
  double global_error;
  double starttime = omp_get_wtime();
  #pragma omp parallel
  {
    double *tmp1 = (double *) malloc((2000 + 2) * (sizeof(double)));
    double *tmp2 = (double *) malloc((2000 + 2) * (sizeof(double)));
    double *tmp3 = (double *) malloc((2000 + 2) * (sizeof(double)));
    int ystart = get_ystart(2000, omp_get_thread_num(), omp_get_num_threads());
    int yend = get_yend(2000, omp_get_thread_num(), omp_get_num_threads());
    int iterations = 0;
    double local_error = 0;
    do
    {
      #pragma omp barrier
      global_error = 0.0;
      local_error = 0.0;
      memcpy(tmp1, T + ((2000 + 2) * ystart), (2000 + 2) * (sizeof(double)));
      memcpy(tmp3, T + ((2000 + 2) * (yend + 1)), (2000 + 2) * (sizeof(double)));
      #pragma omp for schedule(static, (int)ceil((double)N/omp_get_num_threads()))
      for (int y = 1; y <= 2000; y++)
      {
        memcpy(tmp2, T + ((2000 + 2) * y), (2000 + 2) * (sizeof(double)));
        for (int x = 1; x <= 2000; x++)
        {
          double below;
          if (y == yend)
            below = tmp3[x];
          else
            below = T[((2000 + 2) * (y + 1)) + x];

          T[((2000 + 2) * y) + x] = (((tmp1[x] + tmp2[x - 1]) + tmp2[x + 1]) + below) / 4.0;
          local_error = (fabs(tmp2[x] - T[((2000 + 2) * y) + x]) > local_error) ? (fabs(tmp2[x] - T[((2000 + 2) * y) + x])) : (local_error);
        }

        double *swap = tmp1;
        tmp1 = tmp2;
        tmp2 = swap;
      }

      iterations++;
      {
        global_error = (local_error > global_error) ? (local_error) : (global_error);
      }
      #pragma omp barrier
    }
    while ((global_error >= tol) && (iterations < 1000));
    printf("EXIT thread: %d iterations: %d\n", omp_get_thread_num(), iterations);
    free(tmp1);
    free(tmp2);
    free(tmp3);
  }
  double endtime = omp_get_wtime();
  printf("Time: %f\n", endtime - starttime);
  printf("The temperature of element T(1,1): %f\n", T[((2000 + 2) * 1) + 1]);
  free(T);
  return 0;
}

