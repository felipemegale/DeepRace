int main(int argc, char **argv)
{
  int my_min;
  int min;
  int a[100];
  int i;
  for (i = 0; i < 100; i++)
    a[(100 - 1) - i] = i;

  min = a[0];
  #pragma omp parallel for shared (a,min) private(i)
  for (i = 0; i < 100; i++)
    if (a[i] < min)


  if (a[i] < min)
    min = a[i];

  printf("Minimum number is %d\n", min);
  return 0;
}

