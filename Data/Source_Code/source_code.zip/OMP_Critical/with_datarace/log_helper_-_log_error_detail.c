char *timestamp_watchdog;
char timestamp_file[] = "timestamp.txt";
char vardir_key[] = "vardir";
unsigned long int max_errors_per_iter = 500;
char *absolute_path;
char logdir_key[] = "logdir";
char config_file[] = "/etc/radiation-benchmarks.conf";
int iter_interval_print = 1;
int log_error_detail_count = 0;
char log_file_name[200] = "";
char full_log_file_name[300] = "";
unsigned long int last_iter_errors = 0;
unsigned long int last_iter_with_errors = 0;
unsigned long int kernels_total_errors = 0;
unsigned long int iteration_number = 0;
double kernel_time_acc = 0;
double kernel_time = 0;
long long it_time_start;
int log_error_detail(char *string)
{
  FILE *file = 0;
  #pragma omp parallel shared(log_error_detail_count)
  {
    log_error_detail_count++;
  }
  if (((unsigned long) log_error_detail_count) > max_errors_per_iter)
    return 0;

  file = fopen(full_log_file_name, "a");
  if (file == 0)
  {
    fprintf(stderr, "[ERROR in log_string(char *)] Unable to open file %s\n", full_log_file_name);
    return 1;
  }

  fputs("#ERR ", file);
  fputs(string, file);
  fprintf(file, "\n");
  fflush(file);
  fclose(file);
  return 0;

  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt = 100;
  #pragma omp parallel shared(prvt)
  {
    int id = omp_get_thread_num();
    #pragma omp sections firstprivate(prvt)
    {
      #pragma omp section
      {
        if (prvt != 100)
        {
          #pragma omp critical
          errors += 1;
        }

        prvt = id;
        barrier(2);
        if (prvt != id)
        {
          #pragma omp critical
          errors += 1;
        }

      }
      #pragma omp section
      {
        if (prvt != 100)
        {
          #pragma omp critical
          errors += 1;
        }

        prvt = id;
        barrier(2);
        if (prvt != id)
        {
          #pragma omp critical
          errors += 1;
        }

      }
    }
  }
  if (errors == 0)
  {
    printf("firstprivate 005 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 005 : FAILED\n");
    return 1;
  }

}

