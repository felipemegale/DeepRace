int f1()
{
  int i;
  int b;
  int b_p;
  float a;
  float a_p;
  a = 0.0;
  b = 0;
  #pragma omp parallel shared(a, b, x, y, n) private(a_p, b_p)
  {
    a_p = 0.0;
    b_p = 0;
    #pragma omp for private(i)
    for (i = 0; i < n; i++)
    {
      a_p += x[i];
      b_p ^= y[i];
    }

    #pragma omp critical
    {
      a += a_p;
      b ^= b_p;
    }
  }

  int i;
  int tid;
  int sum = 0;
  for (i = 0; i < 10; ++i)
  {
    sum += i;
    {
      tid = omp_get_thread_num();
      printf("In f1() with thread %d\n", tid);
    }
  }

  return sum;
}

