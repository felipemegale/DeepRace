int main()
{
  #pragma omp parallel for
  for (i = 0; i < n; i++)
  {
    if (x[i] > maxval)
    {
      maxval = x[i];
      maxloc = i;
    }

  }

  return 0;
}

