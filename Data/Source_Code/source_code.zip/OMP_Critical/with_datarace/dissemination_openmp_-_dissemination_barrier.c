int num_threads;
int num_rounds;
{
  int myflags[2][10000];
  int *partnerflags[2][10000];
} flags;
void dissemination_barrier(flags *local_flags, int *parity, int *sense)
{
  int i;
  for (i = 0; i < num_rounds; i++)
  {
    {
      *local_flags->partnerflags[*parity][i] = *sense;
    }
    while (local_flags->myflags[*parity][i] != (*sense))
      ;

  }

  if ((*parity) == 1)
  {
    *sense = !(*sense);
  }

  *parity = 1 - (*parity);
}

