int main(int argc, char **argv)
{
  int Numprocs;
  int MyRank;
  int iam;
  int NoofCols;
  int NoofRows;
  int ScatterSize;
  int index;
  int irow;
  int icol;
  int Root = 0;
  float **InputMatrix;
  float *Buffer;
  float *MyBuffer;
  float max = 0;
  float sum = 0;
  float Inf_norm = 0;
  FILE *fp;
  int MatrixFileStatus = 1;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &MyRank);
  MPI_Comm_size(MPI_COMM_WORLD, &Numprocs);
  if (MyRank == 0)
  {
    if ((fp = fopen("./data/infndata.inp", "r")) == 0)
    {
      MatrixFileStatus = 0;
    }

    if (MatrixFileStatus != 0)
    {
      fscanf(fp, "%d %d\n", &NoofRows, &NoofCols);
      InputMatrix = (float **) malloc(NoofRows * (sizeof(float *)));
      for (irow = 0; irow < NoofRows; irow++)
        InputMatrix[irow] = (float *) malloc(NoofCols * (sizeof(float)));

      for (irow = 0; irow < NoofRows; irow++)
      {
        for (icol = 0; icol < NoofCols; icol++)
          fscanf(fp, "%f", &InputMatrix[irow][icol]);

      }

      fclose(fp);
      Buffer = (float *) malloc((NoofRows * NoofCols) * (sizeof(float)));
      index = 0;
      for (irow = 0; irow < NoofRows; irow++)
      {
        for (icol = 0; icol < NoofCols; icol++)
        {
          Buffer[index] = InputMatrix[irow][icol];
          index++;
        }

      }

    }

  }

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Bcast(&MatrixFileStatus, 1, MPI_INT, Root, MPI_COMM_WORLD);
  if (MatrixFileStatus == 0)
  {
    if (MyRank == Root)
      printf("Can't Open Matrix Input File");

    MPI_Finalize();
    exit(-1);
  }

  MPI_Bcast(&NoofRows, 1, MPI_INT, Root, MPI_COMM_WORLD);
  if (NoofRows < Numprocs)
  {
    MPI_Finalize();
    if (MyRank == 0)
      printf("Noof Rows Should Be More Than No of Processors ... \n");

    exit(0);
  }

  if ((NoofRows % Numprocs) != 0)
  {
    MPI_Finalize();
    if (MyRank == 0)
    {
      printf("Matrix Cannot Be Striped Evenly ..... \n");
    }

    exit(0);
  }

  MPI_Bcast(&NoofCols, 1, MPI_INT, Root, MPI_COMM_WORLD);
  ScatterSize = NoofRows / Numprocs;
  MyBuffer = (float *) malloc((ScatterSize * NoofCols) * (sizeof(float)));
  MPI_Scatter(Buffer, ScatterSize * NoofCols, MPI_FLOAT, MyBuffer, ScatterSize * NoofCols, MPI_FLOAT, 0, MPI_COMM_WORLD);
  max = 0;
  omp_set_num_threads(4);
  #pragma omp parallel for private(sum,index,icol) shared(max)
  for (irow = 0; irow < ScatterSize; irow++)
  {
    printf("The Threadid Is %d With each Processor's Rank %d\n", omp_get_thread_num(), MyRank);
    sum = 0;
    index = irow * NoofCols;
    for (icol = 0; icol < NoofCols; icol++)
    {
      sum += (MyBuffer[index] >= 0) ? (MyBuffer[index]) : (0 - MyBuffer[index]);
      index++;
    }

    if (sum > max)
      max = sum;

  }

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Reduce(&max, &Inf_norm, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
  if (MyRank == 0)
  {
    max = 0;
    for (irow = 0; irow < NoofRows; irow++)
    {
      sum = 0;
      index = irow * NoofCols;
      for (icol = 0; icol < NoofCols; icol++)
      {
        sum += (Buffer[index] >= 0) ? (Buffer[index]) : (0 - Buffer[index]);
        index++;
      }

      max = (max < sum) ? (sum) : (max);
    }

    printf("\nThe Infinity Norm Is(Parallel Code) : %f\n", Inf_norm);
    printf("\nThe Infinity Norm Is(Serial Code)   : %f\n\n", max);
    free(InputMatrix);
    free(Buffer);
  }

  free(MyBuffer);
  MPI_Finalize();
}

