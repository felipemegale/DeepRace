int main(int argc, char **argv)
{
  int sj;
  int sstop;
  int tn;
  int tj;
  int tstop;
  int foo(int j);
  omp_set_num_threads(8);
  sj = -1;
  sstop = 0;
  #pragma omp parallel private(tn,tj,tstop)
  {
    tn = omp_get_thread_num();
    while (!sstop)
    {
      {
        sj++;
        tj = sj;
      }
      tstop = foo(tj);
      if (tstop)
      {
        sstop = 1;
        #pragma omp flush(sstop)
      }

      printf("Thread %d, iteration %d, sstop=%d\n", tn, tj, sstop);
    }

  }
}

