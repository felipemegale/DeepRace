{
  int prime;
  long pos;
  long end;
} info_pos_t;
{
  int num_threads;
  long max_num;
  int count;
  info_pos_t cur_pos;
} info_t;
void get_next(info_pos_t *info);
int main(int argc, char **argv)
{
  int i;
  int *number;
  info_pos_t info;
  info_t data;
  if (argc < 3)
  {
    printf("Wrong usage. You should type:\n\t./control <target_number> <number_of_threads>\n");
    return 0;
  }

  data.num_threads = atoi(argv[2]);
  data.max_num = atoi(argv[1]);
  data.cur_pos.prime = 2;
  data.cur_pos.pos = 0;
  data.cur_pos.end = data.max_num / data.num_threads;
  data.count = 1;
  number = (int *) calloc(data.max_num - 1, sizeof(int));
  #pragma omp parallel shared(number, data) private(info, i) num_threads(data.num_threads)
  {
    info.pos = 0;
    while (1)
    {
      {
        info = data.cur_pos;
        if (data.cur_pos.end >= data.max_num)
        {
          for (i = 0; i <= sqrt(data.max_num); i++)
          {
            if ((!number[i]) && ((i + 2) > data.cur_pos.prime))
            {
              data.cur_pos.prime = i + 2;
              data.cur_pos.pos = 0;
              data.count = 1;
              data.cur_pos.end = data.max_num / data.num_threads;
              break;
            }

          }

          if (i >= floor(sqrt(data.max_num)))
          {
            data.cur_pos.pos = -1;
          }

        }
        else
        {
          data.count++;
          data.cur_pos.pos = data.cur_pos.end + 1;
          data.cur_pos.end = (data.count * data.max_num) / data.num_threads;
        }

      }
      if (info.pos < 0)
      {
        break;
      }

      for (i = ((info.pos / info.prime) * info.prime) + (((info.pos % info.prime) > 0) ? (info.prime) : (0)); i <= info.end; i += info.prime)
      {
        if (i > info.prime)
        {
          number[i - 2] = 1;
        }

      }

    }

  }
  free(number);
  return 0;

  POMP_Parallel_fork(&omp_rd_5);
  #pragma omp parallel
  {
    POMP_Parallel_begin(&omp_rd_5);
    POMP_For_enter(&omp_rd_5);
    #pragma omp for nowait
    for (int i = 1; i <= xsize; i++)
      for (int j = 1; j <= ysize; j++)
    {
      unsigned int icolor;
      double color;
      color = (h[i][j] - 20.0) / (100.0 - 20.0);
      if (color < 0.0)
        color = 0.0;

      if (color > 1.0)
        color = 1.0;

      if (graphics)
      {
        POMP_Critical_enter(&omp_rd_6);
        #pragma omp critical(draw)
        {
          POMP_Critical_begin(&omp_rd_6);
          {
            graphic_setRainbowColor(window_number, (double) color);
            graphic_drawPoint(window_number, i, j);
          }
          POMP_Critical_end(&omp_rd_6);
        }
        POMP_Critical_exit(&omp_rd_6);
      }

    }


    POMP_Barrier_enter(&omp_rd_5);
    #pragma omp barrier
    POMP_Barrier_exit(&omp_rd_5);
    POMP_For_exit(&omp_rd_5);
    POMP_Parallel_end(&omp_rd_5);
  }
  POMP_Parallel_join(&omp_rd_5);
  if (graphics)
    graphic_flush(window_number);

}

