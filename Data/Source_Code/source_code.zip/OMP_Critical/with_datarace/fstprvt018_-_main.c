static char rcsid[] = "$Id$";
int errors = 0;
int thds;
const int prvt = 100;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel firstprivate(prvt)
  {
    if (prvt != 100)
    {
      errors += 1;
    }

  }
  if (errors == 0)
  {
    printf("firstprivate 018 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 018 : FAILED\n");
    return 1;
  }

}

