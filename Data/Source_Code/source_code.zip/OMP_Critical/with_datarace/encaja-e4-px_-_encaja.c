{
  int i;
  int j;
  int stop = floor((num + 1) / 2);
  if (threads == 1)
  {
    #pragma omp parallel for num_threads(threads)
    for (i = 2; i < stop; i++)
    {
      #pragma omp parallel for num_threads(threads)
      for (j = i; j <= num; j = j + i)
      {
        if (j != i)
        {
          #pragma omp critical
          primes[j] = 0;
        }

      }

    }

  }
  else
  {
    #pragma omp parallel for num_threads(threads/2)
    for (i = 2; i < stop; i++)
    {
      #pragma omp parallel for num_threads(threads/2)
      for (j = i; j <= num; j = j + i)
      {
        if (j != i)
        {
          #pragma omp critical
          primes[j] = 0;
        }

      }

    }

  }


  Byte r;
  Byte g;
  Byte b;
} Pixel;
{
  unsigned int ancho;
  unsigned int alto;
  Pixel *datos;
} Imagen;
void encaja(Imagen *ima)
{
  unsigned n;
  unsigned i;
  unsigned j;
  unsigned x;
  unsigned linea_minima = 0;
  long unsigned distancia;
  long unsigned distancia_minima;
  const long unsigned grande = 1 + (ima->ancho * 768ul);
  int nr_of_threads;
  int skip = 0;
  n = ima->alto - 2;
  for (i = 0; i < n; i++)
  {
    distancia_minima = grande;
    for (j = i + 1; j < ima->alto; j++)
    {
      distancia = 0;
      #pragma omp parallel private(x)
      {
        nr_of_threads = omp_get_num_threads();
        int th_id = omp_get_thread_num();
        for (x = th_id; x < ima->ancho; x += nr_of_threads)
        {
          {
            distancia += diferencia(&ima->datos[x + (i * ima->ancho)], &ima->datos[x + (j * ima->ancho)]);
          }
          if (distancia > distancia_minima)
            break;

        }

      }
      if (distancia < distancia_minima)
      {
        distancia_minima = distancia;
        linea_minima = j;
      }

    }

    intercambia_lineas(ima, i + 1, linea_minima);
  }

}

