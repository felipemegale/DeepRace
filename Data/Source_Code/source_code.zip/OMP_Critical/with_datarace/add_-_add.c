int add()
{
  int result = 0;
  int i;
  #pragma omp parallel for num_threads(NUM_ACCEL) private(i)
  for (i = 0; i < 10000; i++)
  {
    {
      result += array[i];
    }
  }

  return result;
}

