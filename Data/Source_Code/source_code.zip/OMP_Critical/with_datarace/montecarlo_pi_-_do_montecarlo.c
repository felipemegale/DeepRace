int do_montecarlo(int s)
{
  int res1;
  int res2;
  #pragma omp target map (from: res1, res2)
  {
    int B[2000];
    int i;
    int nthreads;
    res1 = foo();
    #pragma omp parallel shared (B, nthreads)
    {
      #pragma omp master
      nthreads = omp_get_num_threads();
      #pragma omp for
      for (i = 0; i < 2000; i++)
        B[i] = 0;

      #pragma omp critical (crit2)
      for (i = 0; i < 2000; i++)
        B[i]++;

    }
    res2 = 0;
    for (i = 0; i < 2000; i++)
      if (B[i] != nthreads)
      res2 = 1;


  }
  if (res1 || res2)
    abort();

  return 0;

  static int R = 8932;
  int x;
  int y;
  int x2;
  int y2;
  int ret = 0;
  int R2 = R * R;
  srand(time(0));
  unsigned int seed = rand();
  #pragma omp parallel
  {
    #pragma omp for
    for (int i = 0; i < s; i++)
    {
      x = randint(R, &seed);
      y = randint(R, &seed);
      x2 = x * x;
      y2 = y * y;
      if ((x2 + y2) < R2)
      {
        ret++;
      }

    }

  }
  return ret;
}

