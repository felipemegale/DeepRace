static char rcsid[] = "$Id$";
int errors = 0;
int thds;
double prvt;
void func2(int magicno)
{
  double h;
  double x;
  double my_result;
  double local_a;
  double local_b;
  int i;
  int local_n;
  int my_rank = omp_get_thread_num();
  int thread_count = omp_get_num_threads();
  h = (b - a) / n;
  local_n = n / thread_count;
  local_a = a + ((my_rank * local_n) * h);
  local_b = local_a + (local_n * h);
  my_result = (f(local_a) + f(local_b)) / 2.0;
  for (i = 1; i <= (local_n - 1); i++)
  {
    x = local_a + (i * h);
    my_result += f(x);
  }

  my_result = my_result * h;
  #pragma omp critical
  *global_result_p += my_result;

  static int err;
  int id = omp_get_thread_num();
  if (prvt != magicno)
  {
    errors += 1;
  }

  #pragma omp barrier
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    errors++;
  }

}

