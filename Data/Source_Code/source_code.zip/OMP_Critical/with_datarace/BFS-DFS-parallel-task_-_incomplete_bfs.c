int C[81][2];
int N;
int R[9][3] = {};
int threadcount = 0;
#pragma omp threadprivate(threadcount);
int incomplete_bfs()
{
  int ret = 0;
  #pragma omp parallel
  {
    #pragma omp single
    {
      dfs(0, R);
    }
    ret += threadcount;
  }
  return ret;
}

