const double G = 6.673e-11f;
const double delta_t = 3600.0;
const double EARTH_MASS = 5.9742e24;
const double EARTH_SUN = 149600000;
const double SPEED_FACTOR = 1.45e10;
double pos[1500][2];
double forces[1500][2];
double newPos[1500][2];
double vel[1500][2];
double newVel[1500][2];
double masses[1500];
float Ranf(float, float);
void solve(int ite)
{
  for (int t = 0; t < ite; t++)
  {
    #pragma omp parallel for schedule(static, N/thread_count)
    for (int q = 0; q < 1500; q++)
    {
      forces[q][0] = 0;
      forces[q][1] = 0;
    }

    #pragma omp parallel for schedule(static, N/thread_count)
    for (int q = 0; q < 1500; q++)
    {
      for (int k = 1500 - 1; q < k; k--)
      {
        double x_diff = pos[q][0] - pos[k][0];
        double y_diff = pos[q][1] - pos[k][1];
        double dist = sqrt((x_diff * x_diff) + (y_diff * y_diff));
        double dist_cubed = (dist * dist) * dist;
        if (dist_cubed < 0)
          dist_cubed = (-1) * dist_cubed;

        double force_qkX = (((G * masses[q]) * masses[k]) / dist_cubed) * x_diff;
        double force_qkY = (((G * masses[q]) * masses[k]) / dist_cubed) * y_diff;
        {
          forces[q][0] -= force_qkX;
          forces[q][1] -= force_qkY;
          forces[k][0] += force_qkX;
          forces[k][1] += force_qkY;
        }
      }

    }

    #pragma omp parallel for schedule(static, N/thread_count)
    for (int q = 0; q < 1500; q++)
    {
      newPos[q][0] += delta_t * vel[q][0];
      newPos[q][1] += delta_t * vel[q][1];
      newVel[q][0] += (delta_t / masses[q]) * forces[q][0];
      newVel[q][1] += (delta_t / masses[q]) * forces[q][1];
    }

    #pragma omp parallel for schedule(static, N/thread_count)
    for (int q = 0; q < 1500; q++)
    {
      pos[q][0] = newPos[q][0];
      pos[q][1] = newPos[q][1];
      vel[q][0] = newVel[q][0];
      vel[q][1] = newVel[q][1];
    }

  }


  int data;
  struct tnode *left;
  struct tnode *right;
} tnode;
void omp_info();
void quick_sort(int *, int, int);
void printf_array(int *, int);
void sum_tree_data(struct tnode *, int *);
tnode *create_node();
void free_tree(tnode *);
void quick_sort(int *array, int first, int last)
{
  int i = first;
  int j = last;
  int temp;
  int x;
  x = array[first + ((last - first) / 2)];
  do
  {
    while (array[i] < x)
      i++;

    while (array[j] > x)
      j--;

    if (i <= j)
    {
      if (array[i] > array[j])
      {
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }

      i++;
      j--;
    }

  }
  while (i <= j);
  #pragma omp critical (printf)
  printf("Thread # %d\n", omp_get_thread_num());
  #pragma omp task shared(array)
  if (i < last)
    quick_sort(array, i, last);

  #pragma omp task shared(array)
  if (first < j)
    quick_sort(array, first, j);

  #pragma omp taskwait
}

