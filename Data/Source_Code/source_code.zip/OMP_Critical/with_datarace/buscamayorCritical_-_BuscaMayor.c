int *formaVect(int n);
void llenaVect(int *v, int n);
int BuscaMayor(int *A, int n)
{
  int i;
  int max;
  max = A[0];
  #pragma omp parallel
  {
    #pragma omp for
    for (i = 0; i < n; i++)
    {
      if (max < A[i])

      {
        if (max < A[i])
          max = A[i];

      }
    }

  }
  return max;
}

