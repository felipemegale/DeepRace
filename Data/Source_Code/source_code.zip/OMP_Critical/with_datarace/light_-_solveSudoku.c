int hs(int *, long *, int *);
int hdfs(int *, long *, int *);
int set_board_value(int *, long *, int *, int, int);
void undo_alterations(int *, long *, int *, int, int);
int *brd;
long *bits;
int global_solved;
int wpl_sz;
int wpl_szalloc;
int **wpl_brd;
long **wpl_bits;
int **solveSudoku(int **origmat)
{
  global_solved = 0;
  brd = malloc((SIZE * SIZE) * (sizeof(int)));
  bits = malloc((SIZE * SIZE) * (sizeof(long)));
  int i;
  for (i = 0; i < SIZE; ++i)
  {
    memmove(brd + (i * SIZE), origmat[i], SIZE * (sizeof(int)));
  }

  int r;
  int c;
  int b;
  int idx;
  int rp;
  int cp;
  for (i = 0; i < (SIZE * SIZE); ++i)
  {
    r = i / SIZE;
    c = i % SIZE;
    if (origmat[r][c] != 0)
    {
      bits[i] = 0;
    }
    else
    {
      bits[i] = (1 << (SIZE + 1)) - 2;
      rp = r - (r % MINIGRIDSIZE);
      cp = c - (c % MINIGRIDSIZE);
      for (idx = 0; idx < SIZE; ++idx)
      {
        b = origmat[r][idx];
        if (b != 0)
        {
          if (bits[i] & (1 << b))
          {
            bits[i] &= ~(1 << b);
          }

        }

        b = origmat[idx][c];
        if (b != 0)
        {
          if (bits[i] & (1 << b))
          {
            bits[i] &= ~(1 << b);
          }

        }

        b = origmat[rp + (idx / MINIGRIDSIZE)][cp + (idx % MINIGRIDSIZE)];
        if (b != 0)
        {
          if (bits[i] & (1 << b))
          {
            bits[i] &= ~(1 << b);
          }

        }

      }

    }

  }

  global_solved = 0;
  int *arr_lr = malloc(((3 * SIZE) * SIZE) * (sizeof(int)));
  global_solved = hs(brd, bits, arr_lr);
  free(arr_lr);
  if (global_solved == 1)
  {
    for (r = 0; r < SIZE; ++r)
    {
      for (c = 0; c < SIZE; ++c)
      {
        origmat[r][c] = brd[(r * SIZE) + c];
      }

    }

    return origmat;
  }

  int nt = omp_get_num_threads();
  int *wpl_i_sz = malloc((SIZE + 1) * (sizeof(int)));
  memset(wpl_i_sz, 0, (SIZE + 1) * (sizeof(int)));
  wpl_brd = malloc((2 * (((SIZE * SIZE) > nt) ? (SIZE * SIZE) : (nt))) * (sizeof(int *)));
  wpl_bits = malloc((2 * (((SIZE * SIZE) > nt) ? (SIZE * SIZE) : (nt))) * (sizeof(long *)));
  int **wplhelpers = malloc((2 * (((SIZE * SIZE) > nt) ? (SIZE * SIZE) : (nt))) * (sizeof(int *)));
  int x;
  for (idx = 0; idx < (SIZE * SIZE); ++idx)
  {
    x = bit2nal(bits[idx]);
    if (wpl_i_sz[x] == 0)
    {
      wplhelpers[x] = malloc((SIZE * SIZE) * (sizeof(int)));
    }

    wplhelpers[x][wpl_i_sz[x]] = idx;
    wpl_i_sz[x]++;
  }

  int fl_brk = 0;
  int jdx;
  int tochng;
  int vit;
  for (idx = 2; (idx <= SIZE) && (fl_brk == 0); ++idx)
  {
    for (jdx = 0; (jdx < wpl_i_sz[idx]) && (fl_brk == 0); ++jdx)
    {
      for (vit = 1; vit <= SIZE; ++vit)
      {
        tochng = wplhelpers[idx][jdx];
        if (bits[tochng] & (1 << vit))
        {
          int *newbrd = malloc((SIZE * SIZE) * (sizeof(int)));
          long *newbits = malloc((SIZE * SIZE) * (sizeof(long)));
          memmove(newbrd, brd, (SIZE * SIZE) * (sizeof(int)));
          memmove(newbits, bits, (SIZE * SIZE) * (sizeof(long)));
          set_board_value(newbrd, newbits, 0, tochng, vit);
          wpl_brd[wpl_sz] = newbrd;
          wpl_bits[wpl_sz] = newbits;
          wpl_sz++;
        }

      }

      if (wpl_sz > nt)
      {
        fl_brk = 1;
      }

    }

  }

  #pragma omp parallel
  {
    #pragma omp single
    {
      nt = omp_get_num_threads();
    }
    int wpliter = omp_get_thread_num();
    int *tbrd;
    long *tbits;
    int *arr_tlr;
    int didpop;
    int loc_solved;
    arr_tlr = malloc(((3 * SIZE) * SIZE) * (sizeof(int)));
    loc_solved = 0;
    while (wpliter < wpl_sz)
    {
      tbrd = wpl_brd[wpliter];
      tbits = wpl_bits[wpliter];
      loc_solved = hdfs(tbrd, tbits, arr_tlr);
      if (loc_solved == 1)
      {
        {
          if (global_solved != 1)
          {
            global_solved = 1;
            brd = tbrd;
            bits = tbits;
          }
          else
          {
            loc_solved = 13;
          }

        }
        break;
      }
      else
        if (loc_solved == 42)
      {
        break;
      }
      else
        if (global_solved == 1)
      {
        break;
      }



      free(tbrd);
      free(tbits);
      tbrd = 0;
      wpliter += nt;
    }

    free(arr_tlr);
    if ((loc_solved == 1) || (tbrd == 0))
    {
    }
    else
    {
      free(tbrd);
      free(tbits);
    }

  }
  for (r = 0; r < SIZE; ++r)
  {
    for (c = 0; c < SIZE; ++c)
    {
      origmat[r][c] = brd[(r * SIZE) + c];
    }

  }

  return origmat;
}

