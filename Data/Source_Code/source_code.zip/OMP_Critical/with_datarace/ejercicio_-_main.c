{
  double x;
  double y;
  double c;
} punto;
void inicializaMatriz(punto *puntos);
double dist(double x1, double y1, double x2, double y2);
int main()
{
  srand((unsigned int) time(0));
  punto *puntos = (punto *) malloc(5000 * (sizeof(punto)));
  punto *distancias = (punto *) malloc(5000 * (sizeof(punto)));
  punto c1;
  punto c2;
  inicializaMatriz(puntos);
  c1.x = ((double) rand()) / ((double) 32767);
  c1.y = ((double) rand()) / ((double) 32767);
  c2.x = ((double) rand()) / ((double) 32767);
  c2.y = ((double) rand()) / ((double) 32767);
  double sumC1x = -1;
  double sumC1y = -1;
  double sumC2x = -1;
  double sumC2y = -1;
  double nC1 = 0.0;
  double nC2 = 0.0;
  int acabo = 0;
  printf("\n");
  int i = 0;
  while (acabo == 0)
  {
    int i = 0;
    sumC1x = 0;
    sumC1y = 0;
    sumC2x = 0;
    sumC2y = 0;
    nC1 = 0;
    nC2 = 0;
    #pragma omp parallel for private(i)
    for (i = 0; i < 5000; i++)
    {
      double distanciaC1 = dist((puntos + i)->x, (puntos + i)->y, c1.x, c1.y);
      double distanciaC2 = dist((puntos + i)->x, (puntos + i)->y, c2.x, c2.y);
      {
        if (distanciaC1 < distanciaC2)
        {
          sumC1x += (puntos + i)->x;
          sumC1y += (puntos + i)->y;
          nC1++;
        }
        else
        {
          sumC2x += (puntos + i)->x;
          sumC2y += (puntos + i)->y;
          nC2++;
        }

      }
    }

    sumC1x /= nC1;
    sumC1y /= nC1;
    sumC2x /= nC2;
    sumC2y /= nC2;
    if ((dist(sumC1x, sumC1y, c1.x, c1.y) < .0001) || (dist(sumC2x, sumC2y, c2.x, c2.y) < .0001))
    {
      acabo = 1;
    }

    c1.x = sumC1x;
    c1.y = sumC1y;
    c2.x = sumC2x;
    c2.y = sumC2y;
  }

  printf("=========================\n");
  printf("= C1(%f,%f) =\n", c1.x, c1.y);
  printf("= C2(%f,%f) =\n", c2.x, c2.y);
  printf("=========================\n");
  free(puntos);
  free(distancias);
  return 0;
}

