int omp_parallel_for()
{
  double sum = 0.0;
  double max;
  double min;
  max = (min = M1[0] - M2[0]);
  int i;
  int j;
  double diff;
  #pragma omp parallel for private(i,j,diff,min,max) reduction(+:sum)
  for (i = 0; i < Rows_Size; ++i)
  {
    for (j = 0; j < Rows_Size; ++j)
    {
      diff = M1[(i * Rows_Size) + j] - M2[(i * Rows_Size) + j];
      #pragma omp critical
      {
        max = (max > diff) ? (max) : (diff);
        min = (min < diff) ? (min) : (diff);
        sum += diff * diff;
      }
    }

  }

  return sqrt(sum / (Rows_Size * Rows_Size));

  int i;
  int tid;
  int counter = 0;
  int nt = omp_get_num_procs();
  int *counters = (int *) calloc(nt, sizeof(int));
  if (counters == 0)
    exit(-1);

  #pragma omp parallel for private(i, tid)
  for (i = 0; i < 10000; ++i)
  {
    {
      tid = omp_get_thread_num();
      counters[tid]++;
    }
  }

  for (i = 0; i < nt; ++i)
  {
    counter += counters[i];
  }

  return counter;
}

