void introduction();
void getParameters(int, char **, long int *, int *);
void calcTrapezoid(double, double, long int, double *);
float functionCalc(long double);
void displayResults(int, int, int, long int, float, double);
void calcTrapezoid(double a, double b, long int n, double *global_result_p)
{
  double x;
  double my_result;
  double w;
  double local_a;
  double local_b = 0.0;
  int i;
  long int local_n;
  int my_rank = omp_get_thread_num();
  int thread_count = omp_get_num_threads();
  if (thread_count == 1)
  {
    w = (b - a) / n;
    my_result = (functionCalc(a) + functionCalc(b)) / 2.0;
    for (i = 1; i < n; i++)
    {
      x = a + (i * w);
      my_result += functionCalc(x);
      if ((i % 10) == 0)
        printf("i: %d", i);

    }

    my_result = w * my_result;
    *global_result_p += my_result;
    printf("Thread %2d approximation: %f\n", my_rank, my_result);
  }
  else
  {
    w = (b - a) / n;
    local_n = n / thread_count;
    local_a = a + ((my_rank * local_n) * w);
    local_b = (functionCalc(local_a) + functionCalc(local_b)) / 2.0;
    for (i = 1; i < local_n; i++)
    {
      x = local_a + (i * w);
      my_result += functionCalc(x);
    }

    my_result = w * my_result;
    *global_result_p += my_result;
    printf("Thread %2d approximation: %f\n", my_rank, my_result);
  }

  return;
}

