static const double maxeps = 0.1e-7;
static const int itmax = 5000;
int i;
int j;
int k;
double eps;
double A[(((((2 * 2) * 2) * 2) * 2) * 2) + 2][(((((2 * 2) * 2) * 2) * 2) * 2) + 2][(((((2 * 2) * 2) * 2) * 2) * 2) + 2];
double B[(((((2 * 2) * 2) * 2) * 2) * 2) + 2][(((((2 * 2) * 2) * 2) * 2) * 2) + 2][(((((2 * 2) * 2) * 2) * 2) * 2) + 2];
void relax();
void resid();
void init();
void verify();
double e;
int THREADS;
void resid()
{
  double global = eps;
  #pragma omp parallel num_threads(THREADS) shared(global) private(i,j,k)
  {
    double local = eps;
    #pragma omp for schedule(static)
    for (i = 1; i <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); i++)
      for (j = 1; j <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); j++)
      for (k = 1; k <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); k++)
    {
      double e = fabs(A[i][j][k] - B[i][j][k]);
      A[i][j][k] = B[i][j][k];
      local = (local > e) ? (local) : (e);
    }



    {
      if (local > global)
      {
        global = local;
      }

    }
  }
  eps = (fabs(e) > global) ? (fabs(e)) : (global);
}

