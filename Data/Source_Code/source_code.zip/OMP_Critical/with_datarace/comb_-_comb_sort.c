void comb_sort(int *, unsigned long, int numThreads);
void imprimir_vetor(int *, unsigned long);
int validador(int *, unsigned long);
void comb_sort(int *vetor, unsigned long tam, int numThreads)
{
  long i;
  long j;
  long d;
  int intervalo;
  int trocado = 1;
  int aux;
  intervalo = tam;
  while ((intervalo > 1) || (trocado == 1))
  {
    intervalo = (intervalo * 10) / 13;
    if ((intervalo == 9) || (intervalo == 10))
    {
      intervalo = 11;
    }

    if (intervalo < 1)
    {
      intervalo = 1;
    }

    trocado = 0;
    #pragma omp parallel for schedule(static) num_threads(numThreads) shared(vetor, intervalo, trocado, tam) private(aux, i)
    for (i = 0; i < (tam - intervalo); i++)
    {
      if (vetor[i] > vetor[i + intervalo])
      {
        aux = vetor[i];
        vetor[i] = vetor[i + intervalo];
        vetor[i + intervalo] = aux;
        if (trocado == 0)
        {
          trocado = 1;
        }

      }

    }

  }

}

