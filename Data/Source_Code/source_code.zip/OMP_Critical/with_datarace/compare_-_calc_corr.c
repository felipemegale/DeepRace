int s;
int c;
int rmax;
int rmin;
int max_r = 0;
double i2i2;
double max_corr = -DBL_MAX;
void calc_corr(struct rotation *quat, double *m1, double *m2)
{
  int vol = (s * s) * s;
  #pragma omp parallel default(shared)
  {
    int x;
    int y;
    int z;
    int r;
    int i;
    int j;
    int priv_max_r = 0;
    int vox[3];
    double fx;
    double fy;
    double fz;
    double cx;
    double cy;
    double cz;
    double i1i2;
    double i1i1;
    double corr;
    double priv_max_corr = -DBL_MAX;
    double rot[3][3];
    double rot_vox[3];
    double *rotmodel = malloc(vol * (sizeof(double)));
    int rank = omp_get_thread_num();
    #pragma omp for schedule(static,1)
    for (r = 0; r < quat->num_rot; ++r)
    {
      make_rot_quat(&quat->quat[r * 5], rot);
      for (x = 0; x < vol; ++x)
        rotmodel[x] = 0.;

      for (vox[0] = -c; vox[0] < ((s - c) - 1); ++vox[0])
        for (vox[1] = -c; vox[1] < ((s - c) - 1); ++vox[1])
        for (vox[2] = -c; vox[2] < ((s - c) - 1); ++vox[2])
      {
        for (i = 0; i < 3; ++i)
        {
          rot_vox[i] = 0.;
          for (j = 0; j < 3; ++j)
            rot_vox[i] += rot[i][j] * vox[j];

          rot_vox[i] += c;
        }

        if ((rot_vox[0] < 0) || (rot_vox[0] >= (s - 1)))
          continue;

        if ((rot_vox[1] < 0) || (rot_vox[1] >= (s - 1)))
          continue;

        if ((rot_vox[2] < 0) || (rot_vox[2] >= (s - 1)))
          continue;

        x = (int) rot_vox[0];
        y = (int) rot_vox[1];
        z = (int) rot_vox[2];
        fx = rot_vox[0] - x;
        fy = rot_vox[1] - y;
        fz = rot_vox[2] - z;
        cx = 1. - fx;
        cy = 1. - fy;
        cz = 1. - fz;
        rotmodel[((((vox[0] + c) * s) * s) + ((vox[1] + c) * s)) + (vox[2] + c)] = (((((((((cx * cy) * cz) * m1[(((x * s) * s) + (y * s)) + z]) + (((cx * cy) * fz) * m1[(((x * s) * s) + (y * s)) + ((z + 1) % s)])) + (((cx * fy) * cz) * m1[(((x * s) * s) + (((y + 1) % s) * s)) + z])) + (((cx * fy) * fz) * m1[(((x * s) * s) + (((y + 1) % s) * s)) + ((z + 1) % s)])) + (((fx * cy) * cz) * m1[(((((x + 1) % s) * s) * s) + (y * s)) + z])) + (((fx * cy) * fz) * m1[(((((x + 1) % s) * s) * s) + (y * s)) + ((z + 1) % s)])) + (((fx * fy) * cz) * m1[(((((x + 1) % s) * s) * s) + (((y + 1) % s) * s)) + z])) + (((fx * fy) * fz) * m1[(((((x + 1) % s) * s) * s) + (((y + 1) % s) * s)) + ((z + 1) % s)]);
      }



      i1i1 = 0.;
      i1i2 = 0.;
      for (x = 0; x < vol; ++x)
      {
        i1i1 += rotmodel[x] * rotmodel[x];
        i1i2 += m2[x] * rotmodel[x];
      }

      corr = (i1i2 / sqrt(i1i1)) / sqrt(i2i2);
      if (corr > priv_max_corr)
      {
        priv_max_corr = corr;
        priv_max_r = r;
      }

      if (rank == 0)
        fprintf(stderr, "\rFinished r = %d/%d", r, quat->num_rot);

    }

    {
      if (priv_max_corr > max_corr)
      {
        max_corr = priv_max_corr;
        max_r = priv_max_r;
      }

    }
    free(rotmodel);
  }
  printf("\nMax corr = %f for max_r = %d\n", max_corr, max_r);
  printf("Orientation for max corr = %d: %.9f %.9f %.9f %.9f\n", max_r, quat->quat[max_r * 5], quat->quat[(max_r * 5) + 1], quat->quat[(max_r * 5) + 2], quat->quat[(max_r * 5) + 3]);
}

