{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
void f(int n, int a[*]);
void f(int n, int a[n])
{
  for (int i = 0; i < n; i++)
  {
    if (a[i] != org[i])
    {
      #pragma omp critical
      errors++;
    }

  }


  double **data;
  int N;
  int M;
} Matrix;
{
  Matrix mat;
  int b_vec_index;
} MatrixAugmented;
void gauss_reduce_partial_pivot_parallel(MatrixAugmented *augmat, int thread_count)
{
  Matrix *mat = &augmat->mat;
  int aug_col_size = mat->M;
  int aug_row_size = mat->N;
  double multiplier = 1;
  double greatest_value = 0;
  int greatest_val_row_id = 0;
  int row = 0;
  int pivot = 0;
  int k = 0;
  for (pivot = 0; pivot < ((aug_col_size < aug_row_size) ? (aug_col_size) : (aug_row_size)); ++pivot)
  {
    greatest_value = mat->data[pivot][pivot];
    greatest_val_row_id = pivot;
    #pragma omp parallel num_threads(thread_count) shared(mat, pivot, greatest_value, greatest_val_row_id, aug_col_size) private(row, multiplier, k)
    {
      #pragma omp for schedule(static, 1)
      for (row = pivot + 1; row < aug_col_size; ++row)
      {
        if (labs(greatest_value) < labs(mat->data[row][pivot]))
        {
          {
            if (labs(greatest_value) < labs(mat->data[row][pivot]))
            {
              greatest_value = mat->data[row][pivot];
              greatest_val_row_id = row;
            }

          }
        }

      }

    }
    if (greatest_value == 0)
    {
      printf("ERROR: Pivot was found to be 0.. this system is not solvable with only gaussian elimination \n");
    }

    if (greatest_val_row_id != pivot)
    {
      double *tmp_greatest_coef_row_ptr = mat->data[greatest_val_row_id];
      mat->data[greatest_val_row_id] = mat->data[pivot];
      mat->data[pivot] = tmp_greatest_coef_row_ptr;
      tmp_greatest_coef_row_ptr = 0;
    }

    #pragma omp parallel num_threads(thread_count) shared(mat, pivot, aug_col_size) private(row, multiplier, k)
    {
      #pragma omp for schedule(static, 1)
      for (row = pivot + 1; row < aug_col_size; ++row)
      {
        multiplier = mat->data[row][pivot] / mat->data[pivot][pivot];
        for (k = pivot; k < aug_row_size; ++k)
        {
          mat->data[row][k] -= mat->data[pivot][k] * multiplier;
        }

      }

    }
  }

}

