void generateParticleImage_omp(float *output_image, int num_rows, int num_cols, int num_particles, float *X, float *Y, float *particle_diameters, float *particle_max_intensities, int max_num_threads)
{
  int i;
  int k = 0;
  #pragma omp parallel
  {
    printf("parallel\n");
    #pragma omp for
    for (i = 0; i < 4; ++i)
    {
      printf("for %d\n", i);
      k++;
    }

    #pragma omp flush(k)
    #pragma omp barrier
    #pragma omp for ordered
    for (i = 0; i < 4; ++i)
    {
      #pragma omp ordered
      {
        printf("for %d\n", i);
      }
    }

    #pragma omp sections
    {
      #pragma omp section
      printf("section 1\n");
      #pragma omp section
      {
        printf("section 2\n");
      }
    }
    #pragma omp master
    {
      printf("master\n");
    }
    #pragma omp critical
    {
      printf("critical\n");
    }
    #pragma omp critical(foobar)
    {
      printf("critical(foobar)\n");
    }
    #pragma omp atomic
    i += 1;
    #pragma omp single
    {
      printf("single\n");
    }
  }
  #pragma omp parallel
  {
    #pragma omp task
    {
      printf("task\n");
    }
    #pragma omp taskwait
  }

  int p;
  int r;
  int c;
  int ind;
  int thread_id;
  int k;
  float *output_image_private;
  double render_radius;
  int minRenderedCol;
  int maxRenderedCol;
  int minRenderedRow;
  int maxRenderedRow;
  int render_particle;
  int render_pixel;
  int num_pixels = num_rows * num_cols;
  #pragma omp parallel private(thread_id, output_image_private)
  {
    thread_id = omp_get_thread_num();
    printf("Allocating %d pixels for thread %d...\n", num_pixels, thread_id);
    output_image_private = calloc(num_pixels, sizeof(float));
    if (output_image_private == 0)
    {
      printf("Couldn't allocate memory for thread %d\n", thread_id);
    }

    #pragma omp for
    for (p = 0; p < num_particles; p++)
    {
      minRenderedCol = (int) floor(X[p] - (0.75 * particle_diameters[p]));
      maxRenderedCol = (int) ceil(X[p] + (0.75 * particle_diameters[p]));
      minRenderedRow = (int) floor(Y[p] - (0.75 * particle_diameters[p]));
      maxRenderedRow = (int) ceil(Y[p] + (0.75 * particle_diameters[p]));
      render_particle = (((minRenderedCol <= (num_cols - 1)) & (maxRenderedCol >= 0)) & (minRenderedRow <= (num_rows - 1))) & (maxRenderedRow >= 0);
      if (render_particle)
      {
        for (r = minRenderedRow; r <= maxRenderedRow; r++)
        {
          for (c = minRenderedCol; c <= maxRenderedCol; c++)
          {
            render_radius = sqrt(pow(c - X[p], 2) + pow(r - Y[p], 2));
            render_pixel = ((((c >= 0) & (c <= ((*num_cols) - 1))) & (r >= 0)) & (r <= ((*num_rows) - 1))) & (render_radius <= (0.75 * particle_diameters[p]));
            if (render_pixel)
            {
              ind = r + (num_rows * c);
              output_image_private[ind] += (((((particle_max_intensities[p] * particle_diameters[p]) * particle_diameters[p]) * 3.141592653589793) / 32) * (erf((2.82842712475 * ((c - X[p]) - 0.5)) / particle_diameters[p]) - erf((2.82842712475 * ((c - X[p]) + 0.5)) / particle_diameters[p]))) * (erf((2.82842712475 * ((r - Y[p]) - 0.5)) / particle_diameters[p]) - erf((2.82842712475 * ((r - Y[p]) + 0.5)) / particle_diameters[p]));
            }

          }

        }

      }

    }

    {
      printf("Adding result from thread %d...\n", thread_id);
      for (k = 0; k < num_pixels; k++)
      {
        output_image[k] += output_image_private[k];
      }

    }
    free(output_image_private);
  }
  return;
}

