int main(int argc, char **argv)
{
  if (argc < 2)
  {
    fprintf(stderr, "Falta fila y columna\n");
    exit(-1);
  }

  struct timespec;
  double ncgt;
  double cgt1;
  double cgt2;
  int i;
  int k;
  int n = atoi(argv[1]);
  int h;
  double sumalocal = 0;
  double **m;
  double **m2;
  double **res;
  m = (double **) malloc(n * (sizeof(double *)));
  m2 = (double **) malloc(n * (sizeof(double *)));
  res = (double **) malloc(n * (sizeof(double *)));
  for (i = 0; i < n; ++i)
    m[i] = (double *) malloc(n * (sizeof(double)));

  for (i = 0; i < n; ++i)
    m2[i] = (double *) malloc(n * (sizeof(double)));

  for (i = 0; i < n; ++i)
    res[i] = (double *) malloc(n * (sizeof(double)));

  #pragma omp parallel for private(k)
  for (i = 0; i < n; i++)
  {
    for (k = 0; k < n; ++k)
    {
      m[i][k] = 2;
      m2[i][k] = 3;
      res[i][k] = 0;
    }

  }

  #pragma omp parallel private(k,i,sumalocal)
  {
    #pragma omp single
    cgt1 = omp_get_wtime();
    #pragma omp for
    for (h = 0; h < n; h++)
    {
      for (i = 0; i < n; i++)
      {
        for (k = 0; k < n; ++k)
        {
          sumalocal += m[i][k] * m2[k][h];
        }

        {
          res[h][i] = sumalocal;
          sumalocal = 0;
        }
      }

    }

    #pragma omp single
    cgt2 = omp_get_wtime();
  }
  ncgt = cgt2 - cgt1;
  printf("Tiempo(seg.):%11.9f\t / Tamaño Matrices:%u\n", ncgt, n);
  for (h = 0; h < n; h++)
  {
    for (i = 0; i < n; i++)
    {
      for (k = 0; k < n; ++k)
      {
        printf("/ m[%d][%d]*m2[%d][%d] (%8.6f*%8.6f) + \n", i, k, k, h, m[i][k], m2[k][h]);
      }

      printf("= res[%i][%i] =%8.2f/ \n", h, i, res[h][i]);
    }

  }

  for (i = 0; i < n; ++i)
  {
    free(m[i]);
  }

  for (i = 0; i < n; ++i)
  {
    free(m2[i]);
  }

  for (i = 0; i < n; ++i)
    free(res[i]);

  free(m);
  free(m2);
  free(res);
}

