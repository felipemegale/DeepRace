double Obersumme_crit(int stripes)
{
  int i;
  int nbMaxLocaux = 0;
  float tab[2048];
  float max[2048];
  for (i = 0; i < 2048; i++)
  {
    tab[i] = (rand() % 50000) / ((rand() % 100) + 1);
    max[i] = 0;
  }

  #pragma omp parallel for
  for (i = 1; i < (2048 - 1); ++i)
  {
    if ((tab[i - 1] < tab[i]) && (tab[i] > tab[i + 1]))
    {
      #pragma omp critical
      max[i] = tab[i];
      nbMaxLocaux++;
    }

  }

  return 0;

  double n = stripes;
  double Ergebnis = 0;
  #pragma omp parallel for
  for (int i = 0; i <= (stripes - 1); i++)

  Ergebnis = Ergebnis + ((1 / n) * sqrt(1 - pow(i / n, 2)));
  return 4 * Ergebnis;
}

