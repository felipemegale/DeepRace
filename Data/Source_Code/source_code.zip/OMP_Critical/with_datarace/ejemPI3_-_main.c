int main(int argc, char *argv[])
{
  int nprocs;
  int myproc;
  int i;
  int n;
  double pi_25 = 3.141592653589793238462643;
  double pi;
  double sumpi;
  double w;
  double x;
  double y;
  double error;
  double t0;
  double t1;
  if (argc == 2)
  {
    sscanf(argv[1], "%d", &n);
  }
  else
  {
    printf("Enter the number of intervals: (0 quits) ");
    fflush(stdout);
    scanf("%d", &n);
  }

  omp_set_num_threads(3);
  #pragma omp parallel private(myproc,w,x,y,i,pi,t0,t1) shared(nprocs,n,sumpi)
  {
    nprocs = omp_get_num_threads();
    myproc = omp_get_thread_num();
    if (myproc == 0)
      printf("Calculating pi using %d divisions\n", n);

    pi = 0.0;
    sumpi = 0.0;
    w = 1.0 / n;
    #pragma omp barrier
    t0 = omp_get_wtime();
    #pragma omp for
    for (i = 0; i < n; i++)
    {
      x = ((double) i) / n;
      y = sqrt(1.0 - (x * x));
      pi = pi + (y * w);
    }

    {
      sumpi += pi;
    }
    #pragma omp barrier
    if (myproc == 0)
      sumpi = sumpi * 4;

    error = fabs(sumpi - pi_25);
    t1 = omp_get_wtime();
    if (myproc == 0)
    {
      printf("The calculated pi = %f (error = %f)\n", sumpi, error);
      printf("The calculation took %f seconds on %d nodes\n", t1 - t0, nprocs);
    }

  }
  return 0;

  double time_taken = omp_get_wtime();
  int parallel_size = num_steps / 4;
  double pi;
  double sum = 0.0;
  step = 1.0 / ((double) num_steps);
  #pragma omp parallel num_threads(NUM_THREADS)
  {
    int id = omp_get_thread_num();
    double x = 0.0;
    double sum_array = 0.0;
    for (int i = id * parallel_size; i < ((id + 1) * parallel_size); i++)
    {
      x = (i + 0.5) * step;
      sum_array += 4.0 / (1.0 + (x * x));
    }

    #pragma omp critical
    sum += sum_array;
  }
  pi = sum * step;
  time_taken = omp_get_wtime() - time_taken;
  printf("The parallel pi value using critical: %f and time taken : %f \n", pi, time_taken);
}

