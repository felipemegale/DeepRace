long long int total_number_of_tosses;
long long int tosses_per_thread;
long long int number_in_circle = 0;
int thread_count;
int main()
{
  double pi_estimate;
  printf("Enter number of threads and the total number of tosses: ");
  scanf("%d%lld", &thread_count, &total_number_of_tosses);
  srand((long) time(0));
  while ((total_number_of_tosses % thread_count) != 0)
  {
    total_number_of_tosses++;
  }

  tosses_per_thread = total_number_of_tosses / thread_count;
  #pragma omp parallel num_threads(thread_count)
  {
    double x;
    double y;
    double distance_squared;
    int toss;
    int number_in_circle_in_thread = 0;
    for (toss = 0; toss < tosses_per_thread; toss++)
    {
      x = rand_double();
      y = rand_double();
      distance_squared = (x * x) + (y * y);
      if (distance_squared <= 1)
        number_in_circle_in_thread++;

    }

    number_in_circle += number_in_circle_in_thread;
  }
  pi_estimate = (4 * number_in_circle) / ((double) total_number_of_tosses);
  printf("Estimated pi = %f\n", pi_estimate);
  return 0;

  int thread_num;
  int pub;
  int priv;
  int sense;
  int total;
  int sense1;
  int count;
  int i;
  int k = 0;
  int time_spent;
  double start;
  double stop;
  int NUM_THREADS = atoi(argv[1]);
  for (i = 0; i < 1000; i++)
  {
    printf("\n***BARRIER %d***\n", i);
    sense = 0;
    total = -1;
    pub = 0;
    thread_num = -1;
    #pragma omp parallel num_threads(NUM_THREADS) firstprivate(thread_num, priv, start, stop) shared(pub, count, sense)
    {
      thread_num = omp_get_thread_num();
      #pragma omp critical
      {
        if (total == (-1))
        {
          count = omp_get_num_threads();
          total = omp_get_num_threads();
        }

      }
      while (total == (-1))
        ;

      printf("\nthread %d: hello", thread_num);
      #pragma omp critical
      {
        pub += thread_num;
      }
      k = 0;
      while (k < 10000000)
        k++;

      start = omp_get_wtime();
      sense_reversing_barrier(&count, &sense, total);
      stop = omp_get_wtime();
      printf("\nthread %d: final value of pub = %d", thread_num, pub);
      time[thread_num] += stop - start;
    }
  }

  for (k = 0; k < 8; k++)
  {
    if (time[k] > 0)
      printf("\nTime taken by thread no. %d across barriers: %lf", k, time[k]);

  }

  return 0;
}

