struct Graph
{
  int nVertices;
  int *nArestas;
  int **arestas;
  int **w;
};
int *dijkstra(struct Graph *graph, int source)
{
  int nVisitados = 0;
  int nVertices = graph->nVertices;
  int *visitados = (int *) malloc((sizeof(int)) * nVertices);
  int *l = (int *) malloc((sizeof(int)) * nVertices);
  int k;
  int v;
  for (v = 0; v < nVertices; v++)
  {
    l[v] = 32767;
    visitados[v] = 0;
  }

  l[source] = 0;
  for (v = 0; v < nVertices; v++)
  {
    int min = 0;
    int minValue = 32767;
    #pragma omp parallel
    {
      int minL = 0;
      int minValueL = 32767;
      #pragma omp for
      for (k = 0; k < nVertices; k++)
        if ((visitados[k] == 0) && (l[k] < minValue))
      {
        minValueL = l[k];
        minL = k;
      }


      if (minValueL < minValue)
      {
        minValue = minValueL;
        min = minL;
      }

      visitados[min] = 1;
      #pragma omp for
      for (k = 0; k < graph->nArestas[min]; k++)
      {
        int dest = graph->arestas[min][k];
        if (l[dest] > (l[min] + graph->w[min][k]))
          l[dest] = l[min] + graph->w[min][k];

      }

    }
  }

  free(visitados);
  return l;
}

