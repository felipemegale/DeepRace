double start_time;
double end_time;
int numWorkers;
int size;
struct Minmax
{
  int value;
  int column;
  int row;
};
int main(int argc, char *argv[])
{
  int i;
  int j;
  long total = 0;
  size = (argc > 1) ? (atoi(argv[1])) : (10000000);
  numWorkers = (argc > 2) ? (atoi(argv[2])) : (8);
  if (size > 10000000)
    size = 10000000;

  if (numWorkers > 8)
    numWorkers = 8;

  int **matrix = (int **) malloc(size * (sizeof(int *)));
  for (i = 0; i < size; i++)
  {
    matrix[i] = (int *) malloc(size * (sizeof(int)));
  }

  int threads = omp_get_max_threads();
  printf("Thread limit: %d\n", threads);
  omp_set_num_threads(numWorkers);
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      matrix[i][j] = rand() % 99;
    }

  }

  struct Minmax min = {matrix[0][0], 0, 0};
  ;
  struct Minmax max = {matrix[0][0], 0, 0};
  start_time = omp_get_wtime();
  #pragma omp parallel for reduction (+:total) private(j)
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      total += matrix[i][j];
      if (min.value > matrix[i][j])
      {
        if (min.value > matrix[i][j])
        {
          min.value = matrix[i][j];
          min.row = i;
          min.column = j;
        }

      }

      if (max.value < matrix[i][j])
      {
        if (max.value < matrix[i][j])
        {
          max.value = matrix[i][j];
          max.row = i;
          max.column = j;
        }

      }

    }

  }

  end_time = omp_get_wtime();
  printf("the total is %ld\n", total);
  printf("the maximum is %d ; its position is [%d][%d]\n", max.value, max.row, max.column);
  printf("the minimum is %d ; its position is [%d][%d]\n", min.value, min.row, min.column);
  printf("it took %f seconds\n", end_time - start_time);
  free(matrix);
}

