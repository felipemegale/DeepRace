static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt[1024];
void func1(int magicno, int *prvt)
{
  struct timeval t0;
  struct timeval t1;
  double tej;
  int IMA[1000][1000];
  int histo[256];
  int B[1000];
  int C[1000];
  int histop[256];
  int i;
  int j;
  int tid;
  int hmin;
  int imin;
  int spm = 0;
  int x;
  for (i = 0; i < 1000; i++)
    for (j = 0; j < 1000; j++)
    IMA[i][j] = rand() % 256;


  printf("\n Matriz IMA ");
  for (i = 0; i < 10; i++)
  {
    printf("\n");
    for (j = 0; j < 10; j++)
      printf(" %3d", IMA[i][j]);

    printf("\n");
  }

  for (i = 0; i < 256; i++)
    histo[i] = 0;

  gettimeofday(&t0, 0);
  #pragma omp parallel private (histop,j)
  {
    for (i = 0; i < 256; i++)
      histop[i] = 0;

    #pragma omp for
    for (i = 0; i < 1000; i++)
      for (j = 0; j < 1000; j++)
      histo[IMA[i][j]]++;


    #pragma omp critical
    {
      for (i = 0; i < 256; i++)
        histo[i] = histo[i] + histop[i];

      printf("ejecutando hilo\n");
    }
    hmin = (1000 * 1000) + 1;
    #pragma omp critical
    for (i = 0; i < 256; i++)
      if (hmin > histo[i])
    {
      hmin = histo[i];
      imin = i;
    }


    #pragma omp for reduction (+:spm) private (x,j)
    for (i = 0; i < 1000; i++)
    {
      j = 0;
      x = 0;
      while ((IMA[i][j] != imin) && (j < 1000))
      {
        x = x + IMA[i][j];
        j++;
      }

      B[i] = x;
      C[i] = j;
      spm = spm + j;
    }

  }
  gettimeofday(&t1, 0);
  printf("\n Histograma \n");
  for (i = 0; i < 10; i++)
    printf("%5d", i);

  printf("\n");
  for (i = 0; i < 10; i++)
    printf("%5d", histo[i]);

  printf("\n hmin = %d imin = %d\n", hmin, imin);
  printf("\n Vector B \n");
  for (i = 0; i < 10; i++)
    printf(" %3d", B[i]);

  printf("\n Vector C \n");
  for (i = 0; i < 10; i++)
    printf(" %3d", C[i]);

  printf("\n SPM = %d\n\n", spm);
  tej = (t1.tv_sec - t0.tv_sec) + ((t1.tv_usec - t0.tv_usec) / 1e6);
  printf("\n T. ejec. (serie) = %1.3f ms \n\n", tej * 1000);

  int id = omp_get_thread_num();
  int i;
  for (i = 0; i < 1024; i++)
  {
    if (prvt[i] != (magicno + i))
    {
      errors += 1;
    }

  }

  for (i = 0; i < 1024; i++)
  {
    prvt[i] = id + i;
  }

  #pragma omp barrier
  for (i = 0; i < 1024; i++)
  {
    if (prvt[i] != (id + i))
    {
      errors += 1;
    }

  }

}

