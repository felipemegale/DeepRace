static char rcsid[] = "$Id$";
int errors = 0;
int thds;
short prvt;
void func2(int magicno)
{
  int tid;
  int i;
  #pragma omp parallel private(tid)
  {
    tid = omp_get_thread_num();
    sleep(2);
    printf("to ja z numerem %d, i = %d\n", tid, i);
    #pragma omp critical
    {
      sleep(2);
      printf("sekcja:critical, to ja numer %d\n", tid);
    }
    #pragma ompe barrier
    #pragma omp master
    {
      sleep(2);
      printf("sekcja:master, to ja numer %d\n", tid);
    }
  }
  return 0;

  static int err;
  int id = omp_get_thread_num();
  if (prvt != magicno)
  {
    errors += 1;
  }

  #pragma omp barrier
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    errors++;
  }

}

