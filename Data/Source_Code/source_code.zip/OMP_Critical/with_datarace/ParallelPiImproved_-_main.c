static long num_steps = 100000;
double step;
void main()
{
  double pi = 0.0;
  int t;
  struct timeval start;
  struct timeval end;
  step = 1.0 / ((double) num_steps);
  omp_set_num_threads(2);
  gettimeofday(&start, 0);
  #pragma omp parallel
  {
    int i;
    int nthreads;
    int id;
    int nthrds;
    double x;
    double sum;
    id = omp_get_thread_num();
    nthrds = omp_get_num_threads();
    if (id == 0)
    {
      nthreads = nthrds;
    }

    for (i = id, sum = 0.0; i < num_steps; i = i + nthrds)
    {
      x = (i + 0.5) * step;
      sum += 4.0 / (1.0 + (x * x));
    }

    pi += sum * step;
  }
  gettimeofday(&end, 0);
  double delta = ((((end.tv_sec - start.tv_sec) * 1000000u) + end.tv_usec) - start.tv_usec) / 1.e6;
  printf("Time before : %lf\n", delta);
  printf("The value of PI : %lf\n", pi);
}

