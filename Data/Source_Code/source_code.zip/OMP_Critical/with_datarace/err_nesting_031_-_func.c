static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int sum;
void func()
{
  {
    #pragma omp ordered
    {
      sum += 1;
    }
  }
}

