double *rows_before_cost = 0;
int ccrow(int outer_iter_num, int inner_iter_num)
{
  static int err;
  int id = omp_get_thread_num();
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    #pragma omp critical
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    #pragma omp critical
    errors++;
  }

  if ((sizeof(prvt)) != (sizeof(double)))
  {
    #pragma omp critical
    errors += 1;
  }


  int idx;
  int idx2;
  int chunk;
  int tid;
  int new_row_label;
  int offset;
  uint64_t *local_g = 0;
  uint64_t *tmp_global_g = 0;
  int *rows_selected = 0;
  int rows_in_group;
  int cols_in_group;
  uint64_t num1;
  uint64_t num0;
  double before_cost = 0;
  struct timeval stime;
  struct timeval etime;
  double sec_elapsed = 0;
  gettimeofday(&stime, 0);
  chunk = nsamples / row_max_threads;
  omp_set_num_threads(row_max_threads);
  bs_msg("[ccrow.%d.%d] %d row / %d col", outer_iter_num, inner_iter_num, global_rnum, global_cnum);
  if ((rows_before_cost = (double *) malloc(global_rnum * (sizeof(double)))) == 0)
  {
    perror("rows_before_cost malloc()");
    exit(1);
  }

  for (idx = 0; idx < global_rnum; idx++)
  {
    rows_in_group = rows_in_each_group[idx];
    before_cost = 0;
    for (idx2 = 0; idx2 < global_cnum; idx2++)
    {
      cols_in_group = cols_in_each_group[idx2];
      num1 = global_g[(idx * global_cnum) + idx2];
      num0 = (((uint64_t) rows_in_group) * cols_in_group) - num1;
      if ((num1 != 0) && (num0 != 0))
        before_cost += (num1 * log2((num1 + num0) / ((double) num1))) + (num0 * log2((num1 + num0) / ((double) num0)));

    }

    rows_before_cost[idx] = before_cost;
  }

  if ((local_g = (uint64_t *) malloc((sizeof(uint64_t)) * ((global_cnum * global_rnum) * row_max_threads))) == 0)
  {
    perror("local_g malloc()");
    exit(1);
  }

  if ((tmp_global_g = (uint64_t *) calloc(global_cnum * global_rnum, sizeof(uint64_t))) == 0)
  {
    perror("tmp_global_g calloc()");
    exit(1);
  }

  if ((rows_selected = (int *) calloc(global_rnum, sizeof(int))) == 0)
  {
    perror("rows_removed calloc()");
    exit(1);
  }

  #pragma omp parallel default(shared) private(tid)
  {
    tid = omp_get_thread_num();
    memset(local_g + ((tid * global_cnum) * global_rnum), 0, ((sizeof(uint64_t)) * global_cnum) * global_rnum);
  }
  #pragma omp parallel default(shared) private(tid)
  {
    int i;
    int j;
    tid = omp_get_thread_num();
    bitshred_t * thread_bs_fp;
    uint64_t *thread_local_g;
    int sample_id;
    uint32_t byteIndex;
    uint8_t bitMask;
    uint64_t *row_stat = 0;
    int cur_row_label;
    int opt_row_label;
    thread_bs_fp = bs_fp + (tid * chunk);
    thread_local_g = local_g + ((tid * global_cnum) * global_rnum);
    if ((row_stat = (uint64_t *) malloc((sizeof(uint64_t)) * global_cnum)) == 0)
    {
      perror("row_stat malloc()");
      exit(1);
    }

    for (i = 0; i < chunk; i++)
    {
      memset(row_stat, 0, (sizeof(uint64_t)) * global_cnum);
      sample_id = (tid * chunk) + i;
      for (j = 0; j < (FP_SIZE * 8); j++)
      {
        byteIndex = j >> 3;
        bitMask = 1 << (j & 0x00000007);
        if ((thread_bs_fp + i)->bit_vector[byteIndex] & bitMask)
        {
          row_stat[global_c[j]] += 1;
        }

      }

      cur_row_label = global_r[sample_id];
      opt_row_label = opt_row_group(cur_row_label, row_stat);
      global_r[sample_id] = opt_row_label;
      if (!rows_selected[opt_row_label])
      {
        rows_selected[opt_row_label] = 1;
      }

      for (j = 0; j < global_cnum; j++)
        thread_local_g[(opt_row_label * global_cnum) + j] += row_stat[j];

    }

    free(row_stat);
  }
  for (tid = 0; tid < row_max_threads; tid++)
  {
    offset = (tid * global_cnum) * global_rnum;
    for (idx = 0; idx < (global_cnum * global_rnum); idx++)
      tmp_global_g[idx] += local_g[offset + idx];

  }

  new_row_label = 0;
  for (idx = 0; idx < global_rnum; idx++)
  {
    if (rows_selected[idx])
    {
      for (idx2 = 0; idx2 < global_cnum; idx2++)
        global_g[(new_row_label * global_cnum) + idx2] = tmp_global_g[(idx * global_cnum) + idx2];

      rows_selected[idx] = new_row_label;
      new_row_label++;
    }

  }

  memset(rows_in_each_group, 0, (sizeof(unsigned int)) * global_rnum);
  global_rnum = new_row_label;
  for (idx = 0; idx < nsamples; idx++)
  {
    global_r[idx] = rows_selected[global_r[idx]];
    rows_in_each_group[global_r[idx]] += 1;
  }

  bs_msg(" ... %d row / %d col", global_rnum, global_cnum);
  gettimeofday(&etime, 0);
  sec_elapsed = time_diff(etime, stime);
  bs_msg(" @ %um %.1fs\n", ((unsigned int) sec_elapsed) / 60, (sec_elapsed - ((unsigned int) sec_elapsed)) + (((unsigned int) sec_elapsed) % 60));
  free(local_g);
  free(tmp_global_g);
  free(rows_selected);
  free(rows_before_cost);
  return 0;
}

