void FCIspindm12_drv(void (*dm12kernel)(), double *rdm1, double *rdm2, double *bra, double *ket, int norb, int na, int nb, int neleca, int nelecb, int *link_indexa, int *link_indexb, int symm)
{
  const int nnorb = norb * norb;
  int strk;
  int i;
  int j;
  double *pdm1;
  double *pdm2;
  memset(rdm1, 0, (sizeof(double)) * nnorb);
  memset(rdm2, 0, ((sizeof(double)) * nnorb) * nnorb);
  #pragma omp parallel default(none) shared(dm12kernel, bra, ket, norb, na, nb, neleca, nelecb, link_indexa, link_indexb, rdm1, rdm2), private(strk, i, pdm1, pdm2)
  {
    pdm1 = (double *) malloc((sizeof(double)) * nnorb);
    pdm2 = (double *) malloc(((sizeof(double)) * nnorb) * nnorb);
    memset(pdm1, 0, (sizeof(double)) * nnorb);
    memset(pdm2, 0, ((sizeof(double)) * nnorb) * nnorb);
    #pragma omp for schedule(static, 40)
    for (strk = 0; strk < na; strk++)
    {
      (*dm12kernel)(pdm1, pdm2, bra, ket, strk, norb, na, nb, neleca, nelecb, link_indexa, link_indexb);
    }

    {
      for (i = 0; i < nnorb; i++)
      {
        rdm1[i] += pdm1[i];
      }

      for (i = 0; i < (nnorb * nnorb); i++)
      {
        rdm2[i] += pdm2[i];
      }

    }
    free(pdm1);
    free(pdm2);
  }
  if (symm)
  {
    for (i = 0; i < norb; i++)
    {
      for (j = 0; j < i; j++)
      {
        rdm1[(j * norb) + i] = rdm1[(i * norb) + j];
      }

    }

    for (i = 0; i < nnorb; i++)
    {
      for (j = 0; j < i; j++)
      {
        rdm2[(j * nnorb) + i] = rdm2[(i * nnorb) + j];
      }

    }

  }

  _transpose_jikl(rdm2, norb);

  double value;
  double time;
} data;
void parallel_compute(data *par_data, double a, double b, int n, int thread_count);
void serial_compute(data *ser_data, double a, double b, int n);
void serial_compute(data *ser_data, double a, double b, int n)
{
  ser_data->time = 0.0;
  ser_data->value = 0.0;
  double iTime = omp_get_wtime();
  #pragma omp parallel num_threads(1)
  {
    double my_result = 0.0;
    my_result += Trap(a, b, n, 0);
    #pragma omp critical
    ser_data->value += my_result;
  }
  #pragma omp barrier
  ser_data->time = omp_get_wtime() - iTime;
}

