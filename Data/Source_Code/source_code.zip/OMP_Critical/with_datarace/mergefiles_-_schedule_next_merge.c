void init_merger(int new_max_ngram_string_length);
void schedule_next_merge(int k, int n, int rightmost_run, uint8_t (*scheduling_table)[(2 * MAX_BUFFERS) - 1], const char *prefix);
int get_final_k();
static void merge_next(int k, int n, int rightmost_run, uint8_t (*scheduling_table)[(2 * MAX_BUFFERS) - 1], const char *prefix);
static void copy_rest_of_file_to_output(FILE *input, off_t inputsize, FILE *output);
int merge_files(FILE *in_first, off_t first_size, FILE *in_second, off_t second_size, FILE *out, int max_ngram_string_length);
static int max_k = 0;
static int max_ngram_string_length = 40;
void schedule_next_merge(int k, int n, int rightmost_run, uint8_t (*scheduling_table)[(2 * MAX_BUFFERS) - 1], const char *prefix)
{
  if (n > MAX_BUFFERS)
  {
    fprintf(stderr, "Maximum number of buffers filled. Try adjusting MAX_BUFFERS in config.h\n");
    exit(-1);
  }

  int other_n;
  if (n && rightmost_run)
  {
    int other_k = k;
    other_n = n - 1;
    while (other_n && (other_n % 2))
    {
      other_n = (other_n - 1) / 2;
      other_k++;
    }

    if (other_n != (n - 1))
    {
      char *old_directory_name = malloc(((((strlen(prefix) + 1) + 4) + 1) + 4) + 1);
      char *new_directory_name = malloc(((((strlen(prefix) + 1) + 4) + 1) + 4) + 1);
      snprintf(old_directory_name, ((((strlen(prefix) + 1) + 4) + 1) + 4) + 1, "%s/%d_%d", prefix, k, n);
      snprintf(new_directory_name, ((((strlen(prefix) + 1) + 4) + 1) + 4) + 1, "%s/%d_%d", prefix, other_k, other_n + 1);
      recursively_remove_directory(new_directory_name);
      rename(old_directory_name, new_directory_name);
      n = other_n + 1;
      k = other_k;
      free(old_directory_name);
      free(new_directory_name);
    }

  }
  else
  {
    other_n = (n && (n % 2)) ? (n - 1) : (n + 1);
  }

  int run_next_merge;
  {
    if (k > max_k)
      max_k = k;

    if (!(run_next_merge = (*scheduling_table)[((2 * MAX_BUFFERS) - (MAX_BUFFERS / (1 << k))) + n]))
      (*scheduling_table)[((2 * MAX_BUFFERS) - (MAX_BUFFERS / (1 << k))) + other_n] = (rightmost_run) ? (2) : (1);

  }
  if (run_next_merge)
  {
    fprintf(stdout, "|");
    fflush(stdout);
    merge_next(k, n, rightmost_run || (run_next_merge == 2), scheduling_table, prefix);
    fprintf(stdout, "|");
    fflush(stdout);
  }

}

