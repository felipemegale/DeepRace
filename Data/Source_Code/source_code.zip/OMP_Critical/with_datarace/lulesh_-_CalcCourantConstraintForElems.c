enum {VolumeError = -1, QStopError = -2};
double *m_x;
double *m_y;
double *m_z;
double *m_xd;
double *m_yd;
double *m_zd;
double *m_xdd;
double *m_ydd;
double *m_zdd;
double *m_fx;
double *m_fy;
double *m_fz;
double *m_nodalMass;
int *m_symmX;
int *m_symmY;
int *m_symmZ;
int *m_nodeElemCount;
int *m_nodeElemStart;
int *m_nodeElemCornerList;
int *m_matElemlist;
int *m_nodelist;
int *m_lxim;
int *m_lxip;
int *m_letam;
int *m_letap;
int *m_lzetam;
int *m_lzetap;
int *m_elemBC;
double *m_dxx;
double *m_dyy;
double *m_dzz;
double *m_delv_xi;
double *m_delv_eta;
double *m_delv_zeta;
double *m_delx_xi;
double *m_delx_eta;
double *m_delx_zeta;
double *m_e;
double *m_p;
double *m_q;
double *m_ql;
double *m_qq;
double *m_v;
double *m_volo;
double *m_vnew;
double *m_delv;
double *m_vdov;
double *m_arealg;
double *m_ss;
double *m_elemMass;
double m_dtfixed;
double m_time;
double m_deltatime;
double m_deltatimemultlb;
double m_deltatimemultub;
double m_stoptime;
double m_u_cut;
double m_hgcoef;
double m_qstop;
double m_monoq_max_slope;
double m_monoq_limiter_mult;
double m_e_cut;
double m_p_cut;
double m_ss4o3;
double m_q_cut;
double m_v_cut;
double m_qlc_monoq;
double m_qqc_monoq;
double m_qqc;
double m_eosvmax;
double m_eosvmin;
double m_pmin;
double m_emin;
double m_dvovmax;
double m_refdens;
double m_dtcourant;
double m_dthydro;
double m_dtmax;
int m_cycle;
int m_sizeX;
int m_sizeY;
int m_sizeZ;
int m_numElem;
int m_numNode;
inline static void CalcCourantConstraintForElems(int p_matElemlist[91125], double p_ss[91125], double p_vdov[91125], double p_arealg[91125])
{
  int i;
  double dtcourant = 1.0e+20;
  int courant_elem = -1;
  double qqc = m_qqc;
  int length = m_numElem;
  double qqc2 = (64.0 * qqc) * qqc;
  #pragma omp parallel for private(i) firstprivate(length,qqc2) shared(dtcourant,courant_elem)
  for (i = 0; i < length; ++i)
  {
    int indx = p_matElemlist[i];
    double dtf = p_ss[indx] * p_ss[indx];
    if (p_vdov[indx] < 0.)
    {
      dtf = dtf + ((((qqc2 * p_arealg[indx]) * p_arealg[indx]) * p_vdov[indx]) * p_vdov[indx]);
    }

    dtf = SQRT8(dtf);
    dtf = p_arealg[indx] / dtf;
    if (p_vdov[indx] != 0.)
    {
      if (dtf < dtcourant)
      {
        {
          dtcourant = dtf;
          courant_elem = indx;
        }
      }

    }

  }

  if (courant_elem != (-1))
  {
    m_dtcourant = dtcourant;
  }

  return;
}

