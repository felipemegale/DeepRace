void f2(void)
{
  bool found;
  int score = 0;
  for (int i = 0; i < N; i++)
  {
    found = 0;
    #pragma omp parallel shared(data,found)
    {
      #pragma omp for
      for (int j = N - 1; j > (-1); j--)
      {
        if ((data[i][0] == data[j][1]) && (data[i][1] == data[j][0]))
        {
          #pragma omp critical
          {
            score += 1;
            found = 1;
          }
          #pragma omp cancel for
        }

      }

    }
  }

  return score / 2;

  int i;
  #pragma omp parallel
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
    #pragma omp master
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp single
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp taskgroup
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp task
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp for
    for (i = 0; i < 10; i++)
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }

    #pragma omp for ordered
    for (i = 0; i < 10; i++)
      #pragma omp ordered

    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp sections
    {
      {
        #pragma omp cancel parallel
        #pragma omp cancel for
        #pragma omp cancel sections
        #pragma omp cancel taskgroup
        #pragma omp cancellation point parallel
        #pragma omp cancellation point for
        #pragma omp cancellation point sections
        #pragma omp cancellation point taskgroup
      }
      #pragma omp section
      {
        #pragma omp cancel parallel
        #pragma omp cancel for
        #pragma omp cancel sections
        #pragma omp cancel taskgroup
        #pragma omp cancellation point parallel
        #pragma omp cancellation point for
        #pragma omp cancellation point sections
        #pragma omp cancellation point taskgroup
      }
    }
    #pragma omp target data
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp target
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp target data
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp target
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp target teams
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp target teams distribute
  for (i = 0; i < 10; i++)
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }

  #pragma omp for
  for (i = 0; i < 10; i++)
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }

  #pragma omp for
  for (i = 0; i < 10; i++)
    #pragma omp target data

  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp for
  for (i = 0; i < 10; i++)
    #pragma omp target

  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp for ordered
  for (i = 0; i < 10; i++)
    #pragma omp ordered

  #pragma omp target data
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp for ordered
  for (i = 0; i < 10; i++)
    #pragma omp ordered

  #pragma omp target
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp sections
  {
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp section
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp sections
  {
    #pragma omp target data
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp section
    #pragma omp target data
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp sections
  {
    #pragma omp target
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp section
    #pragma omp target
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp task
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
    #pragma omp taskgroup
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
}

