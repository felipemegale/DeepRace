int arr[1024];
int main()
{
  int i;
  int max;
  omp_set_num_threads(8);
  init_arr();
  print_arr();
  max = arr[0];
  #pragma omp parallel for num_threads(4)
  for (i = 1; i < 1024; ++i)
  {
    {
      if (arr[i] > max)
        max = arr[i];

    }
  }

  printf("max = %d\n", max);
  return 0;
}

