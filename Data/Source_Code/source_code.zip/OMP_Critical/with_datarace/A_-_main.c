double arrayA[10000000];
double arrayB[10000000];
int main(int argc, char *argv[])
{
  long i;
  double start;
  double end;
  double prodEsc;
  double result = 0;
  omp_set_num_threads(8);
  srand(time(0));
  for (i = 0; i < 10000000; i++)
  {
    arrayA[i] = rand();
    arrayB[i] = rand();
  }

  start = omp_get_wtime();
  #pragma omp parallel for default(none) private(i, prodEsc), shared(arrayA, arrayB, result)
  for (i = 0; i < 10000000; i++)
  {
    prodEsc = arrayA[i] * arrayB[i];
    result += prodEsc;
  }

  end = omp_get_wtime();
  printf("Número de threads: %d\n", 8);
  printf("Tamanho do vetor: %d\n", 10000000);
  printf("Tempo decorrido: %.4g segundos\n", end - start);
  printf("Produto escalar = %f\n", result);
  return 0;
}

