double maxeps = 0.1e-7;
int itmax = 100;
int i;
int j;
int k;
double eps;
double A[(((((2 * 2) * 2) * 2) * 2) * 2) + 2][(((((2 * 2) * 2) * 2) * 2) * 2) + 2][(((((2 * 2) * 2) * 2) * 2) * 2) + 2];
void relax();
void init();
void verify();
void relax()
{
  int val;
  int prod;
  struct record_s *next_p;
};
struct buf_list
{
  struct record_s *head_p;
  struct record_s *tail_p;
};
struct buf_list *buff;
int *producers_done;
void Put(int rank, int data)
{
  struct record_s *rec_p;
  rec_p = Create_record(rank, data);
  #pragma omp critical(queue)
  {
    Enqueue(rank, rec_p);
  }
  #pragma omp critical(done)
  producers_done[rank]++;

  #pragma omp parallel for shared (A) private (i, j, k)
  for (j = 1; j <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); j++)
    for (i = 1; i <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); i++)
    for (k = 1; k <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); k++)
  {
    A[i][j][k] = (A[i - 1][j][k] + A[i + 1][j][k]) / 2.;
  }



  #pragma omp parallel for shared (A) private (i, j, k)
  for (i = 1; i <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); i++)
    for (j = 1; j <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); j++)
    for (k = 1; k <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); k++)
  {
    A[i][j][k] = (A[i][j - 1][k] + A[i][j + 1][k]) / 2.;
  }



  #pragma omp parallel for shared (A) private (i, j, k)
  for (i = 1; i <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); i++)
    for (j = 1; j <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); j++)
    for (k = 1; k <= (((((((2 * 2) * 2) * 2) * 2) * 2) + 2) - 2); k++)
  {
    double e;
    e = A[i][j][k];
    A[i][j][k] = (A[i][j][k - 1] + A[i][j][k + 1]) / 2.;
    e = fabs(e - A[i][j][k]);
    if (eps < e)
    {
      {
        eps = e;
      }
    }

  }



}

