static double num_steps = 1000000000;
double step;
double start;
double end;
int noomp();
int wiomp();
int wisomp();
int wisomp1();
int wisomp2();
int wisomp3();
int itr = 0;
int wisomp1()
{
  int n = 0;
  for (n = 8; n < 9; n++)
  {
    omp_set_num_threads(n);
    int i = 0;
    double pi = 0.0;
    step = 1.0 / ((double) num_steps);
    start = omp_get_wtime();
    #pragma omp parallel
    {
      double sum = 0.0;
      double x = 0.0;
      #pragma omp for schedule(dynamic,itr)
      for (i = 0; i < ((int) num_steps); i++)
      {
        x = (i + 0.5) * step;
        sum += 4.0 / (1.0 + (x * x));
      }

      pi += sum * step;
    }
    end = omp_get_wtime();
    printf("%d threads takes %f seconds to process dynamically, result is %f\n", n, end - start, pi);
  }

  return 0;
}

