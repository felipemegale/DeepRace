void jacobi_iterate(const int x, const int y, const int halo_depth, double *error, double *kx, double *ky, double *u0, double *u, double *r)
{
  #pragma omp target teams distribute parallel for collapse(2)
  for (int jj = 0; jj < y; ++jj)
  {
    for (int kk = 0; kk < x; ++kk)
    {
      const int index = kk + (jj * x);
      r[index] = u[index];
    }

  }

  const int nb = 512;
  double *reduce_temp = (double *) calloc(sizeof(double), nb);
  #pragma omp target teams distribute parallel for collapse(2) map(tofrom: reduce_temp[:nb])
  for (int jj = halo_depth; jj < (y - halo_depth); ++jj)
  {
    for (int kk = halo_depth; kk < (x - halo_depth); ++kk)
    {
      const int index = kk + (jj * x);
      u[index] = ((u0[index] + ((kx[index + 1] * r[index + 1]) + (kx[index] * r[index - 1]))) + ((ky[index + x] * r[index + x]) + (ky[index] * r[index - x]))) / ((1.0 + (kx[index] + kx[index + 1])) + (ky[index] + ky[index + x]));
      reduce_temp[omp_get_team_num()] += fabs(u[index] - r[index]);
    }

  }

  for (int ii = 0; ii < nb; ++ii)
  {
    *error += reduce_temp[ii];
  }

  free(reduce_temp);
}

