static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt;
void check_parallel(int n)
{
  if (n == 1)
  {
    if (omp_in_parallel() != 0)
    {
      errors += 1;
    }

    if (omp_get_num_threads() != 1)
    {
      errors += 1;
    }

  }
  else
  {
    if (omp_in_parallel() == 0)
    {
      errors += 1;
    }

    if (omp_get_num_threads() != n)
    {
      errors += 1;
    }

  }


  int tid;
  static double *p = 0;
  tid = omp_get_thread_num();
  printf("tid %d\n", tid);
  #pragma omp barrier
  if (tid == 0)
  {
    p = x;
  }

  #pragma omp barrier
  if (tid == 1)
  {
    p = y;
  }

  #pragma omp barrier
  #pragma omp critical
  {
    printf("func2 %d %f\n", tid, p[0]);
  }
}

