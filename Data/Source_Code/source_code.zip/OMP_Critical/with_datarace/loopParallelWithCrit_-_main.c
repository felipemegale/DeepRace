int main(int argc, char *argv[])
{
  int i;
  int data[500000];
  double result = 0.0;
  for (i = 0; i < 500000; i++)
  {
    data[i] = i * i;
  }

  #pragma omp parallel num_threads(2)
  for (i = 0; i < 500000; i++)
  {
    result += (sin(data[i]) - cos(data[i])) / sin(data[i] + cos(data[i]));
  }

  printf("Result = %f\n", result);

  char num_dice;
  char triple;
  char face[6];
} dice_t;
int main(int argc, char **argv)
{
  if (argc != 5)
  {
    printf("Error: Impropper usage.  %s <num games> <mincutoff> <maxcutoff> <num threads>\n", argv[0]);
    exit(0);
  }

  games = atoi(argv[1]);
  int mincutoff = atoi(argv[2]);
  int maxcutoff = atoi(argv[3]);
  int num_threads = atoi(argv[4]);
  printf("Playing %d games for each cutoff ranging from %d-%d using %d threads\n", games, mincutoff, maxcutoff, num_threads);
  unsigned long start = GetCC();
  long long total_inplay_throws[7];
  long long total_inplay_points[7];
  long long total_inplay_duds[7];
  long long max_turns = 0;
  long long min_turns = games * 10000;
  int max_cutoff;
  int min_cutoff;
  for (int i = 1; i < 7; i++)
  {
    total_inplay_throws[i] = 0;
    total_inplay_points[i] = 0;
    total_inplay_duds[i] = 0;
  }

  int thread_id;
  int c;
  int seed;
  omp_set_num_threads(num_threads);
  #pragma omp parallel
  #pragma omp private(thread_id, c)
  {
    thread_id = omp_get_thread_num();
    seed = thread_id;
    #pragma omp for schedule(dynamic, 1)
    for (c = mincutoff; c < maxcutoff; c += 50)
    {
      long long cutoffturns = 0;
      for (int i = 0; i < games; ++i)
      {
        long long inplay_duds[7];
        long long inplay_throws[7];
        long long inplay_points[7];
        for (int i = 1; i < 7; i++)
        {
          inplay_duds[i] = 0;
          inplay_throws[i] = 0;
          inplay_points[i] = 0;
        }

        int turns = play_game(c, inplay_throws, inplay_points, inplay_duds, &seed);
        #pragma omp critical (TOTAL_INPLAY)
        {
          for (int i = 1; i < 7; i++)
          {
            total_inplay_throws[i] += inplay_throws[i];
            total_inplay_points[i] += inplay_points[i];
            total_inplay_duds[i] += inplay_duds[i];
          }

        }
        cutoffturns += turns;
      }

      #pragma omp critical (RECORD)
      {
        if (cutoffturns > max_turns)
        {
          max_turns = cutoffturns;
          max_cutoff = c;
        }
        else
          if (cutoffturns < min_turns)
        {
          min_turns = cutoffturns;
          min_cutoff = c;
        }


      }
    }

  }
  unsigned long finish = GetCC();
  printf("Execution time in cycles: %lld\n", (long long) (finish - start));
  printf("\nPlayed %d games per cutoff leading to the folling statistics:\n", games);
  printf("\tBest Cutoff(%d) resulted in %.2f turns on average\n", min_cutoff, ((double) min_turns) / ((double) games));
  printf("\tWorst Cutoff(%d) resulted in %.2f turns on average\n", max_cutoff, ((double) max_turns) / ((double) games));
  for (int i = 1; i < 7; i++)
  {
    printf("\tAverage points accumualted with %d dice in play: %.2f\n", i, ((double) total_inplay_points[i]) / ((double) total_inplay_throws[i]));
  }

  for (int i = 1; i < 7; i++)
  {
    printf("\tProbability of throwing a dud with %d dice in play: %.2f\n", i, ((double) total_inplay_duds[i]) / ((double) total_inplay_throws[i]));
  }

  return 1;
}

