double input[1501][10];
double net_h[1501][5];
double output_h[1501][5];
double net_o[1501][5];
double output_o[1501][5];
double error[1501][10];
double Total_error[1501];
double TranningData[1501][31];
double weight[1501][12];
double weightTebakan[20];
double deltha_o[1501][2];
double devarative_o[1501][2];
double deltha_h[1501][2];
double devarative_h[1501][2];
int n;
int N;
int nN;
void getDataTrainning_fromFile(char *file);
double createNetwork(double w1, double w2, double w3, double i1, double i2, double b);
double output(double net);
double Error(double target, double out);
void Forward_Pass();
void Backward_Pass();
double dho_output(double out);
double compute_deltha(double target, double out);
double devarative_function_o(double deltha_i, double out);
double compute_deltha_h(double delthao1, double deltha_o2, double w1, double w2, double out);
double devarative_function_h(double deltha_h, double input);
void update_weigth(double alpha);
double update_weigth_function(double W, double learningrate, double devarative_f);
double sumError(double target, double out, double out2);
double mean_se();
void Forward_Pass()
{
  int i;
  int j;
  int e;
  printf("----------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
  printf(" %-11s | %-12s | %-12s | %-12s | %-12s | %-12s | %-12s | %-12s | %-12s | %-12s | %-12s |", "Net h1", "Out h1", "Net h2", "Out h2", "Net o1", "Out o1", "Net o2", "Out o2", "Eo1", "Eo2", "Etotal");
  printf("\n");
  printf("----------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
  double start = omp_get_wtime();
  #pragma omp parallel num_threads(8)
  {
    #pragma omp for schedule(dynamic,1)
    for (i = 1; i <= nN; i++)
    {
      for (j = 1; j <= 11; j++)
      {
        switch (j)
        {
          case 1:
            TranningData[i][j] = createNetwork(weightTebakan[1], weightTebakan[2], weightTebakan[3], input[i][2], input[i][3], 1);
            net_h[i][1] = TranningData[i][j];
            break;

          case 2:
            TranningData[i][j] = output(net_h[i][1]);
            output_h[i][1] = TranningData[i][j];
            break;

          case 3:
            TranningData[i][j] = createNetwork(weightTebakan[4], weightTebakan[5], weightTebakan[6], input[i][2], input[i][3], 1);
            net_h[i][2] = TranningData[i][j];
            break;

          case 4:
            TranningData[i][j] = output(net_h[i][2]);
            output_h[i][2] = TranningData[i][j];
            break;

          case 5:
            TranningData[i][j] = createNetwork(weightTebakan[7], weightTebakan[8], weightTebakan[9], output_h[i][1], output_h[i][2], 1);
            net_o[i][1] = TranningData[i][j];
            break;

          case 6:
            TranningData[i][j] = output(net_o[i][1]);
            output_o[i][1] = TranningData[i][j];
            break;

          case 7:
            TranningData[i][j] = createNetwork(weightTebakan[10], weightTebakan[11], weightTebakan[12], output_h[i][1], output_h[i][2], 1);
            net_o[i][2] = TranningData[i][j];
            break;

          case 8:
            TranningData[i][j] = output(net_o[i][2]);
            output_o[i][2] = TranningData[i][j];
            break;

          case 9:
            TranningData[i][j] = Error(input[i][4], output_o[i][1]);
            error[i][1] = TranningData[i][j];
            break;

          case 10:
            TranningData[i][j] = Error(input[i][4], output_o[i][2]);
            error[i][2] = TranningData[i][j];
            break;

          case 11:
            TranningData[i][j] = error[i][1] + error[i][2];
            Total_error[i] = TranningData[i][j];
            break;

        }

      }

      printf("Data ke-[%i] | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | %5.10lf | \n", i, TranningData[i][1], TranningData[i][2], TranningData[i][3], TranningData[i][4], TranningData[i][5], TranningData[i][6], TranningData[i][7], TranningData[i][8], TranningData[i][9], TranningData[i][10], TranningData[i][11]);
    }

  }
  double stop = omp_get_wtime() - start;
  printf("----------------------------------\n");
  printf("Waktu Eksekusi File    : %lf \n", stop);
  printf("----------------------------------\n");
}

