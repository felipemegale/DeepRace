int main(int argc, char **argv)
{
  double resultado;
  unsigned int N = 3;
  unsigned int i;
  unsigned int j;
  double cgt1;
  double cgt2;
  double ncgt;
  if (argc < 2)
  {
    printf("Faltan no componentes del vector\n");
    exit(-1);
  }

  N = atoi(argv[1]);
  double **matriz;
  double *v1;
  double *v2;
  v1 = (double *) malloc(N * (sizeof(double)));
  v2 = (double *) malloc(N * (sizeof(double)));
  matriz = (double **) malloc(N * (sizeof(double *)));
  for (i = 0; i < N; i++)
    matriz[i] = (double *) malloc(N * (sizeof(double)));

  #pragma omp parallel
  {
    #pragma omp for
    for (i = 0; i < N; i++)
      v1[i] = 2;

    #pragma omp for private(j)
    for (i = 0; i < N; i++)
    {
      for (j = 0; j < N; j++)
      {
        matriz[i][j] = 2;
      }

    }

  }
  cgt1 = omp_get_wtime();
  for (i = 0; i < N; i++)
  {
    resultado = 0;
    v2[i] = 0;
    #pragma omp parallel firstprivate(resultado)
    {
      #pragma omp for
      for (j = 0; j < N; j++)
      {
        resultado = resultado + (matriz[i][j] * v1[j]);
      }

      {
        v2[i] += resultado;
      }
    }
  }

  cgt2 = omp_get_wtime();
  ncgt = cgt2 - cgt1;
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\n", ncgt, N);
  printf("Vector resultadoado\n");
  for (i = 0; i < N; i++)
    printf("%f ", v2[i]);

  free(v1);
  free(v2);
  for (i = 0; i < N; i++)
    free(matriz[i]);

  free(matriz);
}

