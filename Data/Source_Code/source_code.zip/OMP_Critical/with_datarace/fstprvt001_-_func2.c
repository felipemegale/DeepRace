static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt;
void func2(int magicno)
{
  double A[order][diastasi][diastasi];
  double sum = 0;
  int i;
  int j;
  int k;
  for (i = 0; i < order; i++)
  {
    for (j = 0; j < diastasi; j++)
    {
      for (k = 0; k < diastasi; k++)
      {
        A[i][j][k] = 0.000001;
        a[i][j][k] = 0.000001;
      }

    }

  }

  if (lamda_option == 1)
  {
    for (i = 0; i < order; i++)
    {
      Lambda[i] = 1 / ((double) order);
    }

  }
  else
    if (lamda_option == 2)
  {
    double par = 0;
    for (i = 0; i < order; i++)
    {
      par = (par + i) + 1;
    }

    for (i = 0; i < order; i++)
    {
      Lambda[i] = ((double) (order - i)) / par;
    }

  }
  else
  {
    printf("Error: wrong choise of Lambda. Write 1:Lambda=(1/order)  2:Lambda=((order-i)/par)  ");
  }


  int chunk = 200;
  #pragma omp parallel for private(i,j,k) shared(trainseqArray,A) schedule(dynamic,chunk)
  for (i = 1; i < (seq_num * 2); i += 2)
  {
    for (j = order; j < strlen(trainseqArray[i]); j++)
    {
      for (k = 0; k < order; k++)
      {
        int SIDi = 0;
        int SIDj = 0;
        char zebgos[3];
        sprintf(zebgos, "%c%c", trainseqArray[i][(j - k) - 1], trainseqArray[i][j]);
        abc(&SIDi, &SIDj, alphabet, zebgos);
        #pragma omp critical
        A[k][SIDi][SIDj] += 1;
      }

    }

  }

  for (i = 0; i < order; i++)
  {
    for (j = 0; j < diastasi; j++)
    {
      for (k = 0; k < diastasi; k++)
      {
        sum = sum + A[i][j][k];
      }

      for (k = 0; k < diastasi; k++)
      {
        a[i][j][k] = ((double) A[i][j][k]) / ((double) sum);
      }

      sum = 0;
    }

  }


  static int err;
  int id = omp_get_thread_num();
  if (prvt != magicno)
  {
    errors += 1;
  }

  #pragma omp barrier
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    errors++;
  }

}

