int main(int argc, char *argv[])
{
  if (argc < 2)
  {
    usage(argv[0]);
  }

  int num_threads = 2;
  if (argc > 2)
  {
    for (int i = 0; i < argc; i++)
    {
      if ((strcmp(argv[i], "-t") == 0) && (argc > (i + 1)))
      {
        num_threads = atoi(argv[i + 1]);
      }

    }

  }

  omp_set_num_threads(num_threads);
  FILE *input_file = fopen(argv[1], "r");
  if (input_file == 0)
  {
    usage(argv[0]);
  }

  int dim = 0;
  fscanf(input_file, "%u\n", &dim);
  int mat[dim][dim];
  int element = 0;
  for (int i = 0; i < dim; i++)
  {
    for (int j = 0; j < dim; j++)
    {
      if (j != (dim - 1))
        fscanf(input_file, "%d\t", &element);
      else
        fscanf(input_file, "%d\n", &element);

      mat[i][j] = element;
    }

  }

  long alg_start = get_usecs();
  int ps[dim][dim];
  for (int j = 0; j < dim; j++)
  {
    ps[0][j] = mat[0][j];
    for (int i = 1; i < dim; i++)
    {
      ps[i][j] = ps[i - 1][j] + mat[i][j];
    }

  }

  int max_sum = mat[0][0];
  int top = 0;
  int left = 0;
  int bottom = 0;
  int right = 0;
  int sum[dim];
  int pos[dim];
  int local_max;
  #pragma omp parallel for private(sum, pos, local_max) schedule(static, 10)
  for (int i = 0; i < dim; i++)
  {
    for (int k = i; k < dim; k++)
    {
      clear(sum, dim);
      clear(pos, dim);
      local_max = 0;
      sum[0] = ps[k][0] - ((i == 0) ? (0) : (ps[i - 1][0]));
      for (int j = 1; j < dim; j++)
      {
        if (sum[j - 1] > 0)
        {
          sum[j] = (sum[j - 1] + ps[k][j]) - ((i == 0) ? (0) : (ps[i - 1][j]));
          pos[j] = pos[j - 1];
        }
        else
        {
          sum[j] = ps[k][j] - ((i == 0) ? (0) : (ps[i - 1][j]));
          pos[j] = j;
        }

        if (sum[j] > sum[local_max])
        {
          local_max = j;
        }

      }

      if (sum[local_max] > max_sum)
      {
        max_sum = sum[local_max];
        top = i;
        left = pos[local_max];
        bottom = k;
        right = local_max;
      }

    }

  }

  int outmat_row_dim = (bottom - top) + 1;
  int outmat_col_dim = (right - left) + 1;
  int outmat[outmat_row_dim][outmat_col_dim];
  for (int i = top, k = 0; i <= bottom; i++, k++)
  {
    for (int j = left, l = 0; j <= right; j++, l++)
    {
      outmat[k][l] = mat[i][j];
    }

  }

  long alg_end = get_usecs();
  printf("Sub-matrix [%dX%d] with max sum = %d, top = %d, bottom = %d, left = %d, right = %d\n", outmat_row_dim, outmat_col_dim, max_sum, top, bottom, left, right);
  printf("%s,arg(%s),%s,%f sec, threads: %d\n", argv[0], argv[1], "CHECK_NOT_PERFORMED", ((double) (alg_end - alg_start)) / 1000000, num_threads);
  fclose(input_file);
  return 0;
}

