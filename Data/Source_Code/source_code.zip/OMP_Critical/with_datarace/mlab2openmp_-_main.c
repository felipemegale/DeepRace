int *A;
int *B;
float *C;
int main(int argc, const char *argv[])
{|}~ ";
const char *TARGET = "Hello, World!";
const int GENE_POOL_SIZE = 10;
const int FIT_PARENT_PROB = 90;
const int MUTATION_PROB = 100;
int TARGET_LEN;
{
  char *dna;
  int fitness;
} candidate;
void test();
char *gen_string(int length);
int get_fitness(char *source);
int candidate_comparator(const void *arg1, const void *arg2);
candidate get_rand_parent(candidate genepool[]);
void print_candidate(candidate cand);
char *crossover(candidate parent1, candidate parent2);
void mutate(char *source);
int run();
int run()
{
  candidate genepool[GENE_POOL_SIZE];
  for (int i = 0; i < GENE_POOL_SIZE; i++)
  {
    char *rand_dna = gen_string(TARGET_LEN);
    int fitval = get_fitness(rand_dna);
    candidate new_cand = {rand_dna, fitval};
    genepool[i] = new_cand;
  }

  int generation = 0;
  while (1)
  {
    generation++;
    qsort(genepool, GENE_POOL_SIZE, sizeof(candidate), candidate_comparator);
    if (genepool[0].fitness == 0)
    {
      return generation;
    }
    else
    {
      candidate best_child = {0, 32767};
      #pragma omp parallel shared(best_child)
      {
        candidate parent1 = get_rand_parent(genepool);
        candidate parent2 = get_rand_parent(genepool);
        char *child_dna = crossover(parent1, parent1);
        mutate(child_dna);
        int child_fitval = get_fitness(child_dna);
        candidate child = {child_dna, child_fitval};
        #pragma omp critical (best_child)
        {
          if (child.fitness < best_child.fitness)
          {
            best_child = child;
          }

        }
      }
      candidate lowest_cand = genepool[GENE_POOL_SIZE - 1];
      if (best_child.fitness < lowest_cand.fitness)
      {
        genepool[GENE_POOL_SIZE - 1] = best_child;
      }

    }

  }

  return 0;

  int n = 0;
  int thread_c = 4;
  if (argc > 1)
    n = atoi(argv[1]);

  if (argc > 2)
    thread_c = atoi(argv[2]);

  if ((!n) || (n < 0))
  {
    printf("Missing or invalid array size.\n");
    return 0;
  }

  omp_set_num_threads(thread_c);
  A = (int *) malloc(n * (sizeof(int)));
  B = (int *) malloc(n * (sizeof(int)));
  ;
  C = (float *) malloc(n * (sizeof(float)));
  float nMaxT = 0.0;
  float nMinT = 10.0;
  double sumT = 0.0;
  #pragma omp parallel
  {
    int i;
    unsigned int rseed = time(0) - (omp_get_thread_num() * 11);
    double sum = 0.0;
    float nMax = 0.0;
    float nMin = 10.0;
    #pragma omp for nowait schedule(static)
    for (i = 0; i < n; i++)
    {
      A[i] = rand_r(&rseed) % 10;
      B[i] = rand_r(&rseed) % 10;
      C[i] = (A[i] + B[i]) / 2;
      sum += C[i];
      if (C[i] > nMax)
        nMax = C[i];

      if (C[i] < nMin)
        nMin = C[i];

    }

    {
      sumT += sum;
      if (nMax > nMaxT)
        nMaxT = nMax;

      if (nMin < nMinT)
        nMinT = nMin;

    }
  }
  printf("openmp - Average is: %.4f, Maximum is: %.2f, Minimum is: %.2f, Count: %d, Threads: %d\n", sumT / n, nMaxT, nMinT, n, thread_c);
  free(A);
  free(B);
  free(C);
  return 0;
}

