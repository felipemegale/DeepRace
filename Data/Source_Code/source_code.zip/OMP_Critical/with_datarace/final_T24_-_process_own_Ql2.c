int i;
int j;
double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
struct Data
{
  int start;
  int end;
  int size;
};
struct Node
{
  struct Data *data;
  struct Node *next;
};
struct Q
{
  struct Node *front;
  struct Node *rear;
};
void process_own_Ql2(struct Q *list[])
{
  int out = 0.0;
  int ID = omp_get_thread_num();
  struct Data *tempdat;
  struct Data *tempdatothers;
  {
    tempdat = deq(list[ID]);
  }
  while (tempdat != 0)
  {
    loop2(tempdat->start, tempdat->end);
    {
      tempdat = deq(list[ID]);
    }
  }


  int i;
  int j;
  double suma;
  double aux;
  double ncgt;
  double tInicio;
  double tFin;
  if (argc < 2)
  {
    printf("No has indicado la capacidad de la matriz cuadrada\n");
    exit(-1);
  }

  unsigned int N = atoi(argv[1]);
  double *matriz;
  double *vector;
  double *resultado;
  matriz = (double *) malloc((N * N) * (sizeof(double)));
  vector = (double *) malloc(N * (sizeof(double)));
  resultado = (double *) malloc(N * (sizeof(double)));
  if (((resultado == 0) || (matriz == 0)) || (vector == 0))
  {
    printf("\nError a la hora de reservar memoria para la matriz y/o los vectores\n");
    exit(-2);
  }

  for (i = 0; i < N; i++)
  {
    for (j = 0; j < N; j++)
      matriz[(i * N) + j] = (N * 0.1) + (j * 0.1);

    vector[i] = (N * 0.1) - (i * 0.1);
    resultado[i] = 0.0;
  }

  tInicio = omp_get_wtime();
  for (i = 0; i < N; i++)
  {
    suma = 0.0;
    #pragma omp parallel private(aux)
    {
      aux = 0.0;
      #pragma omp for schedule(static)
      for (j = 0; j < N; j++)
        aux += matriz[(i * N) + j] * vector[j];

      #pragma omp critical
      {
        suma += aux;
      }
    }
    resultado[i] = suma;
  }

  tFin = omp_get_wtime();
  ncgt = (tFin - tInicio) * 10.0;
  printf("Tiempo(seg.):%11.9f / Tamaño del vector: %u / resultado[0]=%f / resultado[%d]=%f \n", ncgt, N, resultado[0], N - 1, resultado[N - 1]);
  if (N < 18)
  {
    for (i = 0; i < N; i++)
      printf("\nComponente %d de resultado[%d] = %f", i, i, resultado[i]);

  }

  printf("\n");
  free(matriz);
  free(vector);
  free(resultado);
  return 0;
}

