static long num_steps = 1000000;
int main()
{
  double pi = 0;
  double step = 1.0 / ((double) num_steps);
  #pragma omp parallel num_threads(NUM_THREADS)
  {
    double x;
    double soma = 0;
    int i;
    #pragma omp for
    for (i = 0; i < num_steps; i++)
    {
      x = (i + 0.5) * step;
      soma += 4.0 / (1.0 + (x * x));
    }

    pi += soma * step;
  }
  printf("%f\n", pi);
  return 0;
}

