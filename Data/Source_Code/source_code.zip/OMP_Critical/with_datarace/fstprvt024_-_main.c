static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt = 100;
int main()
{
  int nombre_thread;
  int id_thread;
  #pragma omp parallel private(id_thread)
  {
    #pragma omp master
    {
      nombre_thread = omp_get_num_threads();
      printf("Nombre de thread disponnible: %d\n", nombre_thread);
    }
    #pragma omp barrier
    id_thread = omp_get_thread_num();
    #pragma omp critical
    {
      printf("Thread N° %d pret\n", id_thread);
    }
  }

  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    #pragma omp single firstprivate (prvt)
    {
      if (prvt != 100)
      {
        errors += 1;
      }

    }
  }
  if (errors == 0)
  {
    printf("firstprivate 024 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 024 : FAILED\n");
    return 1;
  }

}

