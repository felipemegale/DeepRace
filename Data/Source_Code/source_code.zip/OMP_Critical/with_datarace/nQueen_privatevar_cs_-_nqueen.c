int P[30] = {};
int N;
int count = 0;
void nqueen(int next, int *Position)
{
  if (next == N)

  count++;
  for (int i = 0; i < N; i++)
    if (ok(next, i, Position))
  {
    Position[next] = i;
    nqueen(++next, Position);
    next--;
  }


}

