int *PHS(int *arr)
{
  int max = arr[0];
  int min = arr[0];
  #pragma omp parallel for num_threads(16)
  for (int i = 0; i < 214748364; i++)
  {
    if (arr[i] < min)
    {
      min = arr[i];
    }

    if (arr[i] > max)
    {
      max = arr[i];
    }

  }

  int *temp = (int *) calloc((max - min) + 1, sizeof(int));
  #pragma omp parallel for num_threads(16)
  for (int i = 0; i < ((max - min) + 1); i++)
  {
    temp[i - min] = i;
  }

  int j = 0;
  #pragma omp parallel for num_threads(4)
  for (int i = 0; i < ((max - min) + 1); i++)
  {
    if (i != 0)
    {
      {
        arr[j] = i;
        j++;
      }
    }

  }

  free(temp);
  return arr;
}

