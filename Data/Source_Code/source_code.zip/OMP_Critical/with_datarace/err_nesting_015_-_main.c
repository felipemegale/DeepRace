static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int i;
int main()
{
  int j = 100;
  omp_set_num_threads(2);
  omp_set_dynamic(0);
  #pragma omp parallel shared(j)
  {
    #pragma omp parallel sections firstprivate(j)
    {
      #pragma omp section
      {
        #pragma omp task shared(j)
        {
          #pragma omp critical
          printf("In Task, j = %d\n", j);
        }
        #pragma omp taskwait
      }
    }
  }
  printf("After parallel, j = %d\n", j);
  if (j != 100)
    printf("The Test \"#omp parallel sections firstprivate\" FAILED\n");
  else
    printf("The Test #\"#omp parallel sections firstprivate\" PASSED\n");


  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    {
      #pragma omp single
      {
        i += 1;
      }
    }
  }
  printf("err_nesting 015 : FAILED, can not compile this program.\n");
  return 1;
}

