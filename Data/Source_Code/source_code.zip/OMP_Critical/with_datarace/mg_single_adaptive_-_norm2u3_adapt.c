{
  int i;
  double d;
};
union x prvt;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt.i = 100;
  #pragma omp parallel firstprivate (prvt)
  {
    int id = omp_get_thread_num();
    if (prvt.i != 100)
    {
      #pragma omp critical
      errors += 1;
    }

    prvt.i = id;
    #pragma omp barrier
    if (prvt.i != id)
    {
      #pragma omp critical
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(union x)))
    {
      #pragma omp critical
      errors += 1;
    }

  }
  prvt.i = 100 * 2;
  #pragma omp parallel firstprivate (prvt)
  func1(100 * 2, &prvt);
  prvt.i = 100 * 3;
  #pragma omp parallel firstprivate (prvt)
  func2(100 * 3);
  if (errors == 0)
  {
    printf("firstprivate 014 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 014 : FAILED\n");
    return 1;
  }


  double real;
  double imag;
} dcomplex;
extern double randlc(double *, double);
extern void vranlc(int, double *, double, double *);
extern void timer_clear(int);
extern void timer_start(int);
extern void timer_stop(int);
extern double timer_read(int);
extern void c_print_results(char *name, char cclass, int n1, int n2, int n3, int niter, int nthreads, double t, double mops, char *optype, int passed_verification, char *npbversion, char *compiletime, char *cc, char *clink, char *c_lib, char *c_inc, char *cflags, char *clinkflags, char *rand);
static int nx[11 + 1];
static int ny[11 + 1];
static int nz[11 + 1];
static char Class;
static int debug_vec[8];
static int m1[11 + 1];
static int m2[11 + 1];
static int m3[11 + 1];
static int lt;
static int lb;
static int is1;
static int is2;
static int is3;
static int ie1;
static int ie2;
static int ie3;
static void setup(int *n1, int *n2, int *n3, int lt);
static void mg3P_adapt(double ****u, double ***v, double ****r, double a[4], double c[4], int n1, int n2, int n3, int k);
static void mg3P(double ****u, double ***v, double ****r, double a[4], double c[4], int n1, int n2, int n3, int k);
static void psinv_adapt(double ***r, double ***u, int n1, int n2, int n3, double c[4], int k);
static void psinv(double ***r, double ***u, int n1, int n2, int n3, double c[4], int k);
static void resid_adapt(double ***u, double ***v, double ***r, int n1, int n2, int n3, double a[4], int k);
static void resid(double ***u, double ***v, double ***r, int n1, int n2, int n3, double a[4], int k);
static void rprj3(double ***r, int m1k, int m2k, int m3k, double ***s, int m1j, int m2j, int m3j, int k);
static void rprj3_adapt(double ***r, int m1k, int m2k, int m3k, double ***s, int m1j, int m2j, int m3j, int k);
static void interp_adapt(double ***z, int mm1, int mm2, int mm3, double ***u, int n1, int n2, int n3, int k);
static void interp(double ***z, int mm1, int mm2, int mm3, double ***u, int n1, int n2, int n3, int k);
static void norm2u3_adapt(double ***r, int n1, int n2, int n3, double *rnm2, double *rnmu, int nx, int ny, int nz);
static void norm2u3(double ***r, int n1, int n2, int n3, double *rnm2, double *rnmu, int nx, int ny, int nz);
static void rep_nrm(double ***u, int n1, int n2, int n3, char *title, int kk);
static void comm3(double ***u, int n1, int n2, int n3, int kk);
static void zran3(double ***z, int n1, int n2, int n3, int nx, int ny, int k);
static void showall(double ***z, int n1, int n2, int n3);
static double power(double a, int n);
static void bubble(double ten[1037][2], int j1[1037][2], int j2[1037][2], int j3[1037][2], int m, int ind);
static void zero3(double ***z, int n1, int n2, int n3);
static void zero3_adapt(double ***z, int n1, int n2, int n3);
static void nonzero(double ***z, int n1, int n2, int n3);
static void norm2u3_adapt(double ***r, int n1, int n2, int n3, double *rnm2, double *rnmu, int nx, int ny, int nz)
{
  #pragma omp parallel
  {
    static double s = 0.0;
    double tmp;
    int i3;
    int i2;
    int i1;
    int n;
    double p_s = 0.0;
    double p_a = 0.0;
    n = (nx * ny) * nz;
    #pragma omp for
    for (i3 = 1; i3 < (n3 - 1); i3++)
    {
      for (i2 = 1; i2 < (n2 - 1); i2++)
      {
        for (i1 = 1; i1 < (n1 - 1); i1++)
        {
          p_s = p_s + (r[i3][i2][i1] * r[i3][i2][i1]);
          tmp = fabs(r[i3][i2][i1]);
          if (tmp > p_a)
            p_a = tmp;

        }

      }

    }

    {
      s += p_s;
      if (p_a > (*rnmu))
        *rnmu = p_a;

    }
    #pragma omp barrier
    #pragma omp single
    {
      *rnm2 = sqrt(s / ((double) n));
      s = 0.0;
    }
  }
}

