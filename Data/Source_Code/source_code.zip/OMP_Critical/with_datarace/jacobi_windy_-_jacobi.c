double time1;
double time2;
void driver(void);
void initialize(void);
void jacobi(void);
void error_check(void);
int n;
int m;
int mits;
double tol;
double relax = 1.0;
double alpha = 0.0543;
double u[16][16];
double f[16][16];
double uold[16][16];
double dx;
double dy;
void jacobi()
{
  double omega;
  int i;
  int j;
  int k;
  double resid;
  double ax;
  double ay;
  double b;
  static double error;
  omega = relax;
  ax = 1.0 / (dx * dx);
  ay = 1.0 / (dy * dy);
  b = (((-2.0) / (dx * dx)) - (2.0 / (dy * dy))) - alpha;
  error = 10.0 * tol;
  k = 1;
  wb_dword(&error);
  while ((k <= mits) && (error > tol))
  {
    error = 0.0;
    wb_dword(&error);
    #pragma omp parallel
    {
      inv_word(&n);
      inv_word(&m);
      #pragma omp for private(j,i)
      for (i = 0; i < n; i++)
      {
        inv_range(&u[i][0], m * (sizeof(double)));
        for (j = 0; j < m; j++)
        {
          uold[i][j] = u[i][j];
        }

        wb_range(&uold[i][0], m * (sizeof(double)));
      }

      inv_dword(&error);
      #pragma omp for private(resid,j,i) nowait
      for (i = 1; i < (n - 1); i++)
      {
        inv_range(&uold[i - 1][1], (m - 2) * (sizeof(double)));
        inv_range(&uold[i][0], m * (sizeof(double)));
        inv_range(&uold[i + 1][1], (m - 2) * (sizeof(double)));
        inv_range(&f[i][1], (m - 2) * (sizeof(double)));
        for (j = 1; j < (m - 1); j++)
        {
          resid = ((((ax * (uold[i - 1][j] + uold[i + 1][j])) + (ay * (uold[i][j - 1] + uold[i][j + 1]))) + (b * uold[i][j])) - f[i][j]) / b;
          u[i][j] = uold[i][j] - (omega * resid);
          {
            inv_dword(&error);
            error = error + (resid * resid);
            wb_dword(&error);
          }
        }

        wb_range(&u[i][1], (m - 2) * (sizeof(double)));
      }

    }
    k = k + 1;
    if ((k % 500) == 0)
      printf("** Finished %d iteration.\n", k);

    printf("Finished %d iteration.\n", k);
    inv_dword(&error);
    error = sqrt(error) / (n * m);
    wb_dword(&error);
  }

  printf("Total Number of Iterations:%d\n", k);
  printf("Residual:%E\n", error);
}

