int main()
{
  const int N = 1000000;
  double sum = 0.0f;
  double *x;
  double *z;
  x = (double *) malloc(N * (sizeof(double)));
  z = (double *) malloc(N * (sizeof(double)));
  int i;
  printf("open mp version: %d\n", _OPENMP);
  #pragma omp parallel for
  for (i = 0; i < N; i++)
    x[i] = (i + 1) * .000001;

  #pragma omp parallel for
  for (i = 0; i < N; i++)
  {
    z[i] = exp(x[i] * x[i]);
  }

  #pragma omp parallel
  {
    double private_sum = 0.0;
    #pragma omp for
    for (i = 0; i < N; i++)
    {
      private_sum += z[i];
    }

    {
      sum += private_sum;
    }
  }
  printf("%f\n", sum);
  return 0;
}

