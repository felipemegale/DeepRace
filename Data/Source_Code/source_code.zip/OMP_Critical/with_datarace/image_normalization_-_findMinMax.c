static int x;
static int y;
void findMinMax(unsigned char *img, unsigned char *min, unsigned char *max, int size)
{
  long i;
  unsigned char value;
  unsigned char *localMin = malloc(3 * (sizeof(unsigned char)));
  unsigned char *localMax = malloc(3 * (sizeof(unsigned char)));
  for (i = 0; i < 3; i++)
  {
    localMin[i] = 255;
    localMax[i] = 0;
  }

  #pragma omp parallel firstprivate(localMin, localMax) private(value) shared(img, size, min, max)
  {
    #pragma omp for
    for (i = 0; i < size; i++)
    {
      value = img[i];
      if (value < localMin[i % 3])
      {
        localMin[i % 3] = value;
      }

      if (value > localMax[i % 3])
      {
        localMax[i % 3] = value;
      }

    }

    for (i = 0; i < 3; i++)
    {
      {
        min[i] = (min[i] < localMin[i]) ? (min[i]) : (localMin[i]);
        max[i] = (max[i] > localMax[i]) ? (max[i]) : (localMax[i]);
      }
    }

  }
  free(localMin);
  free(localMax);

  int n;
  int max_iter = 1;
  double start_time;
  double end_time;
  int number_solutions = 0;
  {
    int num_workers;
    int i;
    n = (argc > 1) ? (atoi(argv[1])) : (8);
    num_workers = (argc > 2) ? (atoi(argv[2])) : (30);
    omp_set_num_threads(num_workers);
    for (i = 0; i < n; i++)
    {
      max_iter *= n;
    }

  }
  start_time = omp_get_wtime();
  int iter;
  #pragma omp parallel for
  for (iter = 0; iter < max_iter; iter++)
  {
    int code = iter;
    int i;
    int queen_rows[16];
    for (i = 0; i < n; i++)
    {
      queen_rows[i] = code % n;
      code /= n;
    }

    if (check_acceptable(queen_rows, n))
    {
      #pragma omp atomic
      number_solutions++;
      #pragma omp critical
      {
        printf("\n");
        for (i = 0; i < n; i++)
        {
          int j;
          for (j = 0; j < n; j++)
          {
            if (queen_rows[i] == j)
              printf("|X");
            else
              printf("| ");

          }

          printf("|\n");
        }

        printf("\n");
      }
    }

  }

  end_time = omp_get_wtime();
  printf("The execution time is %g sec\n", end_time - start_time);
  printf("Number of found solutions is %d\n", number_solutions);
  return 0;
}

