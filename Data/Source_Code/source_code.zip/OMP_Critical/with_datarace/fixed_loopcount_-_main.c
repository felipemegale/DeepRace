int main(int argc, char **argv)
{
  int i;
  int thread_id;
  int global_nloops;
  int private_nloops;
  global_nloops = 0;
  #pragma omp parallel private(private_nloops, thread_id)
  {
    private_nloops = 0;
    thread_id = 0;
    #pragma omp for
    for (i = 0; i < 100000; ++i)
    {
      ++private_nloops;
    }

    {
      printf("Thread %d adding its iterations (%d) to the sum (%d)...\n", thread_id, private_nloops, global_nloops);
      global_nloops += private_nloops;
      printf("...total nloops now equals %d.\n", global_nloops);
    }
  }
  printf("The total number of loop iterations is %d\n", global_nloops);
  return 0;

  int a;
  int b;
  int c;
  a = 3 * 2;
  b = (10 * a) + a;
  c = b + a;
  #pragma omp critical
  {
    printf("Here a = %d\n", a);
    printf("Here b = %d\n", b);
    printf("Here c = %d\n", c);
    printf("Here a+b+c = %d \n", (a + b) + c);
    printf("Hello from thread %d, nthreads %d\n", omp_get_thread_num(), omp_get_num_threads());
  }
  printf("Exit \n");
}

