int main(int argc, char *argv[]);
int main(int argc, char *argv[])
{
  int i;
  int j;
  int cur;
  int temp_i;
  int temp_j;
  double epsilon = 0.001;
  double mean = 0.0;
  double diff;
  double my_diff;
  double u[12][12];
  #pragma omp parallel shared( u ) private(i, j) reduction(+ : mean)
  {
    #pragma omp for
    for (i = 1; i < (12 - 1); i++)
    {
      u[i][0] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (12 - 1); i++)
    {
      u[i][12 - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < 12; j++)
    {
      u[12 - 1][j] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < 12; j++)
    {
      u[0][j] = 0.0;
    }

    #pragma omp for
    for (i = 1; i < (12 - 1); i++)
    {
      mean = mean + u[i][0];
    }

    #pragma omp for
    for (i = 1; i < (12 - 1); i++)
    {
      mean = mean + u[i][12 - 1];
    }

    #pragma omp for
    for (j = 0; j < 12; j++)
    {
      mean = mean + u[12 - 1][j];
    }

    #pragma omp for
    for (j = 0; j < 12; j++)
    {
      mean = mean + u[0][j];
    }

  }
  mean = mean / ((double) (((2 * 12) + (2 * 12)) - 4));
  printf("\n");
  printf("  MEAN = %f\n", mean);
  #pragma omp parallel shared( u ) private(i, j)
  {
    #pragma omp for
    for (i = 1; i < (12 - 1); i++)
    {
      for (j = 1; j < (12 - 1); j++)
      {
        u[i][j] = mean;
      }

    }

  }
  printf(" MEAN = %f\n", mean);
  diff = epsilon;
  int iteration_number = 0;
  int run = 1;
  double wtime = omp_get_wtime();
  while (run)
  {
    int cont = 0;
    my_diff = 0.0;
    printf("Currently running on iteration number %d with diff %f\n", iteration_number, diff);
    diff = 0.0;
    iteration_number++;
    #pragma omp parallel shared(u, diff) private(i, j, cur, mean, temp_i, temp_j) reduction(+ : cont)
    {
      srand(((int) time(0)) ^ omp_get_thread_num());
      for (i = 1; i < (12 - 1); i++)
      {
        #pragma omp for
        for (j = 1; j < (12 - 1); j++)
        {
          mean = 0.0;
          for (cur = 0; cur < 1000; cur++)
          {
            temp_i = i;
            temp_j = j;
            while (1)
            {
              int direction = rand() % 4;
              if (direction == 0)
              {
                temp_i--;
                if (temp_i == 0)
                {
                  mean += 0.0;
                  break;
                }

              }
              else
                if (direction == 1)
              {
                temp_j--;
                if (temp_j == 0)
                {
                  mean += 100.0;
                  break;
                }

              }
              else
                if (direction == 2)
              {
                temp_i++;
                if (temp_i == (12 - 1))
                {
                  mean += 100.0;
                  break;
                }

              }
              else
              {
                temp_j++;
                if (temp_j == (12 - 1))
                {
                  mean += 100.0;
                  break;
                }

              }



            }

          }

          double old = u[i][j];
          if (iteration_number == 0)
          {
            u[i][j] = ((double) (u[i][j] + mean)) / (1000 + 1);
          }
          else
          {
            double cur_iter = ((double) iteration_number) * 1000;
            double prev_avg = ((double) cur_iter) * u[i][j];
            u[i][j] = ((double) (prev_avg + mean)) / (cur_iter + 1000);
          }

          if (fabs(old - u[i][j]) > epsilon)
          {
            if (fabs(old - u[i][j]) > my_diff)
            {
              my_diff = fabs(old - u[i][j]);
            }

            cont++;
          }

        }

      }

      {
        if (my_diff > diff)
        {
          diff = my_diff;
        }

      }
    }
    if (cont == 0)
    {
      run = 0;
    }

  }

  wtime = omp_get_wtime() - wtime;
  printf("Time taken %f\n", wtime);
  return 0;
}

