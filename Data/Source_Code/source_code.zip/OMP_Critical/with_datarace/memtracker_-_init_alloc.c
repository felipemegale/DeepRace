static void *(*real_malloc)(size_t size) = 0;
static void (*real_free)(void *p) = 0;
static size_t used_mem[1];
static char size_pow[6] = {'B', 'K', 'M', 'G', 'T', 'P'};
static void hread_size(float *out_size, char *unit, const size_t in_size);
static void init_alloc(void);
static int memtr_printf(const char *format, ...);
static void print_backtrace(unsigned int max_frames);
static void reset_used_mem(void);
static void splash(void);
static void init_alloc(void)
{
  {
    if (real_malloc == 0)
    {
      splash();
      reset_used_mem();
      real_malloc = dlsym(RTLD_NEXT, "malloc");
      real_free = dlsym(RTLD_NEXT, "free");
    }

  }
  if (real_malloc == 0)
  {
    memtr_printf("error in `dlsym`: %s\n", dlerror());
    exit(1);
  }


  int id = omp_get_thread_num();
  if ((*prvt) != magicno)
  {
    #pragma omp critical
    errors += 1;
  }

  *prvt = id;
  #pragma omp barrier
  if ((*prvt) != id)
  {
    #pragma omp critical
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(double)))
  {
    #pragma omp critical
    errors += 1;
  }

}

