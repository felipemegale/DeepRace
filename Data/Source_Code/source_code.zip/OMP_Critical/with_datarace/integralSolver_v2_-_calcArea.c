double tolerance;
double delta;
double total_area = 0.0;
int type;
int working = 0;
struct _Task
{
  double a;
  double b;
  struct _Task *next;
};
{
  Task *first;
  Task *last;
} Bag;
Bag bag;
void calcArea()
{
  double a;
  double b;
  while (1)
  {
    double value = 0.0;
    double diff;
    double largerArea;
    double smallerArea1;
    double smallerArea2;
    double x;
    int flag = 0;
    {
      if (getTask(&a, &b) != 0)
      {
        if (working == 0)
          flag = 1;
        else
          flag = 2;

      }
      else
        working++;

    }
    if (flag == 1)
      break;
    else
      if (flag == 2)
      continue;


    x = (b - a) / 2.0;
    largerArea = area(a, b);
    smallerArea1 = area(a, a + x);
    smallerArea2 = area(a + x, b);
    value = largerArea;
    diff = largerArea - (smallerArea1 + smallerArea2);
    if ((fabs(diff) > tolerance) && (fabs(b - a) > delta))
    {
      {
        insertTask(a, a + x);
        insertTask(a + x, b);
      }
    }
    else
    {
      total_area += value;
    }

    working--;
  }

}

