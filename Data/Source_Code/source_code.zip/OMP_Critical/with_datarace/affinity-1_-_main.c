struct place
{
  int start;
  int len;
};
struct places
{
  char name[40];
  int count;
  struct place places[8];
} places_array[] = {{"", 1, {{-1, -1}}}, {"{0}:8", 8, {{0, 1}, {1, 1}, {2, 1}, {3, 1}, {4, 1}, {5, 1}, {6, 1}, {7, 1}}}, {"{7,6}:2:-3", 2, {{6, 2}, {3, 2}}}, {"{6,7}:4:-2,!{2,3}", 3, {{6, 2}, {4, 2}, {0, 2}}}, {"{1}:7:1", 7, {{1, 1}, {2, 1}, {3, 1}, {4, 1}, {5, 1}, {6, 1}, {7, 1}}}, {"{0,1},{3,2,4},{6,5,!6},{6},{7:2:-1,!6}", 5, {{0, 2}, {2, 3}, {5, 1}, {6, 1}, {7, 1}}}};
unsigned long contig_cpucount;
unsigned long min_cpusetsize;
int main()
{
  char *env_proc_bind = getenv("OMP_PROC_BIND");
  int test_false = env_proc_bind && (strcmp(env_proc_bind, "false") == 0);
  int test_true = env_proc_bind && (strcmp(env_proc_bind, "true") == 0);
  int test_spread_master_close = env_proc_bind && (strcmp(env_proc_bind, "spread,master,close") == 0);
  char *env_places = getenv("OMP_PLACES");
  int test_places = 0;
  int first = 1;
  if (env_proc_bind)
  {
    printf("OMP_PROC_BIND='%s'", env_proc_bind);
    first = 0;
  }

  if (env_places)
    printf("%sOMP_PLACES='%s'", (first) ? ("") : (" "), env_places);

  printf("\n");
  if ((env_places && (contig_cpucount >= 8)) && (test_true || test_spread_master_close))
  {
    for (test_places = ((sizeof(places_array)) / (sizeof(places_array[0]))) - 1; test_places; --test_places)
      if (strcmp(env_places, places_array[test_places].name) == 0)
      break;


  }

  if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
    abort();

  if (test_true && (omp_get_proc_bind() != omp_proc_bind_true))
    abort();

  if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_spread))
    abort();

  ;
  printf("Initial thread");
  print_affinity(places_array[test_places].places[0]);
  printf("\n");
  omp_set_nested(1);
  omp_set_dynamic(0);
  #pragma omp parallel if (0)
  {
    if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
      abort();

    if (test_true && (omp_get_proc_bind() != omp_proc_bind_true))
      abort();

    if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_master))
      abort();

    ;
    #pragma omp parallel if (0)
    {
      if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
        abort();

      if (test_true && (omp_get_proc_bind() != omp_proc_bind_true))
        abort();

      if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
        abort();

      ;
      #pragma omp parallel if (0)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_true))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
      }
      #pragma omp parallel if (0) proc_bind (spread)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        ;
      }
    }
    #pragma omp parallel if (0) proc_bind (master)
    {
      if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
        abort();

      if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
        abort();

      if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
        abort();

      ;
      #pragma omp parallel if (0)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
      }
      #pragma omp parallel if (0) proc_bind (spread)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        ;
      }
    }
  }
  #pragma omp parallel num_threads (4)
  {
    if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
      abort();

    if (test_true && (omp_get_proc_bind() != omp_proc_bind_true))
      abort();

    if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_master))
      abort();

    ;
    {
      struct place p = places_array[0].places[0];
      int thr = omp_get_thread_num();
      printf("#1 thread %d", thr);
      if ((omp_get_num_threads() == 4) && test_spread_master_close)
        switch (places_array[test_places].count)
      {
        case 8:

        case 7:
          p = places_array[test_places].places[2 * thr];
          break;

        case 5:
          p = places_array[test_places].places[(thr) ? (1 + thr) : (0)];
          break;

        case 3:
          p = places_array[test_places].places[(thr == 3) ? (0) : (thr)];
          break;

        case 2:
          p = places_array[test_places].places[thr / 2];
          break;

      }


      print_affinity(p);
      printf("\n");
    }
    #pragma omp barrier
    if (omp_get_thread_num() == 3)
    {
      #pragma omp parallel num_threads (3)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_true))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#1,#1 thread 3,%d", thr);
          if ((omp_get_num_threads() == 3) && test_spread_master_close)
            switch (places_array[test_places].count)
          {
            case 8:

            case 7:
              p = places_array[test_places].places[6];
              break;

            case 5:
              p = places_array[test_places].places[4];
              break;

            case 3:
              p = places_array[test_places].places[0];
              break;

            case 2:
              p = places_array[test_places].places[1];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (5) proc_bind (spread)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#1,#2 thread 3,%d", thr);
          if ((omp_get_num_threads() == 5) && test_spread_master_close)
            switch (places_array[test_places].count)
          {
            case 8:
              p = places_array[test_places].places[(thr == 4) ? (6) : (6 + (thr / 2))];
              break;

            case 7:
              p = places_array[test_places].places[6];
              break;

            case 5:
              p = places_array[test_places].places[4];
              break;

            case 3:
              p = places_array[test_places].places[0];
              break;

            case 2:
              p = places_array[test_places].places[1];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
        #pragma omp barrier
        if (omp_get_thread_num() == 3)
        {
          #pragma omp parallel num_threads (5) proc_bind (close)
          {
            if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
              abort();

            if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            ;
            {
              struct place p = places_array[0].places[0];
              int thr = omp_get_thread_num();
              printf("#1,#2,#1 thread 3,3,%d", thr);
              if ((omp_get_num_threads() == 5) && test_spread_master_close)
                switch (places_array[test_places].count)
              {
                case 8:
                  p = places_array[test_places].places[7];
                  break;

                case 7:
                  p = places_array[test_places].places[6];
                  break;

                case 5:
                  p = places_array[test_places].places[4];
                  break;

                case 3:
                  p = places_array[test_places].places[0];
                  break;

                case 2:
                  p = places_array[test_places].places[1];
                  break;

              }


              print_affinity(p);
              printf("\n");
            }
          }
        }

      }
      #pragma omp parallel num_threads (4) proc_bind(master)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#1,#3 thread 3,%d", thr);
          if ((omp_get_num_threads() == 4) && test_spread_master_close)
            switch (places_array[test_places].count)
          {
            case 8:

            case 7:
              p = places_array[test_places].places[6];
              break;

            case 5:
              p = places_array[test_places].places[4];
              break;

            case 3:
              p = places_array[test_places].places[0];
              break;

            case 2:
              p = places_array[test_places].places[1];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (6) proc_bind (close)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#1,#4 thread 3,%d", thr);
          if ((omp_get_num_threads() == 6) && test_spread_master_close)
            switch (places_array[test_places].count)
          {
            case 8:
              p = places_array[test_places].places[6 + (thr / 3)];
              break;

            case 7:
              p = places_array[test_places].places[6];
              break;

            case 5:
              p = places_array[test_places].places[4];
              break;

            case 3:
              p = places_array[test_places].places[0];
              break;

            case 2:
              p = places_array[test_places].places[1];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
      }
    }

  }
  #pragma omp parallel num_threads (5) proc_bind(spread)
  {
    if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
      abort();

    if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
      abort();

    if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_master))
      abort();

    ;
    {
      struct place p = places_array[0].places[0];
      int thr = omp_get_thread_num();
      printf("#2 thread %d", thr);
      if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
        switch (places_array[test_places].count)
      {
        case 8:
          p = places_array[test_places].places[(thr < 3) ? (2 * thr) : (3 + thr)];
          break;

        case 7:
          p = places_array[test_places].places[(thr < 2) ? (2 * thr) : (2 + thr)];
          break;

        case 5:
          p = places_array[test_places].places[thr];
          break;

        case 3:
          p = places_array[test_places].places[(thr >= 3) ? (thr - 3) : (thr)];
          break;

        case 2:
          p = places_array[test_places].places[(thr == 4) ? (0) : (thr / 2)];
          break;

      }


      print_affinity(p);
      printf("\n");
    }
    #pragma omp barrier
    if (omp_get_thread_num() == 3)
    {
      int pp = 0;
      switch (places_array[test_places].count)
      {
        case 8:
          pp = 6;
          break;

        case 7:
          pp = 5;
          break;

        case 5:
          pp = 3;
          break;

        case 2:
          pp = 1;
          break;

      }

      #pragma omp parallel num_threads (3) firstprivate (pp)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#2,#1 thread 3,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[pp];

          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (5) proc_bind (spread) firstprivate (pp)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#2,#2 thread 3,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[pp];

          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (4) proc_bind(master) firstprivate(pp)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#2,#3 thread 3,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[pp];

          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (6) proc_bind (close) firstprivate (pp)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#2,#4 thread 3,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[pp];

          print_affinity(p);
          printf("\n");
        }
      }
    }

  }
  #pragma omp parallel num_threads (3) proc_bind(master)
  {
    if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
      abort();

    if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
      abort();

    if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_master))
      abort();

    ;
    {
      struct place p = places_array[0].places[0];
      int thr = omp_get_thread_num();
      printf("#3 thread %d", thr);
      if (test_spread_master_close || test_true)
        p = places_array[test_places].places[0];

      print_affinity(p);
      printf("\n");
    }
    #pragma omp barrier
    if (omp_get_thread_num() == 2)
    {
      #pragma omp parallel num_threads (4)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#3,#1 thread 2,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[0];

          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (4) proc_bind (spread)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#3,#2 thread 2,%d", thr);
          if ((omp_get_num_threads() == 4) && (test_spread_master_close || test_true))
            switch (places_array[test_places].count)
          {
            case 8:

            case 7:
              p = places_array[test_places].places[2 * thr];
              break;

            case 5:
              p = places_array[test_places].places[(thr) ? (1 + thr) : (0)];
              break;

            case 3:
              p = places_array[test_places].places[(thr == 3) ? (0) : (thr)];
              break;

            case 2:
              p = places_array[test_places].places[thr / 2];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
        #pragma omp barrier
        if (omp_get_thread_num() == 0)
        {
          #pragma omp parallel num_threads (5) proc_bind (close)
          {
            if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
              abort();

            if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            ;
            {
              struct place p = places_array[0].places[0];
              int thr = omp_get_thread_num();
              printf("#3,#2,#1 thread 2,0,%d", thr);
              if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
                switch (places_array[test_places].count)
              {
                case 8:

                case 7:

                case 5:
                  p = places_array[test_places].places[(thr & 2) / 2];
                  break;

                case 3:

                case 2:
                  p = places_array[test_places].places[0];
                  break;

              }


              print_affinity(p);
              printf("\n");
            }
          }
        }

        #pragma omp barrier
        if (omp_get_thread_num() == 3)
        {
          #pragma omp parallel num_threads (5) proc_bind (close)
          {
            if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
              abort();

            if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            ;
            {
              struct place p = places_array[0].places[0];
              int thr = omp_get_thread_num();
              printf("#3,#2,#2 thread 2,3,%d", thr);
              if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
                switch (places_array[test_places].count)
              {
                case 8:
                  p = places_array[test_places].places[6 + ((thr & 2) / 2)];
                  break;

                case 7:
                  p = places_array[test_places].places[6];
                  break;

                case 5:
                  p = places_array[test_places].places[4];
                  break;

                case 3:
                  p = places_array[test_places].places[0];
                  break;

                case 2:
                  p = places_array[test_places].places[1];
                  break;

              }


              print_affinity(p);
              printf("\n");
            }
          }
        }

      }
      #pragma omp parallel num_threads (4) proc_bind(master)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#3,#3 thread 2,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[0];

          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (6) proc_bind (close)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#3,#4 thread 2,%d", thr);
          if ((omp_get_num_threads() == 6) && (test_spread_master_close || test_true))
            switch (places_array[test_places].count)
          {
            case 8:

            case 7:
              p = places_array[test_places].places[thr];
              break;

            case 5:
              p = places_array[test_places].places[(thr == 5) ? (0) : (thr)];
              break;

            case 3:
              p = places_array[test_places].places[thr / 2];
              break;

            case 2:
              p = places_array[test_places].places[thr / 3];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
      }
    }

  }
  #pragma omp parallel num_threads (5) proc_bind(close)
  {
    if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
      abort();

    if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
      abort();

    if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_master))
      abort();

    ;
    {
      struct place p = places_array[0].places[0];
      int thr = omp_get_thread_num();
      printf("#4 thread %d", thr);
      if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
        switch (places_array[test_places].count)
      {
        case 8:

        case 7:

        case 5:
          p = places_array[test_places].places[thr];
          break;

        case 3:
          p = places_array[test_places].places[(thr >= 3) ? (thr - 3) : (thr)];
          break;

        case 2:
          p = places_array[test_places].places[(thr == 4) ? (0) : (thr / 2)];
          break;

      }


      print_affinity(p);
      printf("\n");
    }
    #pragma omp barrier
    if (omp_get_thread_num() == 2)
    {
      int pp = 0;
      switch (places_array[test_places].count)
      {
        case 8:

        case 7:

        case 5:

        case 3:
          pp = 2;
          break;

        case 2:
          pp = 1;
          break;

      }

      #pragma omp parallel num_threads (4) firstprivate (pp)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#4,#1 thread 2,%d", thr);
          if (test_spread_master_close)
            p = places_array[test_places].places[pp];
          else
            if ((omp_get_num_threads() == 4) && test_true)
            switch (places_array[test_places].count)
          {
            case 8:

            case 7:
              p = places_array[test_places].places[2 + thr];
              break;

            case 5:
              p = places_array[test_places].places[(thr == 3) ? (0) : (2 + thr)];
              break;

            case 3:
              p = places_array[test_places].places[(2 + thr) % 3];
              break;

            case 2:
              p = places_array[test_places].places[1 - (thr / 2)];
              break;

          }



          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (4) proc_bind (spread)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_spread))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#4,#2 thread 2,%d", thr);
          if ((omp_get_num_threads() == 4) && (test_spread_master_close || test_true))
            switch (places_array[test_places].count)
          {
            case 8:

            case 7:
              p = places_array[test_places].places[(thr == 3) ? (0) : (2 + (2 * thr))];
              break;

            case 5:
              p = places_array[test_places].places[(thr == 3) ? (0) : (2 + thr)];
              break;

            case 3:
              p = places_array[test_places].places[(thr == 0) ? (2) : (thr - 1)];
              break;

            case 2:
              p = places_array[test_places].places[1 - (thr / 2)];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
        #pragma omp barrier
        if (omp_get_thread_num() == 0)
        {
          #pragma omp parallel num_threads (5) proc_bind (close)
          {
            if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
              abort();

            if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            ;
            {
              struct place p = places_array[0].places[0];
              int thr = omp_get_thread_num();
              printf("#4,#2,#1 thread 2,0,%d", thr);
              if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
                switch (places_array[test_places].count)
              {
                case 8:

                case 7:
                  p = places_array[test_places].places[2 + ((thr & 2) / 2)];
                  break;

                case 5:

                case 3:
                  p = places_array[test_places].places[2];
                  break;

                case 2:
                  p = places_array[test_places].places[1];
                  break;

              }


              print_affinity(p);
              printf("\n");
            }
          }
        }

        #pragma omp barrier
        if (omp_get_thread_num() == 2)
        {
          #pragma omp parallel num_threads (5) proc_bind (close)
          {
            if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
              abort();

            if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            ;
            {
              struct place p = places_array[0].places[0];
              int thr = omp_get_thread_num();
              printf("#4,#2,#2 thread 2,2,%d", thr);
              if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
                switch (places_array[test_places].count)
              {
                case 8:
                  p = places_array[test_places].places[6 + ((thr & 2) / 2)];
                  break;

                case 7:
                  p = places_array[test_places].places[6];
                  break;

                case 5:
                  p = places_array[test_places].places[4];
                  break;

                case 3:
                  p = places_array[test_places].places[1];
                  break;

                case 2:
                  p = places_array[test_places].places[0];
                  break;

              }


              print_affinity(p);
              printf("\n");
            }
          }
        }

        #pragma omp barrier
        if (omp_get_thread_num() == 3)
        {
          #pragma omp parallel num_threads (5) proc_bind (close)
          {
            if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
              abort();

            if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
              abort();

            ;
            {
              struct place p = places_array[0].places[0];
              int thr = omp_get_thread_num();
              printf("#4,#2,#3 thread 2,3,%d", thr);
              if ((omp_get_num_threads() == 5) && (test_spread_master_close || test_true))
                switch (places_array[test_places].count)
              {
                case 8:

                case 7:

                case 5:
                  p = places_array[test_places].places[(thr & 2) / 2];
                  break;

                case 3:
                  p = places_array[test_places].places[2];
                  break;

                case 2:
                  p = places_array[test_places].places[0];
                  break;

              }


              print_affinity(p);
              printf("\n");
            }
          }
        }

      }
      #pragma omp parallel num_threads (4) proc_bind(master) firstprivate (pp)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_master))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#4,#3 thread 2,%d", thr);
          if (test_spread_master_close || test_true)
            p = places_array[test_places].places[pp];

          print_affinity(p);
          printf("\n");
        }
      }
      #pragma omp parallel num_threads (6) proc_bind (close)
      {
        if (test_false && (omp_get_proc_bind() != omp_proc_bind_false))
          abort();

        if (test_true && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        if (test_spread_master_close && (omp_get_proc_bind() != omp_proc_bind_close))
          abort();

        ;
        {
          struct place p = places_array[0].places[0];
          int thr = omp_get_thread_num();
          printf("#4,#4 thread 2,%d", thr);
          if ((omp_get_num_threads() == 6) && (test_spread_master_close || test_true))
            switch (places_array[test_places].count)
          {
            case 8:
              p = places_array[test_places].places[2 + thr];
              break;

            case 7:
              p = places_array[test_places].places[(thr == 5) ? (0) : (2 + thr)];
              break;

            case 5:
              p = places_array[test_places].places[(thr >= 3) ? (thr - 3) : (2 + thr)];
              break;

            case 3:
              p = places_array[test_places].places[(thr < 2) ? (2) : ((thr / 2) - 1)];
              break;

            case 2:
              p = places_array[test_places].places[1 - (thr / 3)];
              break;

          }


          print_affinity(p);
          printf("\n");
        }
      }
    }

  }
  return 0;
}

