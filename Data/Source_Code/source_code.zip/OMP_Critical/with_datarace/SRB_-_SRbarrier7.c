void SRbarrier7(int *count, int *sense, int *local_sense, unsigned int *local_spin_count)
{
  *local_sense = !(*local_sense);
  {
    *count = (*count) - 1;
    if ((*count) == 0)
    {
      *count = omp_get_num_threads();
      *sense = *local_sense;
    }

  }
  int delay = LB_DELAY;
  while ((*sense) != (*local_sense))
  {
    (*local_spin_count)++;
    usleep(delay);
    delay = delay + DELAY_RATE;
  }

  ;
}

