static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int flag;
void func_critical()
{
  int id = omp_get_thread_num();
  switch (id)
  {
    case 0:
    {
      flag = 1;
      while (flag != 2)
      {
        #pragma omp flush
      }

    }
      break;

    case 1:
    {
      while (flag != 1)
      {
        #pragma omp flush
      }

      flag = 2;
    }
      break;

    default:
      break;

  }

}

