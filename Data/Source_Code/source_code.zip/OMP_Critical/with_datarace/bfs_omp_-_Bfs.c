{
  int capacity;
  int size;
  int front;
  int rear;
  int *elements;
} Queue;
int *visited;
void Bfs(int **graph, int *size, int presentVertex, int *visited)
{
  visited[presentVertex] = 1;
  Queue *Q = CreateQueue(100000);
  Enqueue(Q, presentVertex);
  int iter;
  int semaphore = 6;
  omp_set_num_threads(6);
  #pragma omp shared(visited, graph, presentVertex, semaphore) private(iter)
  {
    while (Q->size)
    {
      presentVertex = Dequeue(Q);
      if (presentVertex == (-1))
        return;

      #pragma omp parallel for
      for (iter = 0; iter < size[presentVertex]; iter++)
      {
        if (!visited[graph[presentVertex][iter]])
        {
          visited[graph[presentVertex][iter]] = 1;
          Enqueue(Q, graph[presentVertex][iter]);
        }

      }

    }

  }
  return;

  #pragma omp critical
  suma += array[indice];
}

