int NUM_THREADS;
int count;
void OMP_sense_reversal_barrier(int *local_sense, int *sense)
{
  int local_count;
  *local_sense = !(*local_sense);
  {
    local_count = --count;
  }
  if (local_count == 0)
  {
    count = NUM_THREADS;
    *sense = *local_sense;
  }
  else
    while ((*sense) != (*local_sense))
    ;



  static int err;
  int id = omp_get_thread_num();
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    #pragma omp critical
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    #pragma omp critical
    errors++;
  }

  if ((sizeof(prvt)) != (sizeof(long)))
  {
    #pragma omp critical
    errors += 1;
  }

}

