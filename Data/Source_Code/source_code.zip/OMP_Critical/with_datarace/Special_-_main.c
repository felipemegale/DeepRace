struct block
{
  timer_start();
  double cx;
  double cy;
  double zx;
  double zy;
  double new_zx;
  unsigned char n;
  int nx;
  int ny;
  int cx_iter;
  int cy_iter;
  int xmin_iter = (int) (xMin * 1000);
  int ymin_iter = (int) (yMin * 1000);
  int xmax_iter = (int) (xMax * 1000);
  int ymax_iter = (int) (yMax * 1000);
  int dxy_iter = (int) (dxy * 1000);
  for (cy_iter = ymin_iter; cy_iter < ymax_iter; cy_iter += dxy_iter)
  {
    #pragma omp parallel for shared(cy_iter)
    for (cx_iter = xmin_iter; cx_iter <= xmax_iter; cx_iter += dxy_iter)
    {
      cx = ((double) cx_iter) / 1000;
      cy = ((double) cy_iter) / 1000;
      zx = 0.0;
      zy = 0.0;
      n = 0;
      while ((((zx * zx) + (zy * zy)) < 4.0) && (n != 255))
      {
        new_zx = ((zx * zx) - (zy * zy)) + cx;
        zy = ((2.0 * zx) * zy) + cy;
        zx = new_zx;
        n++;
      }

      #pragma omp critical
      {
        write(1, &n, sizeof(n));
      }
    }

  }

  nx = 0;
  ny = 0;
  for (cx = xMin; cx < xMax; cx += dxy)
  {
    nx++;
  }

  for (cy = yMin; cy < yMax; cy += dxy)
  {
    ny++;
  }

  fprintf(stderr, "To process the image: convert -depth 8 -size %dx%d gray:output out.jpg\n", nx, ny);
  double elapsed = timer_end();
  fprintf(stderr, "Time elapsed: %f seconds\n", elapsed);
  return 0;

  int col_index;
  int row1;
  int row2;
  int row3;
  int row4;
  long long signature;
};
struct DIA_SET
{
  int collection[100];
  int col_index;
  int size;
};
long long *KEYS;
struct block b;
struct block *Big_Block;
int NUM_OF_BLOCK = 0;
int BLOCK_INDEX = 0;
struct DIA_SET one_dia_set;
struct DIA_SET dias[100000];
int NUM_OF_DIA_SET = 0;
double **readMatrix(char *fileName);
void readKey(char *fileName);
double *readCol(double **jz, int col_number, int row_size);
void collection(double *one_column, int col_num, int start, int row_size);
void add_to_dia_set(int *collection, int col_number, int size);
int get_combination_size(int n, int m);
int **combNonRec(int collect[], int sizeOfColl, int sizeOut);
long long getKey(int row_index);
void create_Block(int arr[], int COL_INDEX);
void add_To_Block_Collection();
int main(void)
{
  clock_t begin = clock();
  readKey("keys.txt");
  double **jz = readMatrix("data.txt");
  int j = 0;
  int i = 0;
  int k = 0;
  #pragma omp parallel for
  for (i = 0; i < 100; i++)
  {
    printf("THIS IS COLUMN %d\n", i);
    double *c = readCol(jz, i, 4400);
    #pragma omp parallel for shared(i)
    for (j = 0; j < 4400; j++)
    {
      collection(c, i, j, 4400);
    }

    free(c);
  }

  printf("NUM_OF_DIA_SET is %d\n", NUM_OF_DIA_SET);
  int dia_index = 0;
  #pragma omp parallel for shared(NUM_OF_DIA_SET,NUM_OF_BLOCK)
  for (dia_index = 0; dia_index < NUM_OF_DIA_SET; dia_index++)
  {
    int size = dias[dia_index].size;
    int combination_size = get_combination_size(dias[dia_index].size, 4);
    #pragma omp parallel for shared(NUM_OF_DIA_SET,NUM_OF_BLOCK,dia_index,combination_size)
    for (k = 0; k < combination_size; k++)
    {
      #pragma omp atomic
      NUM_OF_BLOCK++;
    }

  }

  printf("NUM_OF_BLOCK is %d\n", NUM_OF_BLOCK);
  if ((Big_Block = (struct block *) calloc(NUM_OF_BLOCK, sizeof(struct block))) != 0)
  {
    for (dia_index = 0; dia_index < NUM_OF_DIA_SET; dia_index++)
    {
      int **rrr = combNonRec(dias[dia_index].collection, dias[dia_index].size, 4);
      #pragma omp parallel for shared(NUM_OF_DIA_SET,NUM_OF_BLOCK,dia_index,BLOCK_INDEX)
      for (k = 0; k < get_combination_size(dias[dia_index].size, 4); k++)
      {
        {
          create_Block(rrr[k], dias[dia_index].col_index);
          add_To_Block_Collection();
          BLOCK_INDEX++;
        }
      }

      free(rrr);
    }

  }
  else
  {
    printf("Calloc for big_Block fails\n");
    exit(1);
  }

  collision();
  clock_t end = clock();
  double time_spent = ((double) (end - begin)) / CLOCKS_PER_SEC;
  printf("Total time spent : %f\n", time_spent);
  printf("The size of block is %d", NUM_OF_BLOCK);
  free(jz);
  free(Big_Block);
  free(KEYS);
  exit(0);
}

