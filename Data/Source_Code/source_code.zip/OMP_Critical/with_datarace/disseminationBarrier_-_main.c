{
  int myflags[2][8];
  int *partnerFlags[2][8];
} Flags;
void disseminationBarrier(Flags *localFlags, int *sense, int *rounds, int *parity);
int main(int argc, char *argv[])
{
  int NUM_THREADS;
  int NUM_BARRIERS;
  int nPrime;
  if (argc == 4)
  {
    NUM_THREADS = atoi(argv[1]);
    NUM_BARRIERS = atoi(argv[2]);
    nPrime = atoi(argv[3]);
  }
  else
  {
    printf("Syntax : ./Dissemination <#number of threads>  <#num of barriers> <prime_count>");
    exit(-1);
  }

  Flags totalProcessors[NUM_THREADS];
  int rounds = ceil(log(NUM_THREADS) / log(2));
  ;
  omp_set_num_threads(NUM_THREADS);
  double totalTime = 0;
  int i;
  int p;
  int j;
  for (i = 0; i < NUM_THREADS; i++)
    for (p = 0; p < 2; p++)
    for (j = 0; j < rounds; j++)
    totalProcessors[i].myflags[p][j] = 0;



  #pragma omp parallel
  {
    int totalThreads = omp_get_num_threads();
    int threadNum = omp_get_thread_num();
    double elapsedTime = 0.0;
    struct timeval startTime;
    struct timeval endTime;
    int parity = 0;
    int sense = 1;
    int i;
    int p;
    int j;
    int k;
    int notifyNodes;
    Flags *localFlags = &totalProcessors[threadNum];
    for (j = 0; j < NUM_BARRIERS; j++)
    {
      long a = getPrime(nPrime);
      printf("Thread %d entering barrier %d\n", threadNum, j);
      for (k = 0; k < rounds; k++)
      {
        notifyNodes = ceil(pow(2, k));
        int i = (threadNum + notifyNodes) % totalThreads;
        totalProcessors[threadNum].partnerFlags[0][k] = &totalProcessors[i].myflags[0][k];
        totalProcessors[threadNum].partnerFlags[1][k] = &totalProcessors[i].myflags[1][k];
      }

      gettimeofday(&startTime, 0);
      disseminationBarrier(localFlags, &sense, &rounds, &parity);
      gettimeofday(&endTime, 0);
      elapsedTime += (endTime.tv_sec - startTime.tv_sec) * 1000.0;
      elapsedTime += (endTime.tv_usec - startTime.tv_usec) / 1000.0;
      printf("Thread %d exiting barrier %d\n", threadNum, j);
    }

    {
      totalTime += elapsedTime;
    }
  }
  printf("Total time spent per barrier averaged over NUM_BARRIERS is %f \n", totalTime / ((NUM_BARRIERS * NUM_THREADS) * 1.0));
}

