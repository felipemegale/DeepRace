struct Complex
{
  int ix_next;
  int iy_next;
  #pragma omp parallel shared(x, y) private(ix_next, iy_next)
  {
    #pragma omp critical (xaxis) hint(omp_lock_hint_contended)
    ix_next = dequeue(x);
    work(ix_next, x);
    #pragma omp critical (yaxis) hint(omp_lock_hint_contended)
    iy_next = dequeue(y);
    work(iy_next, y);
  }

  float real;
  float imaginary;
};
struct Matrix
{
  struct Complex **cell;
  int size;
};
struct Index
{
  int column;
  int line;
};
void find_min_max_omp(int thread_number, struct Matrix x, float *min, struct Index *index_min, float *max, struct Index *index_max)
{
  float shared_min = 32767;
  float shared_max = INT_MIN;
  struct Index shared_index_min;
  struct Index shared_index_max;
  #pragma omp parallel num_threads(thread_number)
  {
    float private_min = 32767;
    float private_max = INT_MIN;
    struct Index private_index_min;
    struct Index private_index_max;
    int i;
    int j;
    #pragma omp for nowait
    for (i = 0; i < x.size; i++)
    {
      for (j = 0; j < x.size; j++)
      {
        if (complex_radius(x.cell[i][j]) > private_max)
        {
          private_max = complex_radius(x.cell[i][j]);
          private_index_max.column = i;
          private_index_max.line = j;
        }

        if (complex_radius(x.cell[i][j]) < private_min)
        {
          private_min = complex_radius(x.cell[i][j]);
          private_index_min.column = i;
          private_index_min.line = j;
        }

      }

    }

    {
      if (private_max > shared_max)
      {
        shared_max = private_max;
        shared_index_max = private_index_max;
      }

      if (private_min < shared_min)
      {
        shared_min = private_min;
        shared_index_min = private_index_min;
      }

    }
  }
  *min = shared_min;
  *max = shared_max;
  *index_max = shared_index_max;
  *index_min = shared_index_min;
}

