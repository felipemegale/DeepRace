extern const struct training_set ts;
extern const struct settings s;
extern const float ionenergies[];
extern const float affinities[];
int minimize_part_of_gm_set(struct subset *ss, int min_iterations)
{
  assert(ss != 0);
  int quite_good = 0;
  int i = 0;
  #pragma omp parallel for num_threads(s.om_threads) shared(ss, quite_good) private(i)
  for (i = 0; i < ss->kappa_data_count; i++)
  {
    if ((ss->data[i].full_stats.R2 > 0.2) && (ss->data[i].full_stats.R > 0))
    {
      {
        quite_good++;
      }
      struct kappa_data *m = (struct kappa_data *) malloc(sizeof(struct kappa_data));
      kd_init(m);
      m->parent_subset = ss;
      kd_copy_parameters(&ss->data[i], m);
      minimize_locally(m, min_iterations);
      kd_copy_parameters(m, &ss->data[i]);
      kd_destroy(m);
      free(m);
    }

  }

  if (s.verbosity >= VERBOSE_KAPPA)
  {
    printf("Out of %d in population, we minimized %d\n", ss->kappa_data_count, quite_good);
  }

  return quite_good;

  int sum = 7;
  int sum0 = 0;
  int known_sum;
  int i;
  #pragma omp parallel
  {
    #pragma omp sections private(sum0,i)
    {
      #pragma omp section
      {
        sum0 = 0;
        for (i = 1; i < 400; i++)
          sum0 = sum0 + i;

        #pragma omp critical
        {
          sum = sum + sum0;
        }
      }
      #pragma omp section
      {
        sum0 = 0;
        for (i = 400; i < 700; i++)
          sum0 = sum0 + i;

        #pragma omp critical
        {
          sum = sum + sum0;
        }
      }
      #pragma omp section
      {
        sum0 = 0;
        for (i = 700; i < 1000; i++)
          sum0 = sum0 + i;

        #pragma omp critical
        {
          sum = sum + sum0;
        }
      }
    }
  }
  known_sum = ((999 * 1000) / 2) + 7;
  return known_sum == sum;
}

