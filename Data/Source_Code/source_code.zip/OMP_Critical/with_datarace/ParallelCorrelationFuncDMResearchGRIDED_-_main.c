int main(int argc, char **argv)
{
  int **myImage;
  int **activeAldo;
  int imgRows = 0;
  int imgCols = 0;
  int i = 0;
  int j = 0;
  int k = 0;
  int l = 0;
  int inImgRow = 0;
  int inImgCol = 0;
  int rowMod = 0;
  int colMod = 0;
  int activeRow = 0;
  int activeCol = 0;
  int rotation = 0;
  int found;
  int noImagesLeft = 0;
  char myFilename[20];
  char dump[100];
  char inStr[10];
  char *token;
  FILE *fp;
  while (1)
  {
    found = 0;
    #pragma omp critical
    {
      strcpy(myFilename, imageData.name);
      fp = fopen(myFilename, "r");
      printf("Filename %s T%d\n", myFilename, index);
      if (fp == 0)
      {
        noImagesLeft = 1;
      }

      if (0 != _findnext(imageID, &imageData))
      {
        noImagesLeft = 1;
      }

    }
    if (noImagesLeft == 1)
      return;

    fgets(inStr, 10, fp);
    token = strtok(inStr, " ");
    imgRows = atoi(token);
    token = strtok(0, " ");
    imgCols = atoi(token);
    myImage = (int **) malloc((sizeof(int *)) * imgRows);
    for (i = 0; i < imgRows; i++)
    {
      myImage[i] = (int *) malloc((sizeof(int)) * imgCols);
    }

    for (i = 0; i < imgRows; i++)
    {
      for (j = 0; j < imgCols; j++)
      {
        myImage[i][j] = fgetc(fp) - '0';
      }

      fgets(dump, 100, fp);
    }

    for (i = 0; i < numAldos; i++)
    {
      if ((!(allAldoRows[i] > imgRows)) && (!(allAldoCols[i] > imgCols)))
      {
        for (j = 0; j < 4; j++)
        {
          switch (j)
          {
            case 0:
              activeRow = allAldoRows[i];
              activeCol = allAldoCols[i];
              colMod = 0;
              rowMod = 0;
              rotation = 0;
              activeAldo = aldos[i];
              break;

            case 1:
              activeRow = allAldoCols[i];
              activeCol = allAldoRows[i];
              colMod = allAldoCols[i];
              rowMod = 0;
              rotation = 90;
              activeAldo = aldos90[i];
              break;

            case 2:
              activeRow = allAldoRows[i];
              activeCol = allAldoCols[i];
              colMod = allAldoCols[i];
              rowMod = allAldoRows[i];
              rotation = 180;
              activeAldo = aldos180[i];
              break;

            case 3:
              activeRow = allAldoCols[i];
              activeCol = allAldoRows[i];
              colMod = 0;
              rowMod = allAldoRows[i];
              rotation = 270;
              activeAldo = aldos[i];
              break;

          }

          for (inImgRow = 0; inImgRow < (imgRows - activeRow); inImgRow++)
          {
            for (inImgCol = 0; inImgCol < (imgCols - activeCol); inImgCol++)
            {
              k = 0;
              l = 0;
              while (((k < activeRow) && ((inImgRow + k) < (imgRows - 1))) && (myImage[inImgRow + k][inImgCol + l] == activeAldo[k][l]))
              {
                l++;
                if (l == (allAldoCols[i] - 1))
                {
                  if (k == (allAldoRows[i] - 1))
                  {
                    printf("$%s %s (%d,%d,%d)\n", aldoFileNames[i], myFilename, (inImgRow + rowMod) + 1, (inImgCol + colMod) + 1, rotation);
                    found = 1;
                    break;
                  }

                  k++;
                  l = 0;
                }

                if (found == 1)
                  break;

              }

              if (found == 1)
                break;

            }

            if (found == 1)
              break;

          }

          if (found == 1)
            break;

        }

      }

      if (found == 1)
        break;

    }

    fclose(fp);
    fp = 0;
    for (i = 0; i < imgRows; i++)
    {
      free(myImage[i]);
    }

    free(myImage);
  }

  return;

  printf("FIRST line of MAIN\n");
  long int i;
  long int j;
  printf("argc: %d\n", argc);
  if (argc != 2)
  {
    printf("Usage: bash %s arg1\n", argv[0]);
    printf("where arg1 is the NUM_OF_THREADS (integer <= 32)\n");
    exit(0);
  }

  int k = 1;
  int temp_value = 0;
  int num_threads_set = 0;
  if (argc > 1)
  {
    temp_value = atoi(argv[k]);
    if ((temp_value > 0) && (temp_value < 32))
    {
      num_threads_set = atoi(argv[k]);
    }

  }
  else
  {
    num_threads_set = 16;
  }

  int periodic_boundary_conditions = 1;
  int chunk;
  int tid;
  int nthreads;
  double dec_to_rad = (2. * 3.14159621234161928) / 360.;
  double deg_to_rad = (2. * 3.14159621234161928) / 360.;
  const int num_bins = 10;
  double bin_counts[10] = {0.0};
  double r_min = 0.1675;
  double r_max = 5.7885;
  double logrNOTSQUARED_min = log10(r_min);
  double logrNOTSQUARED_max = log10(r_max);
  double logr_min = log10(pow(pow(10., logrNOTSQUARED_min), 2.));
  double logr_max = log10(pow(pow(10., logrNOTSQUARED_max), 2.));
  long int errorcounts = 0;
  long int distance_counts[10] = {0};
  long int randdistance_counts[10] = {0};
  double Xi_func[10] = {0.0};
  int dist_index;
  long int FILELENGTHDM = 66659;
  long int FILELENGTHDMrand = 250000;
  long int N_rand = FILELENGTHDMrand;
  int box_side_length = 1;
  int gridx_LIST[N_rand];
  int gridy_LIST[N_rand];
  int gridz_LIST[N_rand];
  double D;
  double logD;
  double actual_D;
  double logactual_D;
  double actual_Ddist_index;
  double r = 0;
  double x1 = 0;
  double y1 = 0;
  double z1 = 0;
  double rj = 0;
  double x2 = 0;
  double y2 = 0;
  double z2 = 0;
  double delx;
  double dely;
  double delz;
  chunk = 100;
  float grid_binmax = box_side_length;
  float grid_binmin = 0;
  int grid_numbins = 10;
  int grid_x1;
  int grid_y1;
  int grid_z1;
  int grid_x2;
  int grid_y2;
  int grid_z2;
  int gxvar;
  int grid_x_check;
  int grid_y_check;
  int grid_z_check;
  int grid_x_pbc;
  int grid_y_pbc;
  int grid_z_pbc;
  int grid_x_norm;
  int grid_y_norm;
  int grid_z_norm;
  static const char random_datafile[] = "/scratch/chasonnscr/random/DM_randomResearch.dat";
  if (!periodic_boundary_conditions)
  {
    FILE *myrandfile = fopen(random_datafile, "r");
    if (myrandfile == 0)
    {
      printf("DM_random.dat not opened, trying local filepath...\n");
      static const char random_datafile[] = "./DM_random.dat";
      myrandfile = fopen(random_datafile, "r");
      if (myrandfile == 0)
      {
        printf("DM_random.dat not opened, exiting...\n");
        exit(0);
      }

    }

    double randX_LIST[N_rand];
    double randY_LIST[N_rand];
    double randZ_LIST[N_rand];
    for (i = 0; i < N_rand; ++i)
    {
      fscanf(myrandfile, "%lf", &randX_LIST[i]);
      fscanf(myrandfile, "%lf", &randY_LIST[i]);
      fscanf(myrandfile, "%lf", &randZ_LIST[i]);
      if (randX_LIST[i] > ((float) box_side_length))
      {
        box_side_length = (int) ceil(randX_LIST[i]);
      }

      if (i >= (N_rand - 1))
      {
        printf("Close or exceeded N_data limit. X: %lf \n", randX_LIST[i]);
      }

    }

    grid_numbins = floor(grid_binmax / r_max);
    printf("Final Grid Bin Resolution: %d Bins......\n", grid_numbins);
    float grid_normalization = grid_numbins / grid_binmax;
    float grid_binwidth = grid_binmax / grid_numbins;
    printf("Final Grid Binwidth: %f width [mpc]\n", grid_binwidth);
    fclose(myrandfile);
    printf("Closing File.\n");
    #pragma simd
    for (i = 0; i < N_rand; ++i)
    {
      gridx_LIST[i] = (int) floor(randX_LIST[i] * grid_normalization);
      gridy_LIST[i] = (int) floor(randY_LIST[i] * grid_normalization);
      gridz_LIST[i] = (int) floor(randZ_LIST[i] * grid_normalization);
    }

    printf("Beginning Random Nested Loops...\n");
    #pragma omp parallel shared( randZ_LIST, randY_LIST, randX_LIST, gridx_LIST, gridy_LIST, gridz_LIST, grid_numbins, N_rand,chunk, num_threads_set) private (D, logD, actual_D, logactual_D, x1, y1, z1, x2, y2, z2, delx, dely, delz, dist_index, i, j,grid_x1, grid_y1, grid_z1, grid_x2, grid_y2, grid_z2, grid_x_check,grid_y_check,grid_z_check, grid_x_pbc,grid_y_pbc,grid_z_pbc, grid_x_norm, grid_y_norm,grid_z_norm)
    {
      omp_set_num_threads(num_threads_set);
      long int sum_local_counts[10];
      memset(sum_local_counts, 0, 10 * (sizeof(sum_local_counts[0])));
      #pragma omp for schedule(guided, chunk)
      for (i = 0; i < (N_rand - 1); ++i)
      {
        x1 = randX_LIST[i];
        y1 = randY_LIST[i];
        z1 = randZ_LIST[i];
        grid_x1 = gridx_LIST[i];
        grid_y1 = gridy_LIST[i];
        grid_z1 = gridz_LIST[i];
        for (j = 0; j < (N_rand - 1); ++j)
        {
          if (j != i)
          {
            x2 = randX_LIST[j];
            y2 = randY_LIST[j];
            z2 = randZ_LIST[j];
            grid_x2 = gridx_LIST[j];
            grid_y2 = gridy_LIST[j];
            grid_z2 = gridz_LIST[j];
            grid_x_norm = ((grid_x1 == grid_x2) || (grid_x1 == (grid_x2 + 1))) || (grid_x1 == (grid_x2 - 1));
            grid_y_norm = ((grid_y1 == grid_y2) || (grid_y1 == (grid_y2 + 1))) || (grid_y1 == (grid_y2 - 1));
            grid_z_norm = ((grid_z1 == grid_z2) || (grid_z1 == (grid_z2 + 1))) || (grid_z1 == (grid_z2 - 1));
            grid_x_pbc = ((grid_x1 == (grid_numbins - 1)) && (grid_x2 == 0)) || ((grid_x2 == (grid_numbins - 1)) && (grid_x1 == 0));
            grid_y_pbc = ((grid_y1 == (grid_numbins - 1)) && (grid_y2 == 0)) || ((grid_y2 == (grid_numbins - 1)) && (grid_y1 == 0));
            grid_z_pbc = ((grid_z1 == (grid_numbins - 1)) && (grid_z2 == 0)) || ((grid_z2 == (grid_numbins - 1)) && (grid_z1 == 0));
            grid_x_check = grid_x_norm || grid_x_pbc;
            grid_y_check = grid_y_norm || grid_y_pbc;
            grid_z_check = grid_z_norm || grid_z_pbc;
            if ((grid_x_check && grid_y_check) && grid_z_check)
            {
              delx = fabs(x1 - x2);
              dely = fabs(y1 - y2);
              delz = fabs(z1 - z2);
              if (delx > (2. * grid_binwidth))
              {
                if (x1 > x2)
                {
                  delx = (x2 + grid_binmax) - x1;
                }
                else
                {
                  delx = (x1 + grid_binmax) - x2;
                }

              }

              if (dely > (2. * grid_binwidth))
              {
                if (y1 > y2)
                {
                  dely = (y2 + grid_binmax) - y1;
                }
                else
                {
                  dely = (y1 + grid_binmax) - y2;
                }

              }

              if (delz > (2. * grid_binwidth))
              {
                if (z1 > z2)
                {
                  delz = (z2 + grid_binmax) - z1;
                }
                else
                {
                  delz = (z1 + grid_binmax) - z2;
                }

              }

              D = ((delx * delx) + (dely * dely)) + (delz * delz);
              logD = log10(D);
              if (logD < logr_max)
              {
                dist_index = (int) floor((logD - logr_min) * (10 / (logr_max - logr_min)));
                if ((dist_index >= 0) && (dist_index < 10))
                {
                  sum_local_counts[dist_index] += 1;
                }

              }

            }

          }

        }

      }

      {
        for (i = 0; i < 10; ++i)
        {
          randdistance_counts[i] += sum_local_counts[i];
        }

      }
    }
    printf("\n*");
    printf("\n   *");
    printf("\n     *");
    printf("\n       *");
    printf("\n      *");
    printf("\n     *");
    printf("\n    *");
    printf("\n   *        *");
    printf("\n   *");
    printf("\n     *");
    printf("\n      *");
    printf("\n       **");
    printf("\n        * *");
    printf("\n        * * *");
    printf("\n       * * * *\n");
    printf("************************************\n");
    printf("FINISHED DM RAND PRAGMA OMP CRITICAL\n");
    printf("************************************\n");
    printf("FINISHED RANDOM NESTED LOOPS! \n");
    printf("Counts: ");
    #pragma simd
    for (i = 0; i < 10; ++i)
    {
      randdistance_counts[i] = (long long) floor(randdistance_counts[i] / 2.);
    }

    printf("\n");
  }

  char DM_datafile[100];
  int filenum = 0;
  int max_filenum = 1;
  for (filenum = 0; filenum < max_filenum; filenum++)
  {
    sprintf(DM_datafile, "/scratch/chasonnscr/positdirHPC/PositionXYZdatafile%d.dat", filenum);
    FILE *myfile = fopen(DM_datafile, "r");
    if (myfile == 0)
    {
      printf("DM.dat not opened, trying local filepath...DM.dat\n");
      static const char DM_datafile[] = "./DM.dat";
      myfile = fopen(DM_datafile, "r");
      if (myfile == 0)
      {
        printf("DM.dat not opened, exiting...\n");
        exit(0);
      }

    }

    printf("Opened file - Begining assignment.\n");
    long int N_data = FILELENGTHDM;
    double X_LIST[N_data];
    double Y_LIST[N_data];
    double Z_LIST[N_data];
    i = 0;
    while ((i < N_data) && (!feof(myfile)))
    {
      fscanf(myfile, "%lf", &X_LIST[i]);
      fscanf(myfile, "%lf", &Y_LIST[i]);
      fscanf(myfile, "%lf", &Z_LIST[i]);
      if (X_LIST[i] > ((float) box_side_length))
      {
        box_side_length = (int) ceil(X_LIST[i]);
      }

      if (i >= (N_data - 1))
      {
        printf("Close or exceeded N_data limit. X: %lf \n", X_LIST[i]);
      }

      ++i;
    }

    fclose(myfile);
    printf("Closing File.\n");
    grid_binmax = box_side_length;
    grid_numbins = floor(grid_binmax / r_max);
    printf("Final Grid Bin Resolution: %d Bins......\n", grid_numbins);
    float grid_normalization = grid_numbins / grid_binmax;
    float grid_binwidth = grid_binmax / grid_numbins;
    printf("Final Grid Binwidth: %f width [mpc]\n", grid_binwidth);
    printf("correcting N_data size, due to different datafile. N_data: %ld i: %ld\n", N_data, i);
    N_data = i;
    #pragma simd
    for (i = 0; i < N_rand; ++i)
    {
      gridx_LIST[i] = (int) floor(X_LIST[i] * grid_normalization);
      gridy_LIST[i] = (int) floor(Y_LIST[i] * grid_normalization);
      gridz_LIST[i] = (int) floor(Z_LIST[i] * grid_normalization);
    }

    printf("Beginning Nested Loops...\n");
    printf("Note: using Distance Squared to avoid taking SQRT for index rank.\n");
    #pragma omp parallel shared( Z_LIST, Y_LIST, X_LIST, gridx_LIST, gridy_LIST, gridz_LIST, grid_numbins, N_data, chunk, num_threads_set) private (D, logD, x1, y1, z1, x2, y2, z2, dist_index, i, j, tid, grid_x1, grid_y1, grid_z1, grid_x2, grid_y2, grid_z2, grid_x_check, grid_y_check, grid_z_check)
    {
      omp_set_num_threads(num_threads_set);
      long int sum_local_counts[10];
      memset(sum_local_counts, 0, 10 * (sizeof(sum_local_counts[0])));
      tid = omp_get_thread_num();
      if (tid == 0)
      {
        nthreads = omp_get_num_threads();
        printf("thread id: %d, num threads: %d \n", tid, nthreads);
      }

      #pragma omp for schedule(guided, chunk)
      for (i = 0; i < (N_data - 1); ++i)
      {
        x1 = X_LIST[i];
        y1 = Y_LIST[i];
        z1 = Z_LIST[i];
        grid_x1 = gridx_LIST[i];
        grid_y1 = gridy_LIST[i];
        grid_z1 = gridz_LIST[i];
        for (j = 0; j < (N_data - 1); ++j)
        {
          if (j != i)
          {
            x2 = X_LIST[j];
            y2 = Y_LIST[j];
            z2 = Z_LIST[j];
            grid_x2 = gridx_LIST[j];
            grid_y2 = gridy_LIST[j];
            grid_z2 = gridz_LIST[j];
            grid_x_check = ((((grid_x1 == grid_x2) || (grid_x1 == (grid_x2 + 1))) || (grid_x1 == (grid_x2 - 1))) || ((grid_x1 == (grid_numbins - 1)) && (grid_x2 == 0))) || ((grid_x2 == (grid_numbins - 1)) && (grid_x1 == 0));
            grid_y_check = ((((grid_y1 == grid_y2) || (grid_y1 == (grid_y2 + 1))) || (grid_y1 == (grid_y2 - 1))) || ((grid_y1 == (grid_numbins - 1)) && (grid_y2 == 0))) || ((grid_y2 == (grid_numbins - 1)) && (grid_y1 == 0));
            grid_z_check = ((((grid_z1 == grid_z2) || (grid_z1 == (grid_z2 + 1))) || (grid_z1 == (grid_z2 - 1))) || ((grid_z1 == (grid_numbins - 1)) && (grid_z2 == 0))) || ((grid_z2 == (grid_numbins - 1)) && (grid_z1 == 0));
            if ((grid_x_check && grid_y_check) && grid_z_check)
            {
              delx = fabs(x1 - x2);
              dely = fabs(y1 - y2);
              delz = fabs(z1 - z2);
              if (delx > (2. * grid_binwidth))
              {
                if (x1 > x2)
                {
                  delx = (x2 + grid_binmax) - x1;
                }
                else
                {
                  delx = (x1 + grid_binmax) - x2;
                }

              }

              if (dely > (2. * grid_binwidth))
              {
                if (y1 > y2)
                {
                  dely = (y2 + grid_binmax) - y1;
                }
                else
                {
                  dely = (y1 + grid_binmax) - y2;
                }

              }

              if (delz > (2. * grid_binwidth))
              {
                if (z1 > z2)
                {
                  delz = (z2 + grid_binmax) - z1;
                }
                else
                {
                  delz = (z1 + grid_binmax) - z2;
                }

              }

              D = ((delx * delx) + (dely * dely)) + (delz * delz);
              logD = log10(D);
              dist_index = (int) floor((logD - logr_min) * (10 / (logr_max - logr_min)));
              if ((dist_index >= 0) && (dist_index < 10))
              {
                if (dist_index >= 10)
                  printf("YELLING!");

                sum_local_counts[dist_index] += 1;
              }

            }

          }

        }

      }

      {
        for (i = 0; i < 10; ++i)
        {
          distance_counts[i] += sum_local_counts[i];
        }

      }
    }
    printf("\n*");
    printf("\n   *");
    printf("\n     *");
    printf("\n       *");
    printf("\n      *");
    printf("\n     *");
    printf("\n    *");
    printf("\n   *        *");
    printf("\n   *");
    printf("\n     *");
    printf("\n      *");
    printf("\n       **");
    printf("\n        * *");
    printf("\n        * * *");
    printf("\n       * * * *\n");
    printf("****************************\n");
    printf("FINISHED DM PRAGMA OMP CRITICAL\n");
    printf("****************************\n");
    printf("FINISHED DM NESTED LOOP. \n");
    printf("Dividing Counts by two to correct double counting...");
    printf("Counts: ");
    #pragma simd
    for (i = 0; i < 10; ++i)
    {
      distance_counts[i] = (long long) floor(distance_counts[i] / 2.);
      printf("%ld ", distance_counts[i]);
    }

    printf("\n");
    if (periodic_boundary_conditions)
    {
      float pbc_rand_normalization = ((0.5 * N_rand) * N_rand) / ((box_side_length * box_side_length) * box_side_length);
      float r1;
      float r2;
      printf("Random Counts Analytic:");
      for (i = 0; i < 10; ++i)
      {
        r1 = sqrt(pow(10, (((logr_max - logr_min) / 10) * i) + logr_min));
        r2 = sqrt(pow(10, (((logr_max - logr_min) / 10) * (i + 1)) + logr_min));
        randdistance_counts[i] = (long long) floor(((pbc_rand_normalization * (4. / 3.)) * 3.14159621234161928) * (pow(r2, 3) - pow(r1, 3)));
        printf("%ld ", randdistance_counts[i]);
      }

      printf("\n");
    }

    printf("Calculating DM Correlation Function...\n");
    double ratio = ((double) N_rand) / ((double) N_data);
    #pragma simd
    for (i = 0; i < 10; i++)
    {
      Xi_func[i] = ((ratio * ratio) * (((double) distance_counts[i]) / ((double) randdistance_counts[i]))) - 1.0;
      printf("%.2lf ", Xi_func[i]);
    }

    printf("\n");
    printf("Saving DM bins to file.\n");
    FILE *fp_out;
    fp_out = fopen("output_DM_allbins_Research.txt", "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i <= 10; i++)
    {
      bin_counts[i] = sqrt(pow(10, (((logr_max - logr_min) / 10) * i) + logr_min));
      fprintf(fp_out, "%lf \n", bin_counts[i]);
    }

    fclose(fp_out);
    printf("Saving DM counts to file.\n");
    fp_out = fopen("output_counts_DMdataResearchGRID.txt", "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i < 10; i++)
    {
      fprintf(fp_out, "%ld \n", distance_counts[i]);
    }

    fclose(fp_out);
    printf("Saving logr counts to file.\n");
    fp_out = fopen("output_logrResearch.txt", "w");
    if (fp_out == 0)
    {
      printf("output_logr.txt not opened, exiting...\n");
      exit(0);
    }

    fprintf(fp_out, "%lf %lf %d \n", logrNOTSQUARED_min, logrNOTSQUARED_max, 10);
    fclose(fp_out);
    printf("Saving Random counts to file.\n");
    fp_out = fopen("output_counts_DMrandomResearchGRID.txt", "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i < 10; i++)
    {
      fprintf(fp_out, "%ld \n", randdistance_counts[i]);
    }

    fclose(fp_out);
    printf("Saving Xi-DM to file.\n");
    char Xifilename[50];
    sprintf(Xifilename, "output_Xi_DMResearchGRID_%d.txt", filenum);
    fp_out = fopen(Xifilename, "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i < 10; i++)
    {
      fprintf(fp_out, "%f \n", Xi_func[i]);
    }

    fclose(fp_out);
  }

  printf("Done.\n");
  return 0;
}

