int suzuki(int matrix[10][10], int m, int n)
{
  double time_spent;
  double t1;
  double t2;
  struct timespec tp;
  struct timespec tp1;
  int tid = 0;
  int label[10][10];
  int i;
  int j;
  int val;
  int counter;
  int flag;
  int T[50] = {0};
  counter = 0;
  int nthreads = 2;
  omp_set_num_threads(nthreads);
  int condition[2][100];
  int chunk = n / nthreads;
  for (i = 0; i < 2; i++)
  {
    for (j = 0; j < m; j++)
      condition[i][j] = 0;

  }

  condition[0][0] = 1;
  clock_gettime(CLOCK_REALTIME, &tp);
  t1 = (((double) tp.tv_sec) * 1000000) + (((double) tp.tv_nsec) / 1000);
  #pragma omp parallel default(shared) private(tid,i,j) firstprivate(chunk)
  for (i = 0; i < m; i++)
  {
    #pragma omp for
    for (j = 0; j < n; j++)
    {
      tid = omp_get_thread_num();
      while (condition[tid][i] != 1)
        wait();

      if (matrix[i][j] == 0)
      {
        label[i][j] = 0;
      }
      else
      {
        val = fmask(label, matrix, m, n, i, j, T);
        if (val == 0)
        {
          {
            counter++;
            T[counter] = counter;
            label[i][j] = counter;
          }
        }
        else
        {
          label[i][j] = val;
          fassignT(T, label, m, n, i, j, val);
        }

      }

      if (((j == (((tid + 1) * chunk) - 1)) && (i != (m - 1))) && (j != (n - 1)))
      {
        condition[tid + 1][i] = 1;
        condition[tid][i + 1] = 1;
      }
      else
        if ((j == (((tid + 1) * chunk) - 1)) && (i != (m - 1)))
      {
        condition[tid][i + 1] = 1;
      }
      else
        if ((j == (((tid + 1) * chunk) - 1)) && (j != (n - 1)))
      {
        condition[tid + 1][i] = 1;
      }



    }

  }

  flag = 1;
  while (flag)
  {
    for (i = 0; i < 2; i++)
    {
      for (j = 0; j < m; j++)
        condition[i][j] = 0;

    }

    condition[0][0] = 1;
    #pragma omp parallel default(shared) private(tid,i,j) firstprivate(chunk)
    for (i = 0; i < m; i++)
    {
      #pragma omp for
      for (j = 0; j < n; j++)
      {
        tid = omp_get_thread_num();
        while (condition[tid][i] != 1)
          wait();

        if (matrix[i][j] != 0)
        {
          val = bmask(label, matrix, m, n, i, j, T);
          if ((val != 0) && (val < label[i][j]))
          {
            flag = 0;
            label[i][j] = val;
          }

          if (val != 0)
          {
            {
              bassignT(T, label, m, n, i, j, val);
            }
          }

        }

        if (((j == (((tid + 1) * chunk) - 1)) && (i != (m - 1))) && (j != (n - 1)))
        {
          condition[tid + 1][i] = 1;
          condition[tid][i + 1] = 1;
        }
        else
          if ((j == (((tid + 1) * chunk) - 1)) && (i != (m - 1)))
        {
          condition[tid][i + 1] = 1;
        }
        else
          if ((j == (((tid + 1) * chunk) - 1)) && (j != (n - 1)))
        {
          condition[tid + 1][i] = 1;
        }



      }

    }

    for (i = 0; i < 2; i++)
    {
      for (j = 0; j < m; j++)
        condition[i][j] = 0;

    }

    condition[0][0] = 1;
    #pragma omp parallel default(shared) private(tid,i,j) firstprivate(chunk)
    for (i = 0; i < m; i++)
    {
      #pragma omp for
      for (j = 0; j < n; j++)
      {
        tid = omp_get_thread_num();
        while (condition[tid][i] != 1)
          wait();

        if (matrix[i][j] != 0)
        {
          val = fmask(label, matrix, m, n, i, j, T);
          if ((val != 0) && (val < label[i][j]))
          {
            flag = 0;
            label[i][j] = val;
          }

          if (val != 0)
          {
            {
              fassignT(T, label, m, n, i, j, val);
            }
          }

        }

        if (((j == (((tid + 1) * chunk) - 1)) && (i != (m - 1))) && (j != (n - 1)))
        {
          condition[tid + 1][i] = 1;
          condition[tid][i + 1] = 1;
        }
        else
          if ((j == (((tid + 1) * chunk) - 1)) && (i != (m - 1)))
        {
          condition[tid][i + 1] = 1;
        }
        else
          if ((j == (((tid + 1) * chunk) - 1)) && (j != (n - 1)))
        {
          condition[tid + 1][i] = 1;
        }



      }

    }

    flag = 1 - flag;
  }

  printf("The Result is \n");
  for (i = 0; i < m; i++)
  {
    for (j = 0; j < n; j++)
    {
      printf("%d ", label[i][j]);
    }

    printf("\n");
  }

  clock_gettime(CLOCK_REALTIME, &tp1);
  t2 = (((double) tp1.tv_sec) * 1000000) + (((double) tp1.tv_nsec) / 1000);
  time_spent = t2 - t1;
  printf("Time Spent : %f\n", time_spent);
}

