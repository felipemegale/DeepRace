struct timeval tv1;
struct timeval tv2;
int main(int argc, char *argv[])
{
  float g_sum = 0.0;
  float g_max = -3.4028234663852886E+38;
  float g_min = 3.4028234663852886E+38;
  float numbers[640001];
  int nm_threads = 1;
  int list_size;
  int i;
  list_size = get_list_size(argc, argv, &nm_threads);
  omp_set_num_threads(nm_threads);
  fill_list(numbers, list_size);
  printf("numbers list =\n");
  print_list(numbers, list_size);
  printf("\n");
  tv1.tv_sec = (tv1.tv_usec = (tv2.tv_sec = (tv2.tv_usec = 0)));
  gettimeofday(&tv1, (struct timezone *) 0);
  int num_threads;
  int tid;
  int st_index;
  int nm_ele;
  float l_sum;
  float l_max;
  float l_min;
  #pragma omp parallel private(num_threads,tid,st_index,nm_ele,l_sum,l_max,l_min)
  {
    l_sum = 0;
    l_max = -3.4028234663852886E+38;
    l_min = 3.4028234663852886E+38;
    tid = omp_get_thread_num();
    num_threads = omp_get_num_threads();
    nm_ele = (list_size / num_threads) + (tid < (list_size % num_threads));
    st_index = (tid < (list_size % num_threads)) ? (tid + ((list_size / num_threads) * tid)) : ((list_size % num_threads) + ((list_size / num_threads) * tid));
    for (i = st_index; i < (st_index + nm_ele); i++)
    {
      l_sum += numbers[i];
      if (l_max < numbers[i])
        l_max = numbers[i];

      if (l_min > numbers[i])
        l_min = numbers[i];

    }

    if (tid == 0)
    {
      printf("Number of threads = %d\n", num_threads);
    }

    {
      g_sum += l_sum;
      if (g_max < l_max)
        g_max = l_max;

      if (g_min > l_min)
        g_min = l_min;

    }
  }
  gettimeofday(&tv2, (struct timezone *) 0);
  printf("Sum of numbers is %e\n", g_sum);
  printf("Maximum number in list is %e\n", g_max);
  printf("Minimum number in list is %e\n", g_min);
  printf("time=%e seconds\n\n", ((double) ((tv2.tv_usec - tv1.tv_usec) + ((tv2.tv_sec - tv1.tv_sec) * 1000000))) / 1000000.0);
}

