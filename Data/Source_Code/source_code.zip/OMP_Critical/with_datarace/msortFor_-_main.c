{
  int d2;
  int i;
  int j;
  int k;
} Point;
int compar(Point ptA, Point ptB);
void merge(int r1, int r2, int *N, Point **ls);
int main(int argc, char **argv)
{
  int M = atoi(argv[1]);
  int p = atoi(argv[2]);
  double begin = omp_get_wtime();
  int Ntot = (((M + 1) * (M + 2)) * (M + 3)) / 6;
  Point *ls[p];
  int N[p];
  int r;
  #pragma omp parallel for private(r)
  for (r = 0; r < p; r++)
  {
    N[r] = Ntot / p;
    if (r < (Ntot % p))
      N[r]++;

    Point *lsr = ls[r] = (Point *) malloc(N[r] * (sizeof(Point)));
    int n = 0;
    for (int k = 0; k <= M; k++)
      for (int j = 0; j <= k; j++)
      for (int i = 0; i <= j; i++)
    {
      if ((n % p) == r)
      {
        Point lsrnbyp = {((i * i) + (j * j)) + (k * k), i, j, k};
        lsr[n / p] = lsrnbyp;
      }

      n++;
    }



    for (int n = 0; n < N[r]; n++)
      for (int m = n; (m > 0) && (compar(lsr[m], lsr[m - 1]) < 0); m--)
    {
      Point lsrm = lsr[m];
      lsr[m] = lsr[m - 1];
      lsr[m - 1] = lsrm;
    }


  }

  int p0 = p;
  int p1 = 1;
  while ((2 * p1) < p0)
    p1 *= 2;

  while (p0 > 1)
  {
    #pragma omp parallel for private(r)
    for (r = 0; r < (p0 - p1); r++)
      merge(r, p1 + r, N, ls);

    p0 = p1;
    p1 /= 2;
  }

  double end = omp_get_wtime();
  int n = 0;
  #pragma omp parallel
  {
    n++;
  }
  printf("nthreads = %2d, nparts = %2d, time = %.3lf\n", n, p, end - begin);
  FILE *sorted = fopen("sorted.txt", "w");
  for (int n = 0; n < Ntot; n++)
  {
    Point pt = ls[0][n];
    fprintf(sorted, "%d %d %d %d\n", pt.d2, pt.i, pt.j, pt.k);
  }

  fclose(sorted);
}

