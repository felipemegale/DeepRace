static char rcsid[] = "$Id$";
int errors = 0;
int thds;
double prvt;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt = 100;
  #pragma omp parallel firstprivate (prvt)
  {
    int id = omp_get_thread_num();
    if (prvt != 100)
    {
      errors += 1;
    }

    prvt = id;
    #pragma omp barrier
    if (prvt != id)
    {
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(double)))
    {
      errors += 1;
    }

  }
  prvt = 100 * 2;
  #pragma omp parallel firstprivate (prvt)
  func1(100 * 2, &prvt);
  prvt = 100 * 3;
  #pragma omp parallel firstprivate (prvt)
  func2(100 * 3);
  if (errors == 0)
  {
    printf("firstprivate 012 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 012 : FAILED\n");
    return 1;
  }

}

