int i;
int j;
double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
struct Data
{
  int start;
  int end;
  int size;
};
struct Node
{
  struct Data *data;
  struct Node *next;
};
struct Q
{
  struct Node *front;
  struct Node *rear;
};
struct Data *nxt_chunk(struct Q *list[])
{
  struct Data *tempdat;
  struct Data *finaldat;
  int large = 0;
  int pos = -1;
  for (i = 0; i < 24; i++)
  {
    tempdat = peek(list[i]);
    if (tempdat != 0)
    {
      if (tempdat->size > large)
      {
        large = tempdat->size;
        pos = i;
      }

    }

  }

  if (pos != (-1))
  {
    {
      finaldat = deq(list[pos]);
    }
    return finaldat;
  }
  else
  {
    return 0;
  }


  int x;
  int y;
};
struct Body
{
  int m;
  struct Vector force;
  struct Vector position;
  struct Vector velocity;
};
int numBodies = 2;
int numTimeSteps = 5;
int approxLim = 1337;
int numWorkers = 13;
int taskNum;
struct Body *bodyArray;
int main(int argc, char *argv[])
{
  while (argc)
  {
    if (!strncasecmp(argv[0], (char * const ) "-b", 2))
      numBodies = atoi(argv[0] + 2);
    else
      if (!strncasecmp(argv[0], (char * const ) "-t", 2))
      numTimeSteps = atoi(argv[0] + 2);
    else
      if (!strncasecmp(argv[0], (char * const ) "-a", 2))
      approxLim = atoi(argv[0] + 2);
    else
      if (!strncasecmp(argv[0], (char * const ) "-w", 2))
      numWorkers = atoi(argv[0] + 2);




    argc--;
    argv++;
  }

  bodyArray = malloc(numBodies * (sizeof(struct Body)));
  printf("Bodies: %d\nTime steps: %d\nApprox lim: %d\nWorkers: %d\n", numBodies, numTimeSteps, approxLim, numWorkers);
  init();
  int i;
  int task;
  #pragma omp parallel num_threads(numWorkers) private(i, task) shared(taskNum) firstprivate(numTimeSteps, numBodies)
  {
    for (i = 0; i < numTimeSteps; i++, task = 0)
    {
      while (1)
      {
        #pragma omp critical (calcTask)
        {
          task = taskNum++;
        }
        if (task >= numBodies)
          break;

        calculateForces(task);
      }

      #pragma omp barrier
      task = 0;
      #pragma omp single
      {
        taskNum = 0;
      }
      while (1)
      {
        #pragma omp critical (calcTask)
        {
          task = taskNum++;
        }
        if (task >= numBodies)
          break;

        moveBodies(task);
      }

      #pragma omp barrier
      #pragma omp single
      {
        taskNum = 0;
      }
      #pragma omp barrier
    }

  }
  return 0;
}

