{
  unsigned key;
  unsigned value;
} keyvalue;
{
  unsigned n_max;
  unsigned n;
  unsigned *pt;
  keyvalue *kv;
} bheap;
{
  unsigned s;
  unsigned t;
} edge;
{
  unsigned n;
  unsigned e;
  unsigned n2;
  unsigned e2;
  edge *edges;
  unsigned *d0;
  unsigned *cd0;
  unsigned *adj0;
  unsigned *rank;
  unsigned *map;
  unsigned core;
  unsigned *d;
  unsigned *cd;
  unsigned *adj;
} sparse;
unsigned *ck_p;
unsigned *merge_p;
unsigned *size_p;
unsigned long long *nck_p;
unsigned long long *nck_1;
unsigned long long *nck_2;
#pragma omp threadprivate(ck_p,merge_p,size_p,nck_p);
{
  unsigned key;
  unsigned long long value;
} keyvalueLLU;
{
  unsigned n_max;
  unsigned n;
  unsigned *pt;
  keyvalueLLU *kv;
} bheapLLU;
{
  unsigned n;
  keyvalueLLU *ic;
  unsigned long long ckcore;
  unsigned size;
  double rho;
  double ckrho;
} densest;
void oneshortpass(sparse *g, bheapLLU *heap, unsigned kmax, unsigned u)
{
  unsigned i;
  unsigned j;
  unsigned v;
  unsigned s = 0;
  static unsigned *adj = 0;
  if (adj == 0)
  {
    adj = malloc(g->n2 * (sizeof(unsigned)));
  }

  for (i = g->cd0[u]; i < g->cd0[u + 1]; i++)
  {
    v = g->adj0[i];
    if (heap->pt[v] != (-1))
    {
      adj[s++] = v;
    }

  }

  if (s > (kmax - 2))
  {
    #pragma omp parallel private(i)
    {
      ck_p[0] = u;
      #pragma omp for schedule(dynamic, 1) nowait
      for (i = 0; i < s; i++)
      {
        ck_p[1] = adj[i];
        size_p[0] = merging(adj, s, &g->adj[g->cd[ck_p[1]]], g->d[ck_p[1]], merge_p);
        recursion(kmax, 3, g, ck_p, merge_p, size_p, nck_p);
      }

      {
        for (i = 0; i < s; i++)
        {
          j = adj[i];
          nck_2[j] += nck_p[j];
          nck_p[j] = 0;
        }

      }
    }
  }

}

