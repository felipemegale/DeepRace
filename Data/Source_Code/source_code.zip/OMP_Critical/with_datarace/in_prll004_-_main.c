static char rcsid[] = "$Id$";
int main()
{
  int thds;
  int i;
  int errors = 0;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi thread.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel sections
  {
    #pragma omp section
    {
      if (omp_in_parallel() == 0)
      {
        errors += 1;
      }

    }
    #pragma omp section
    {
      if (omp_in_parallel() == 0)
      {
        errors += 1;
      }

    }
  }
  for (i = 1; i <= thds; i++)
  {
    omp_set_num_threads(i);
    #pragma omp parallel sections
    {
      #pragma omp section
      {
        if (omp_in_parallel() == 0)
        {
          errors += 1;
        }

      }
      #pragma omp section
      {
        if (omp_in_parallel() == 0)
        {
          errors += 1;
        }

      }
    }
  }

  if (errors == 0)
  {
    printf("omp_in_parallel 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("omp_in_parallel 004 : FAILED\n");
    return 1;
  }

}

