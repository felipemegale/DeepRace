int main(int argc, char *argv[])
{
  int num_tasks;
  int max_task_time;
  double start_time;
  double end_time;
  int task_time;
  int total_task_time = 0;
  int max_thread_total_task_time;
  int min_thread_total_task_time;
  bool verbose = 0;
  int nthreads;
  char *usage_msg = "usage is %s num_tasks max_task_time [--verbose]\n";
  num_tasks = get_integer_arg(argc, argv, 1, 1, "num_tasks", usage_msg);
  max_task_time = get_integer_arg(argc, argv, 2, 1, "max_task_time", usage_msg);
  int required_parms = 3;
  if (argc > required_parms)
  {
    if (strcmp(argv[required_parms], "--verbose") == 0)
      verbose = 1;
    else
    {
      fprintf(stderr, usage_msg, argv[0]);
      return 1;
    }

  }

  max_thread_total_task_time = 0;
  min_thread_total_task_time = max_task_time * num_tasks;
  start_time = get_time();
  #pragma omp parallel private(task_time)
  {
    int thread_total_task_time = 0;
    int thread_num_tasks = 0;
    int thread_ID = omp_get_thread_num();
    #pragma omp single
    {
      nthreads = omp_get_num_threads();
    }
    #pragma omp for schedule(static)
    for (int i = 0; i < num_tasks; ++i)
    {
      {
        task_time = random_in_range(1, max_task_time);
      }
      thread_total_task_time += task_time;
      ++thread_num_tasks;
      if (verbose)
        printf("(thread %d) task time = %d\n", thread_ID, task_time);

      millisleep(task_time);
    }

    printf("thread %d number of tasks = %d, total time = %d\n", thread_ID, thread_num_tasks, thread_total_task_time);
    {
      if (thread_total_task_time > max_thread_total_task_time)
        max_thread_total_task_time = thread_total_task_time;

      if (thread_total_task_time < min_thread_total_task_time)
        min_thread_total_task_time = thread_total_task_time;

      total_task_time += thread_total_task_time;
    }
  }
  end_time = get_time();
  printf("\nOpenMP parallel version with %d threads, static scheduling\n", nthreads);
  printf("number of tasks = %d\n", num_tasks);
  printf("max task time = %d\n", max_task_time);
  printf("total task time = %d\n", total_task_time);
  printf("total task time in threads ranges from %d to %d\n", min_thread_total_task_time, max_thread_total_task_time);
  printf("running time = %g\n", end_time - start_time);
  return 0;
}

