double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
void init1(void);
void init2(void);
void runloop(int);
void loop1chunk(int, int);
void loop2chunk(int, int);
void valid1(void);
void valid2(void);
void runloop(int loopid)
{
  int global_work_remaining[omp_get_max_threads()];
  #pragma omp parallel default(none) shared(global_work_remaining, loopid, a, b, c)
  {
    int i;
    int my_id = omp_get_thread_num();
    int nthreads = omp_get_num_threads();
    int ipt = (int) ceil(((double) 729) / ((double) nthreads));
    int chunk_id = my_id;
    int chunk_lo = chunk_id * ipt;
    int chunk_hi = (chunk_id + 1) * ipt;
    if (chunk_hi > 729)
      chunk_hi = 729;

    int chunk_range = chunk_hi - chunk_lo;
    int local_lo;
    int local_hi;
    int local_work;
    global_work_remaining[my_id] = chunk_range;
    #pragma omp barrier
    int finished = 0;
    while (1)
    {
      {
        if (global_work_remaining[chunk_id] == 0)
        {
          int old_id = chunk_id;
          for (i = 0; i < nthreads; i++)
          {
            if (global_work_remaining[chunk_id] < global_work_remaining[i])
            {
              chunk_id = i;
            }

          }

          if (old_id == chunk_id)
          {
            finished = 1;
            chunk_range = 0;
          }
          else
          {
            chunk_hi = (chunk_id + 1) * ipt;
            if (chunk_hi > 729)
              chunk_hi = 729;

            chunk_range = global_work_remaining[chunk_id];
          }

        }
        else
        {
          chunk_range = global_work_remaining[chunk_id];
        }

        local_work = floor(((double) chunk_range) / ((double) nthreads));
        if ((local_work < 1) && (finished == 0))
          local_work = 1;

        global_work_remaining[chunk_id] -= local_work;
      }
      if (finished == 1)
        break;

      local_lo = chunk_hi - chunk_range;
      local_hi = local_lo + local_work;
      switch (loopid)
      {
        case 1:
          loop1chunk(local_lo, local_hi);
          break;

        case 2:
          loop2chunk(local_lo, local_hi);
          break;

      }

    }

  }
}

