static char rcsid[] = "$Id$";
int errors = 0;
int thds;
short prvt;
int main()
{
  int i;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    #pragma omp for schedule(static,1) lastprivate (prvt)
    for (i = 0; i < thds; i++)
    {
      prvt = i;
      barrier(thds);
      if (prvt != i)
      {
        errors += 1;
      }

      if ((sizeof(prvt)) != (sizeof(short)))
      {
        errors += 1;
      }

      if (i == 0)
      {
        waittime(1);
      }

      prvt = i;
    }

    if (prvt != (thds - 1))
    {
      errors += 1;
    }

  }
  #pragma omp parallel
  func(thds);
  func(1);
  if (errors == 0)
  {
    printf("lastprivate 007 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("lastprivate 007 : FAILED\n");
    return 1;
  }


  int d;
  int omp_rank = omp_get_thread_num();
  long x;
  long vol = (iter->size * iter->size) * iter->size;
  #pragma omp critical(model)
  {
    for (x = 0; x < vol; ++x)
    {
      iter->model2[x] += priv_model[x];
      iter->inter_weight[x] += priv_weight[x];
    }

  }
  #pragma omp critical(like_info)
  {
    for (d = 0; d < frames->tot_num_data; ++d)
    {
      likelihood[d] += priv_data[d];
      info[d] += priv_data[frames->tot_num_data + d];
    }

  }
  if (param.need_scaling)
  {
    if (omp_rank == 0)
      memset(iter->scale, 0, frames->tot_num_data * (sizeof(double)));

    #pragma omp barrier
    #pragma omp critical(scale)
    {
      for (d = 0; d < frames->tot_num_data; ++d)
        if (!frames->blacklist[d])
        iter->scale[d] += priv_data[(2 * frames->tot_num_data) + d];


    }
  }

  free(priv_model);
  free(priv_weight);
  free(priv_data);
}

