void multiplex(int, int, int);
void multiplex(int tid, int local, int sum)
{
  #pragma omp parallel shared(sum) private(local)
  {
    tid = omp_get_thread_num();
    {
      local = tid + 1;
      sum += local;
    }
    #pragma omp barrier
    #pragma omp master
    {
      sum = sum;
    }
  }
}

