int **p;
int num_tds = 0;
int num_rounds = 0;
unsigned long t_sec;
unsigned long t_usec;
struct timeval t_barr1;
struct timeval t_barr2;
struct timeval t_total1;
struct timeval t_total2;
struct timeval t_start[8];
struct timeval t_end[8];
int main(int argc, char **argv)
{
  gettimeofday(&t_total1, 0);
  int thread_num = -1;
  int priv = 0;
  int pub = 0;
  int i = 0;
  num_tds = atoi(argv[1]);
  num_rounds = (int) ceil(findlog2(num_tds));
  p = (int **) malloc(num_tds * (sizeof(int *)));
  for (i = 0; i < num_tds; i++)
  {
    p[i] = malloc(num_rounds * (sizeof(int)));
  }

  int sense;
  gettimeofday(&t_barr1, 0);
  #pragma omp parallel num_threads(num_tds) firstprivate(thread_num, priv) private(sense) shared(pub)
  {
    thread_num = omp_get_thread_num();
    printf("thread %d: Hello World \n", thread_num);
    sense = 1;
    {
      priv += thread_num;
      pub += thread_num;
    }
    printf("thread %d: before barrier pub is = %d\n", thread_num, pub);
    barrier(&sense);
    printf("thread %d: After barrier pub is = %d\n", thread_num, pub);
    barrier(&sense);
    printf("thread %d: After barrier priv is = %d\n", thread_num, priv);
  }
  gettimeofday(&t_barr2, 0);
  print_time(&t_barr1, &t_barr2, 999);
  gettimeofday(&t_total2, 0);
  print_time(&t_total1, &t_total2, 9999);
  int m = 0;
  for (m = 0; m < num_tds; m++)
  {
    print_time(&t_start[m], &t_end[m], m);
  }

  return 0;
}

