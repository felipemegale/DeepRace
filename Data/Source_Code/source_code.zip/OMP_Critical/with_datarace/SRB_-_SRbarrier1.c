void SRbarrier1(int *count, int *sense, int *local_sense)
{
  *local_sense = !(*local_sense);
  {
    *count = (*count) - 1;
    if ((*count) == 0)
    {
      *count = omp_get_num_threads();
      *sense = *local_sense;
    }

  }
  while ((*sense) != (*local_sense))
  {
  }

  ;
}

