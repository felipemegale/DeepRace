int main(int argc, char *argv[])
{
  int a[6][8];
  srand(time(0));
  for (int i = 0; i < 6; i++)
  {
    for (int j = 0; j < 8; j++)
    {
      a[i][j] = rand() % (6 * 8);
      printf("%d ", a[i][j]);
    }

    printf("\n");
  }

  int min = 6 * 8;
  int max = 0;
  #pragma omp parallel for collapse(2)
  for (int i = 0; i < 6; i++)
  {
    for (int j = 0; j < 8; j++)
    {
      #pragma omp critical
      if (a[i][j] > max)
      {
        max = a[i][j];
      }

      #pragma omp critical
      if (a[i][j] < min)
      {
        min = a[i][j];
      }

    }

  }

  printf("min=%d, max=%d\n", min, max);
  return 0;

  double x = 0;
  int thread_num;
  int nthreads = 16;
  printf("Testing OpenMP, you should see each thread print...\n");
  #pragma omp parallel for private(x)
  for (int i = 0; i < 100; ++i)
  {
    x = expensive(i);
    {
    }
  }

}

