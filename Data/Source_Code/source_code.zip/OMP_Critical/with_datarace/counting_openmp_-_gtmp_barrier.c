static int number_of_threads;
static int count;
static char global_sense;
void gtmp_barrier()
{
  char local_sense;
  local_sense = !global_sense;
  {
    count = count - 1;
    if (count == 0)
    {
      count = number_of_threads;
      global_sense = local_sense;
    }

  }
  while (global_sense != local_sense)
    ;


  int id = omp_get_thread_num();
  *prvt = id;
  #pragma omp barrier
  if ((*prvt) != id)
  {
    #pragma omp critical
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(int)))
  {
    #pragma omp critical
    errors += 1;
  }

}

