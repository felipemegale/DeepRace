int main()
{
  int number;
  int i;
  omp_set_num_threads(4);
  omp_set_nested(1);
  int a = 10;
  #pragma omp parallel
  {
    a = 12;
    #pragma omp parallel
    {
      a++;
      #pragma omp for firstprivate(a)
      for (i = 0; i < 20; i++)
      {
        int b = a;
      }

    }
  }
  return 0;
}

