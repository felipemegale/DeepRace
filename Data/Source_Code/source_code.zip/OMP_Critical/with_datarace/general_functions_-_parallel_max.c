void parallel_max(float *max_out, float *X, int N, int col)
{
  int j;
  *max_out = -FLT_MAX;
  int index;
  #pragma omp parallel shared(X,max_out,N) private(j)
  {
    float max = -FLT_MAX;
    #pragma omp for schedule(guided) nowait
    for (j = 0; j < N; j++)
    {
      index = (j * DIM) + col;
      if (max < X[index])
      {
        max = X[index];
      }

    }

    {
      if (max > (*max_out))
        *max_out = max;

    }
  }
}

