{
  double real;
  double imag;
} dcomplex;
extern double randlc(double *, double);
extern void vranlc(int, double *, double, double *);
extern void timer_clear(int);
extern void timer_start(int);
extern void timer_stop(int);
extern double timer_read(int);
extern void c_print_results(char *name, char cclass, int n1, int n2, int n3, int niter, int nthreads, double t, double mops, char *optype, int passed_verification, char *npbversion, char *compiletime, char *cc, char *clink, char *c_lib, char *c_inc, char *cflags, char *clinkflags, char *rand);
int fftblock;
int fftblockpad;
static int dims[3][3];
static int xstart[3];
static int ystart[3];
static int zstart[3];
static int xend[3];
static int yend[3];
static int zend[3];
static double ex[(20 * ((((512 * 512) / 4) + ((256 * 256) / 4)) + ((256 * 256) / 4))) + 1];
static dcomplex u[512];
static dcomplex sums[20 + 1];
static int niter;
static void evolve(dcomplex u0[256][256][512], dcomplex u1[256][256][512], int t, int indexmap[256][256][512], int d[3]);
static void compute_initial_conditions(dcomplex u0[256][256][512], int d[3]);
static void ipow46(double a, int exponent, double *result);
static void setup(void);
static void compute_indexmap(int indexmap[256][256][512], int d[3]);
static void print_timers(void);
static void fft(int dir, dcomplex x1[256][256][512], dcomplex x2[256][256][512]);
static void cffts1(int is, int d[3], dcomplex x[256][256][512], dcomplex xout[256][256][512], dcomplex y0[512][18], dcomplex y1[512][18]);
static void cffts2(int is, int d[3], dcomplex x[256][256][512], dcomplex xout[256][256][512], dcomplex y0[512][18], dcomplex y1[512][18]);
static void cffts3(int is, int d[3], dcomplex x[256][256][512], dcomplex xout[256][256][512], dcomplex y0[512][18], dcomplex y1[512][18]);
static void fft_init(int n);
static void cfftz(int is, int m, int n, dcomplex x[512][18], dcomplex y[512][18]);
static void fftz2(int is, int l, int m, int n, int ny, int ny1, dcomplex u[512], dcomplex x[512][18], dcomplex y[512][18]);
static int ilog2(int n);
static void checksum(int i, dcomplex u1[256][256][512], int d[3]);
static void verify(int d1, int d2, int d3, int nt, boolean *verified, char *cclass);
static void checksum(int i, dcomplex u1[256][256][512], int d[3])
{
  int j;
  int q;
  int r;
  int s;
  int ierr;
  dcomplex chk;
  dcomplex allchk;
  chk.real = 0.0;
  chk.imag = 0.0;
  #pragma omp for nowait
  for (j = 1; j <= 1024; j++)
  {
    q = (j % 512) + 1;
    if ((q >= xstart[0]) && (q <= xend[0]))
    {
      r = ((3 * j) % 256) + 1;
      if ((r >= ystart[0]) && (r <= yend[0]))
      {
        s = ((5 * j) % 256) + 1;
        if ((s >= zstart[0]) && (s <= zend[0]))
        {
          chk.real = chk.real + u1[s - zstart[0]][r - ystart[0]][q - xstart[0]].real, chk.imag = chk.imag + u1[s - zstart[0]][r - ystart[0]][q - xstart[0]].imag;
        }

      }

    }

  }

  {
    sums[i].real += chk.real;
    sums[i].imag += chk.imag;
  }
  #pragma omp barrier
  #pragma omp single
  {
    sums[i].real = sums[i].real / ((double) 33554432);
    sums[i].imag = sums[i].imag / ((double) 33554432);
    printf("T = %5d     Checksum = %22.12e %22.12e\n", i, sums[i].real, sums[i].imag);
  }
}

