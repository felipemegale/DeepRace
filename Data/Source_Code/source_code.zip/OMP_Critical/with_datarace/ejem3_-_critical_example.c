extern float average(float, float, float);
int dequeue(float *a);
void work(int i, float *a);
void critical_example(float *x, float *y)
{
  unsigned i;
  unsigned j;
  char unused;
  if (ell == size)
  {
    #pragma omp critical
    {
      fprintf(stdout, "solution from thread #%d = ", omp_get_thread_num());
      for (i = 0; i < size; i++)
        fprintf(stdout, "%3d ", tuple[i]);

      fprintf(stdout, "\n");
    }
  }
  else
  {
    #pragma omp parallel for if(ell == t_depth) default(none) shared(alphabet,tuple,size,ell,t_depth) private(j,unused)
    for (i = 0; i < alphabet; i++)
    {
      unsigned *tuple_to_send;
      if (ell == t_depth)
      {
        unsigned *local_tuple;
        local_tuple = (unsigned *) calloc(size, sizeof(unsigned));
        for (j = 0; j < ell; j++)
          local_tuple[j] = tuple[j];

        tuple_to_send = local_tuple;
      }
      else
      {
        tuple_to_send = tuple;
      }

      tuple_to_send[ell] = i;
      backtrack(size, alphabet, tuple_to_send, ell + 1, t_depth);
    }

  }


  int ix_next;
  int iy_next;
  #pragma omp parallel shared(x,y) private(ix_next, iy_next)
  {
    ix_next = dequeue(x);
    work(ix_next, x);
    iy_next = dequeue(y);
    work(iy_next, y);
  }
}

