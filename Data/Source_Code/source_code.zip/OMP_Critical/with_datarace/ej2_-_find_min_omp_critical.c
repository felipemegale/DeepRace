int find_min_omp_critical(int *arr, int size)
{
  int i;
  int min = arr[0];
  #pragma omp parallel for
  for (i = 1; i < size; i++)

  if (arr[i] < min)
    min = arr[i];

  return min;
}

