double trapezoid(approxFunction theFunc, int N, double a, double b);
double myFunc(double x);
double coarseTrap(approxFunction theFunc, int N, double a, double b)
{
  int tid;
  double *p = 0;
  tid = omp_get_thread_num();
  printf("tid %d\n", tid);
  #pragma omp barrier
  if (tid == 0)
  {
    p = x;
  }

  #pragma omp barrier
  if (tid == 1)
  {
    p = y;
  }

  #pragma omp barrier
  #pragma omp critical
  {
    printf("func2 %d %f\n", tid, p[0]);
  }

  int NUM_THREADS = 10;
  omp_set_num_threads(NUM_THREADS);
  double final = 0.0;
  int jobSize = N / NUM_THREADS;
  double interval = (((double) b) - ((double) a)) / ((double) N);
  printf("split sample size = %d\n", jobSize);
  printf("interval  = %0.12f\n", interval);
  #pragma omp parallel
  {
    int id;
    double x = 0.0;
    id = omp_get_thread_num();
    double newA = a + ((((double) id) * ((double) jobSize)) * ((double) interval));
    double newB = newA + (jobSize * interval);
    printf("Thread id (%d);newA = %f; newB = %f\n", id, newA, newB);
    x += trapezoid(theFunc, jobSize, newA, newB);
    final += x;
  }
  return final;
}

