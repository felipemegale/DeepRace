int max_level = 50;
FILE *inputFile;
struct cell
{
  int n;
  coor *alt;
  int top;
  int bot;
  int lhs;
  int rhs;
  int left;
  int above;
  int next;
};
struct cell *gcells;
int MIN_AREA;
ibrd BEST_BOARD;
coor MIN_FOOTPRINT;
int N;
void add_cell(int id, coor FOOTPRINT, ibrd BOARD, struct cell *CELLS, int level)
{
  int i;
  int j;
  int nn;
  int area;
  ibrd board;
  coor footprint;
  coor NWS[64];
  for (i = 0; i < CELLS[id].n; i++)
  {
    nn = starts(id, i, NWS, CELLS);
    for (j = 0; j < nn; j++)
    {
      #pragma omp task default(none) untied private(board, footprint,area) firstprivate(NWS,i,j,id,nn) shared(FOOTPRINT,BOARD,CELLS,MIN_AREA,MIN_FOOTPRINT,N,BEST_BOARD)
      {
        struct cell cells[N + 1];
        memcpy(cells, CELLS, (sizeof(struct cell)) * (N + 1));
        cells[id].top = NWS[j][0];
        cells[id].bot = (cells[id].top + cells[id].alt[i][0]) - 1;
        cells[id].lhs = NWS[j][1];
        cells[id].rhs = (cells[id].lhs + cells[id].alt[i][1]) - 1;
        memcpy(board, BOARD, sizeof(ibrd));
        if (!lay_down(id, board, cells))
        {
          if (0)
            printf("Chip %d, shape %d does not fit\n", id, i);

          goto _end;
        }

        footprint[0] = (FOOTPRINT[0] > cells[id].bot) ? (FOOTPRINT[0]) : (cells[id].bot);
        footprint[1] = (FOOTPRINT[1] > cells[id].rhs) ? (FOOTPRINT[1]) : (cells[id].rhs);
        area = footprint[0] * footprint[1];
        if (cells[id].next == 0)
        {
          if (area < MIN_AREA)
          {
            if (area < MIN_AREA)
            {
              MIN_AREA = area;
              MIN_FOOTPRINT[0] = footprint[0];
              MIN_FOOTPRINT[1] = footprint[1];
              memcpy(BEST_BOARD, board, sizeof(ibrd));
              if (0)
                printf("N  %d\n", MIN_AREA);

            }

          }

        }
        else
          if (area < MIN_AREA)
        {
          if ((level + 1) < max_level)
            add_cell(cells[id].next, footprint, board, cells, level + 1);
          else
            add_cell_ser(cells[id].next, footprint, board, cells);

        }
        else
        {
          if (0)
            printf("T  %d, %d\n", area, MIN_AREA);

        }


        _end:
        ;

      }
    }

  }

  #pragma omp taskwait
}

