int main()
{
  #pragma omp parallel
  {
    {
      printf("Bonjour ! %d\n", omp_get_thread_num());
      printf("Au revoir !%d\n", omp_get_thread_num());
    }
  }
  return 0;

  float sum = 0.0;
  #pragma omp parallel for shared(sum)
  for (int i = 0; i < n; i++)
  {
    #pragma omp critical
    sum += a[i] * b[i];
  }

  return sum;
}

