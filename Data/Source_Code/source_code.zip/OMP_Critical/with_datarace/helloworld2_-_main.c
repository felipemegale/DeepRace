int main()
{
  printf("That is the start for our %d threads\n", omp_get_num_threads());
  #pragma omp parallel
  {
    {
      printf("hello from thread %d out of %d\n", omp_get_thread_num(), omp_get_num_threads());
    }
  }
  printf("\nThat was the end of our %d threads\n", omp_get_num_threads());

  char c;
  int count;
} char_count_t;
{
  char *prev_string;
  char *new_string;
} replace_table_t;
{
  char *string;
  int count;
} string_count_t;
int char_search(char c);
int word_replace(char *old_string, replace_table_t *table);
void replace_table_insert(replace_table_t **table, char *prev_string, char *new_string);
int contain_subtring(char *old_string, char *sub_string, int sub_string_initial);
int word_search(char *string);
char_count_t *character;
string_count_t *words;
char **replace_character;
char **string_array;
int length = 0;
int string_count_length = 0;
int replace_length = 0;
int table_size = 0;
int total_words = 0;
int word_search(char *string)
{
  int exit = 1;
  if ((((strcmp(string, "\n") == 0) || (strcmp(string, "\r") == 0)) || (strcmp(string, " ") == 0)) || (strcmp(string, "\t") == 0))
  {
    return 1;
  }

  #pragma omp critical (word_count)
  {
    for (int i = 0; i < string_count_length; i++)
    {
      if (strcmp(words[i].string, string) == 0)
      {
        words[i].count++;
        exit = 0;
      }

    }

    if (exit == 1)
    {
      words = realloc(words, (string_count_length + 1) * (sizeof(string_count_t)));
      words[string_count_length].string = malloc((sizeof(char)) * strlen(string));
      strcpy(words[string_count_length].string, string);
      words[string_count_length].count = 1;
      string_count_length++;
    }

  }
  return 1;
}

