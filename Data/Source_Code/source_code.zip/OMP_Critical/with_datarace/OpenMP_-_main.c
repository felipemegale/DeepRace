float *input;
float *bucket;
int main(int argc, char *args[])
{
  if (argc != 5)
  {
    printf("Enter No_of_Processors : P\n -t Problem Size : N\nWrite to output file : y/n");
    printf("\nExample ./OpenMP P -t N y\n");
    return 0;
  }

  int no_of_cores = atoi(args[1]);
  int n = atoi(args[3]);
  int i;
  int max_num = 100;
  double start;
  double end;
  input = malloc((sizeof(float)) * n);
  random_number_generator_normal(input, n, max_num);
  bucket = malloc((no_of_cores * n) * (sizeof(float)));
  {
  }
  {
  }
  int count[no_of_cores];
  int limit = max_num / no_of_cores;
  for (int l = 0; l < no_of_cores; l++)
  {
    for (int k = 0; k < n; k++)
    {
      *((((float *) bucket) + (l * n)) + k) = 0.0;
    }

    count[l] = 0;
  }

  FILE *fp;
  if ((*args[4]) == 'y')
  {
    fp = fopen("output.txt", "w");
    fprintf(fp, "%s \n", "BEFORE ");
    for (int h = 0; h < n; h++)
    {
      fprintf(fp, "%f \n", input[h]);
    }

    fprintf(fp, "\n");
  }
  else
  {
    printf("Before \n");
  }

  struct timeval time;
  gettimeofday(&time, 0);
  double t1 = time.tv_sec + (time.tv_usec / 1000000.0);
  int bucket_no = 0;
  omp_set_num_threads(no_of_cores);
  #pragma omp parallel for private(i) shared(n,count)
  for (int i = 0; i < n; i++)
  {
    bucket_no = floor(input[i] / limit);
    int tem;
    {
      tem = count[bucket_no];
      count[bucket_no] += 1;
    }
    *((((float *) bucket) + (bucket_no * n)) + tem) = input[i];
  }

  printf("Bucket \n");
  printf(" count \n");
  for (int g = 0; g < no_of_cores; g++)
  {
  }

  printf("\n");
  int k;
  #pragma omp parallel for private(i) shared(no_of_cores)
  for (int i = 0; i < no_of_cores; i++)
  {
    int k = 0;
    for (int j = 0; j < count[i]; j++)
    {
      k = j;
      while ((k > 0) && ((*((((float *) bucket) + (i * n)) + k)) < (*(((((float *) bucket) + (i * n)) + k) - 1))))
      {
        float temp = *((((float *) bucket) + (i * n)) + k);
        *((((float *) bucket) + (i * n)) + k) = *(((((float *) bucket) + (i * n)) + k) - 1);
        *(((((float *) bucket) + (i * n)) + k) - 1) = temp;
        k--;
      }

    }

  }

  printf("After bucket\n");
  k = 0;
  int no_to_add = 0;
  #pragma omp parallel for shared(no_of_cores) private(i,no_to_add)
  for (int i = 0; i < no_of_cores; i++)
  {
    no_to_add = 0;
    int d = i;
    while (d > 0)
    {
      no_to_add += count[d - 1];
      d--;
    }

    for (int j = 0; j < count[i]; j++)
    {
      input[j + no_to_add] = *((((float *) bucket) + (i * n)) + j);
      k++;
    }

  }

  gettimeofday(&time, 0);
  double t2 = time.tv_sec + (time.tv_usec / 1000000.0);
  if ((*args[4]) == 'y')
  {
    fprintf(fp, "%s \n", "AFTER ");
    for (int h = 0; h < n; h++)
    {
      fprintf(fp, "%f \n", input[h]);
    }

    fprintf(fp, "\n");
    fclose(fp);
  }
  else
  {
    printf("After \n");
  }

  printf("Time Taken %f \n", t2 - t1);
}

