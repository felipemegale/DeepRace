char line[4096];
double x[250000][531];
double test[250000];
double y[250000];
double w[250000];
double srt[250000];
double predt[250000];
int use[531];
int id[250000];
int idt[550000];
int has_na[] = {0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0};
int na_ind[] = {0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0};
int main()
{
  char *p;
  int ci2;
  int ci;
  int ri;
  int tc;
  int bestc;
  int mc;
  double besta;
  double sd[531];
  double avg[531];
  double med;
  FILE *fp;
  for (ri = 0; ri < 250000; ri++)
  {
    test[ri] = rand() % 2;
  }

  fp = fopen("training.csv", "r");
  p = fgets(line, 4096, fp);
  ri = 0;
  while (fgets(line, 4096, fp))
  {
    p = strtok(line, ",");
    id[ri] = atoi(p);
    ri++;
  }

  fclose(fp);
  fp = fopen("training.csv", "r");
  p = fgets(line, 4096, fp);
  ri = 0;
  while (fgets(line, 4096, fp))
  {
    p = strtok(line, ",");
    for (ci = 0; ci < 31; ci++)
    {
      x[ri][ci] = atof(p);
      p = strtok(0, ",");
    }

    w[ri] = atof(p);
    p = strtok(0, ",");
    if ((p[0] == 's') || (p[0] == '1'))
      y[ri] = 1;
    else
      y[ri] = 0;

    ri += 1;
  }

  fclose(fp);
  if (ri != 250000)
  {
    fprintf(stderr, "ERROR: incorrect rows %d vs %d\n", 250000, ri);
    exit(1);
  }

  fp = fopen("smooth_gaussian_10.000000_10.csv", "r");
  p = fgets(line, 4096, fp);
  ri = 0;
  while (fgets(line, 4096, fp))
  {
    p = strtok(line, ",");
    for (ci = 0; ci < 31; ci++)
    {
      x[ri][31 + ci] = atof(p);
      p = strtok(0, ",");
    }

    w[ri] = atof(p);
    p = strtok(0, ",");
    if ((p[0] == 's') || (p[0] == '1'))
      y[ri] = 1;
    else
      y[ri] = 0;

    ri += 1;
  }

  fclose(fp);
  if (ri != 250000)
  {
    fprintf(stderr, "ERROR: incorrect rows %d vs %d\n", 250000, ri);
    exit(1);
  }

  mc = 0;
  for (ci = 0; ci < 31; ci++)
  {
    if (has_na[ci])
    {
      for (ri = 0; ri < 250000; ri++)
      {
        srt[ri] = x[ri][ci];
      }

      qsort(srt, 250000, sizeof(double), cmpd);
      med = srt[250000 / 2];
      for (ri = 0; ri < 250000; ri++)
      {
        if (x[ri][ci] == (-999))
        {
          x[ri][ci] = med;
          if (na_ind[ci])
            x[ri][(2 * 31) + mc] = 1;

        }
        else
        {
          if (na_ind[ci])
            x[ri][(2 * 31) + mc] = 0;

        }

      }

      if (na_ind[ci])
        mc++;

    }

  }

  mc = 65;
  for (ci = 0; ci < 531; ci++)
  {
    for (ci2 = ci + 1; ci2 < 531; ci2++)
    {
      if ((ci < 31) && (ci2 < 31))
      {
        for (ri = 0; ri < 250000; ri++)
        {
          x[ri][mc] = x[ri][ci] * x[ri][ci2];
        }

        mc++;
      }

    }

  }

  for (ci = 0; ci < 531; ci++)
  {
    avg[ci] = 0;
    for (ri = 0; ri < 250000; ri++)
    {
      avg[ci] += x[ri][ci];
    }

    avg[ci] /= 250000;
    sd[ci] = 0;
    for (ri = 0; ri < 250000; ri++)
    {
      sd[ci] += (avg[ci] - x[ri][ci]) * (avg[ci] - x[ri][ci]);
    }

    sd[ci] = sqrt(sd[ci] / 250000);
    if (sd[ci] > 0.00001)
    {
      for (ri = 0; ri < 250000; ri++)
      {
        x[ri][ci] = (x[ri][ci] - avg[ci]) / sd[ci];
      }

    }

  }

  for (ci = 0; ci < 531; ci++)
    if (ci < 65)
    use[ci] = 1;
  else
    use[ci] = 0;


  besta = 11110;
  bestc = 0;
  while (1)
  {
    #pragma omp parallel for
    for (tc = 0; tc < 531; tc++)
    {
      int r;
      int l2;
      int cv;
      int c;
      double maxa;
      double d;
      double pred;
      double ll;
      double lastsc;
      double b[2];
      double coef[2][531];
      if (use[tc] == 0)
      {
        for (cv = 0; cv < 2; cv++)
        {
          b[cv] = 0;
          for (c = 0; c < 531; c++)
          {
            coef[cv][c] = 0;
          }

        }

        lastsc = 99999;
        while (1)
        {
          ll = 0;
          for (cv = 0; cv < 2; cv++)
          {
            for (l2 = 0; l2 < 10; l2++)
            {
              for (r = 0; r < 250000; r++)
              {
                if (test[r] != cv)
                {
                  pred = b[cv];
                  for (c = 0; c < 531; c++)
                  {
                    if (use[c] || (c == tc))
                      pred += coef[cv][c] * x[r][c];

                  }

                  pred = 1 / (1 + exp(-pred));
                  if (pred < 0.001)
                    pred = 0.001;

                  if (pred > 0.999)
                    pred = 0.999;

                  d = y[r] - pred;
                  b[cv] += d * 0.00005;
                  for (c = 0; c < 531; c++)
                  {
                    if (use[c] || (c == tc))
                      coef[cv][c] += (d * x[r][c]) * 0.00005;

                  }

                }

              }

            }

            for (r = 0; r < 250000; r++)
            {
              if (test[r] == cv)
              {
                pred = b[cv];
                for (c = 0; c < 531; c++)
                {
                  if (use[c] || (c == tc))
                    pred += coef[cv][c] * x[r][c];

                }

                predt[r] = pred;
                pred = 1 / (1 + exp(-pred));
                if (pred < 0.001)
                  pred = 0.001;

                if (pred > 0.999)
                  pred = 0.999;

                ll += (y[r] * log(pred)) + ((1 - y[r]) * log(1 - pred));
              }

            }

          }

          maxa = (-ll) / 250000;
          if (fabs(lastsc - maxa) < 0.00001)
            break;

          lastsc = maxa;
        }

        if (maxa < besta)
        {
          besta = maxa;
          bestc = tc;
        }

      }

    }

    use[bestc] = 1;
    printf("%d %f\n", bestc, besta);
    fflush(stdout);
  }

  return 0;
}

