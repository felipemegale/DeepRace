double simulation_time_interpol(double fieldcloser, double fieldclose, double fieldfar, double fieldfarer, double distcloser, double distclose, double distfar, double distfarer, double dist)
{
  double pg;
  double g;
  double p;
  double c;
  double d;
  double dfdxc;
  double dfdxf;
  g = distfar - distclose;
  p = dist - distclose;
  if ((p < 0) || (p > g))
  {
    {
      printf("Error, out of range interpolation!\nWanted:	%le	(%le	%le)\nBoundary:	%le	%le	%le	%le\nField:	%le	%le	%le	%le\n", dist, p, g, distcloser, distclose, distfar, distfarer, fieldcloser, fieldclose, fieldfar, fieldfarer);
      fflush(stdout);
      exit(0);
    }
  }

  if (fieldfarer == fieldfar)
    dfdxf = (fieldfar - fieldclose) / g;
  else
  {
    c = g / (distfarer - distfar);
    dfdxf = ((fieldclose - fieldfar) - (((fieldfarer - fieldfar) * c) * c)) / ((-g) * (1.0 + c));
  }

  if (fieldcloser == fieldclose)
    dfdxc = (fieldfar - fieldclose) / g;
  else
  {
    c = (distcloser - distclose) / g;
    dfdxc = ((fieldcloser - fieldclose) - (((fieldfar - fieldclose) * c) * c)) / ((distcloser - distclose) * (1.0 - c));
  }

  pg = p / g;
  c = ((3 * (fieldfar - fieldclose)) - (dfdxf * g)) - ((2. * dfdxc) * g);
  d = ((dfdxf * g) + (dfdxc * g)) - (2 * (fieldfar - fieldclose));
  return ((fieldclose + (dfdxc * p)) + ((c * pg) * pg)) + (((d * pg) * pg) * pg);
}

