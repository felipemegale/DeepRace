{
  int data;
  struct tnode *left;
  struct tnode *right;
} tnode;
void omp_info();
void quick_sort(int *, int, int);
void printf_array(int *, int);
void sum_tree_data(struct tnode *, int *);
tnode *create_node();
void free_tree(tnode *);
void sum_tree_data(tnode *node, int *sum)
{
  if (node == 0)
    return;

  printf("Thread # %d, elem=%d\n", omp_get_thread_num(), node->data);
  *sum += node->data;
  #pragma omp task shared(node, sum)
  sum_tree_data(node->left, sum);
  #pragma omp task shared(node, sum)
  sum_tree_data(node->right, sum);
  #pragma omp taskwait
}

