static double num_steps = 100000000;
double step;
double start;
double end;
int noomp();
int wiomp();
int wiompc()
{
  int n;
  for (n = 1; n < 7; n++)
  {
    double pi = 0.0;
    int nthrds = 0;
    step = 1.0 / ((double) num_steps);
    omp_set_num_threads(n);
    start = omp_get_wtime();
    #pragma omp parallel
    {
      double x = 0;
      int i = 0;
      double sum;
      int id = omp_get_thread_num();
      int nthreads = omp_get_num_threads();
      if (id == 0)
      {
        nthrds = nthreads;
        printf("This one has used %d threads\n", nthrds);
      }

      for (i = id, sum = 0; i < num_steps; i += nthreads)
      {
        x = (i + 0.5) * step;
        sum += 4.0 / (1.0 + (x * x));
      }

      pi += sum * step;
    }
    end = omp_get_wtime();
    printf("%d threads takes %f time to process with SPMD Critical, result is %f\n", n, end - start, pi);
  }

  return 0;
}

