void broadcast(int, int, int);
void broadcast(int count, int tid, int local)
{
  #pragma omp parallel private(tid, local) shared(count)
  {
    #pragma omp master
    {
      local = 1;
      count = local;
    }
    #pragma omp barrier
    {
      tid = omp_get_thread_num();
      local = count;
    }
  }
}

