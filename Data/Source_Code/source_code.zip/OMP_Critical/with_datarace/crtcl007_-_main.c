static char rcsid[] = "$Id$";
int thds;
int errors = 0;
int data;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  omp_set_nested(0);
  clear();
  #pragma omp parallel
  {
    #pragma omp barrier
    #pragma omp parallel
    {
      {
        int i;
        i = read_data();
        waittime(1);
        write_data(i + 1);
      }
    }
  }
  check(thds);
  clear();
  #pragma omp parallel
  {
    #pragma omp barrier
    #pragma omp parallel
    {
      func_critical();
    }
  }
  check(thds);
  clear();
  func_critical();
  check(1);
  if (errors == 0)
  {
    printf("critical 007 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("critical 007 : FAILED\n");
    return 1;
  }

}

