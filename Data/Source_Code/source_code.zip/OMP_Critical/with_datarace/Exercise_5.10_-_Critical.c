void Critical(long n)
{
  int my_rank = omp_get_thread_num();
  int thread_count = omp_get_num_threads();
  int i;
  double my_sum = 0.0;
  for (i = 0; i < n; i++)
  {
    my_sum += 1.0;
  }

  printf("%2d/%2d |  my_sum = %f\n", my_rank, thread_count, my_sum);
}

