struct ind_gen;
struct ind_map;
int afs(struct ind_gen *matgen, struct ind_map *matmap, long int p1, long int p2, long int p3, long int col, long int row, int unfolded, int header, int summary, int nt)
{
  long int n1;
  long int n2;
  long int n3;
  long int i;
  long int k;
  long int j;
  long int x;
  long int y;
  long int z;
  unsigned int m1;
  unsigned int m2;
  unsigned int m3;
  long int tot[3];
  char iname[100];
  char inamedadi[100];
  FILE *o_afs;
  FILE *dadi_afs;
  int iCPU = omp_get_num_procs();
  if (nt > iCPU)
  {
    nt = iCPU;
  }

  omp_set_num_threads(nt);
  if (((p1 != (-1)) & (p2 != (-1))) & (p3 != (-1)))
  {
    if (unfolded == 1)
    {
      printf("-> Start computing unfolded joint AFS (pop1: [%s] - pop2: [%s] - pop3: [%s]) using %ld SNPs\t", matgen[p1].pop, matgen[p2].pop, matgen[p3].pop, col);
    }
    else
    {
      printf("-> Start computing folded joint AFS (pop1: [%s] - pop2: [%s] - pop3: [%s]) using %ld SNPs\t", matgen[p1].pop, matgen[p2].pop, matgen[p3].pop, col);
    }

  }
  else
    if (((p1 != (-1)) & (p2 != (-1))) & (p3 == (-1)))
  {
    if (unfolded == 1)
    {
      printf("-> Start computing unfolded joint AFS (pop1: [%s] - pop2: [%s]) using %ld SNPs\t", matgen[p1].pop, matgen[p2].pop, col);
    }
    else
    {
      printf("-> Start computing folded joint AFS (pop1: [%s] - pop2: [%s]) using %ld SNPs\t", matgen[p1].pop, matgen[p2].pop, col);
    }

  }
  else
    if (((p1 != (-1)) & (p2 == (-1))) & (p3 == (-1)))
  {
    if (unfolded == 1)
    {
      printf("-> Start computing unfolded AFS (pop1: [%s]) using %ld SNPs\t", matgen[p1].pop, col);
    }
    else
    {
      printf("-> Start computing folded AFS (pop1: [%s]) using %ld SNPs\t", matgen[p1].pop, col);
    }

  }



  if (((p1 == (-1)) & (p2 == (-1))) & (p3 == (-1)))
  {
    printf("\nERROR: afs: at least one population required!");
    return 1;
  }

  n1 = -1;
  n2 = -1;
  n3 = -1;
  if (p1 != (-1))
  {
    n1 = 0;
  }

  if (p2 != (-1))
  {
    n2 = 0;
  }

  if (p3 != (-1))
  {
    n3 = 0;
  }

  for (i = 0; i < row; i++)
  {
    if (p1 != (-1))
    {
      if (strcmp(matgen[p1].pop, matgen[i].pop) == 0)
      {
        n1++;
      }

    }

    if (p2 != (-1))
    {
      if (strcmp(matgen[p2].pop, matgen[i].pop) == 0)
      {
        n2++;
      }

    }

    if (p3 != (-1))
    {
      if (strcmp(matgen[p3].pop, matgen[i].pop) == 0)
      {
        n3++;
      }

    }

  }

  if (((p1 != (-1)) & (p2 != (-1))) & (p3 != (-1)))
  {
    x = (n1 * 2) + 1;
    y = (n2 * 2) + 1;
    z = (n3 * 2) + 1;
  }
  else
    if (((p1 != (-1)) & (p2 != (-1))) & (p3 == (-1)))
  {
    x = (n1 * 2) + 1;
    y = (n2 * 2) + 1;
    z = 1;
  }
  else
    if (((p1 != (-1)) & (p2 == (-1))) & (p3 == (-1)))
  {
    x = (n1 * 2) + 1;
    y = 1;
    z = 1;
  }



  long int *allElements = malloc(((x * y) * z) * (sizeof(long int)));
  if (allElements == 0)
  {
    printf("\nERROR: afs: error allocating memory (1)");
    return 1;
  }

  long int ***af = malloc(x * (sizeof(long int **)));
  if (af == 0)
  {
    printf("\nERROR: afs: error allocating memory (2)");
    return 1;
  }

  for (i = 0; i < x; i++)
  {
    af[i] = malloc(y * (sizeof(long int *)));
    if (af[i] == 0)
    {
      printf("\nERROR: afs: error allocating memory (3)");
      return 1;
    }

    for (j = 0; j < y; j++)
    {
      af[i][j] = (allElements + ((i * y) * z)) + (j * z);
    }

  }

  for (i = 0; i < x; i++)
  {
    for (j = 0; j < y; j++)
    {
      for (k = 0; k < z; k++)
      {
        af[i][j][k] = 0;
      }

    }

  }

  #pragma omp parallel for private(k,tot,i) shared(af) schedule(dynamic)
  for (k = 0; k < col; k++)
  {
    tot[0] = 0;
    tot[1] = 0;
    tot[2] = 0;
    m1 = 0;
    m2 = 0;
    m3 = 0;
    for (i = 0; i < row; i++)
    {
      if (p1 != (-1))
      {
        if (strcmp(matgen[p1].pop, matgen[i].pop) == 0)
        {
          if ((matgen[i].gen1[k] == 'N') | (matgen[i].gen1[k] == '0'))
          {
            m1 = 1;
          }

          if (unfolded == 0)
          {
            if (matgen[i].gen1[k] != matmap[k].ref)
            {
              tot[0]++;
            }

            if (matgen[i].gen2[k] != matmap[k].ref)
            {
              tot[0]++;
            }

          }

          if (unfolded == 1)
          {
            if (matgen[i].gen1[k] != matmap[k].anc)
            {
              tot[0]++;
            }

            if (matgen[i].gen2[k] != matmap[k].anc)
            {
              tot[0]++;
            }

          }

        }

      }

      if (p2 != (-1))
      {
        if (strcmp(matgen[p2].pop, matgen[i].pop) == 0)
        {
          if ((matgen[i].gen1[k] == 'N') | (matgen[i].gen1[k] == '0'))
          {
            m2 = 1;
          }

          if (unfolded == 0)
          {
            if (matgen[i].gen1[k] != matmap[k].ref)
            {
              tot[1]++;
            }

            if (matgen[i].gen2[k] != matmap[k].ref)
            {
              tot[1]++;
            }

          }

          if (unfolded == 1)
          {
            if (matgen[i].gen1[k] != matmap[k].anc)
            {
              tot[1]++;
            }

            if (matgen[i].gen2[k] != matmap[k].anc)
            {
              tot[1]++;
            }

          }

        }

      }

      if (p3 != (-1))
      {
        if (strcmp(matgen[p3].pop, matgen[i].pop) == 0)
        {
          if ((matgen[i].gen1[k] == 'N') | (matgen[i].gen1[k] == '0'))
          {
            m3 = 1;
          }

          if (unfolded == 0)
          {
            if (matgen[i].gen1[k] != matmap[k].ref)
            {
              tot[2]++;
            }

            if (matgen[i].gen2[k] != matmap[k].ref)
            {
              tot[2]++;
            }

          }

          if (unfolded == 1)
          {
            if (matgen[i].gen1[k] != matmap[k].anc)
            {
              tot[2]++;
            }

            if (matgen[i].gen2[k] != matmap[k].anc)
            {
              tot[2]++;
            }

          }

        }

      }

    }

    if ((((((p1 != (-1)) & (p2 != (-1))) & (p3 != (-1))) & (m1 == 0)) & (m2 == 0)) & (m3 == 0))
    {
      af[tot[0]][tot[1]][tot[2]]++;
    }
    else
      if (((((p1 != (-1)) & (p2 != (-1))) & (p3 == (-1))) & (m1 == 0)) & (m2 == 0))
    {
      af[tot[0]][tot[1]][0]++;
    }
    else
      if ((((p1 != (-1)) & (p2 == (-1))) & (p3 == (-1))) & (m1 == 0))
    {
      af[tot[0]][0][0]++;
    }



  }

  printf("[done]");
  printf(" - Writing AFS to file\t");
  if (summary)
  {
    if (unfolded == 1)
    {
      strcpy(iname, "AFS-U_SUMMARY");
    }
    else
    {
      strcpy(iname, "AFS-F_SUMMARY");
    }

    strcpy(inamedadi, iname);
    strcat(iname, ".txt");
    strcat(inamedadi, ".dadi.txt");
    o_afs = fopen(iname, "a+");
    dadi_afs = fopen(inamedadi, "a+");
  }
  else
  {
    if (unfolded == 1)
    {
      strcpy(iname, "AFS-U_");
    }
    else
    {
      strcpy(iname, "AFS-F_");
    }

    if (p1 != (-1))
    {
      strcat(iname, matgen[p1].pop);
    }

    if (p2 != (-1))
    {
      strcat(iname, "_");
      strcat(iname, matgen[p2].pop);
    }

    if (p3 != (-1))
    {
      strcat(iname, "_");
      strcat(iname, matgen[p3].pop);
    }

    strcpy(inamedadi, iname);
    strcat(iname, ".txt");
    strcat(inamedadi, ".dadi.txt");
    o_afs = fopen(iname, "w");
    dadi_afs = fopen(inamedadi, "w");
  }

  if (header == 1)
  {
    if (p1 != (-1))
    {
      for (i = 0; i < x; i++)
      {
        if (p2 != (-1))
        {
          for (k = 0; k < y; k++)
          {
            if (p3 != (-1))
            {
              for (j = 0; j < z; j++)
              {
                if (unfolded == 1)
                {
                  fprintf(o_afs, "u_%s%ld_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k, matgen[p3].pop, j);
                  fprintf(dadi_afs, "#u_%s%ld_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k, matgen[p3].pop, j);
                }
                else
                  if (unfolded == 0)
                {
                  fprintf(o_afs, "f_%s%ld_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k, matgen[p3].pop, j);
                  fprintf(dadi_afs, "#f_%s%ld_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k, matgen[p3].pop, j);
                }


              }

            }
            else
            {
              if (unfolded == 1)
              {
                fprintf(o_afs, "u_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k);
                fprintf(dadi_afs, "#u_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k);
              }
              else
                if (unfolded == 0)
              {
                fprintf(o_afs, "f_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k);
                fprintf(dadi_afs, "#f_%s%ld_%s%ld\t", matgen[p1].pop, i, matgen[p2].pop, k);
              }


            }

          }

        }
        else
        {
          if (unfolded == 1)
          {
            fprintf(o_afs, "u_%s%ld\t", matgen[p1].pop, i);
            fprintf(dadi_afs, "#u_%s%ld\t", matgen[p1].pop, i);
          }
          else
            if (unfolded == 0)
          {
            fprintf(o_afs, "f_%s%ld\t", matgen[p1].pop, i);
            fprintf(dadi_afs, "#f_%s%ld\t", matgen[p1].pop, i);
          }


        }

      }

    }

    fprintf(o_afs, "\n");
    fprintf(dadi_afs, "\n");
  }

  if (((p1 != (-1)) & (p2 != (-1))) & (p3 != (-1)))
  {
    fprintf(dadi_afs, "%ld %ld %ld unfolded\n", x, y, z);
    for (i = 0; i < x; i++)
    {
      for (k = 0; k < y; k++)
      {
        for (j = 0; j < z; j++)
        {
          fprintf(o_afs, "%ld\t", af[i][k][j]);
          fprintf(dadi_afs, "%ld\t", af[i][k][j]);
        }

      }

    }

    fprintf(o_afs, "\n");
    fprintf(dadi_afs, "\n");
    for (i = 0; i < ((x * y) * z); i++)
    {
      fprintf(dadi_afs, "0");
      if (i != ((x * y) * z))
      {
        fprintf(dadi_afs, " ");
      }

    }

    fprintf(dadi_afs, "\n");
  }
  else
    if (((p1 != (-1)) & (p2 != (-1))) & (p3 == (-1)))
  {
    fprintf(dadi_afs, "%ld %ld unfolded\n", x, y);
    for (i = 0; i < x; i++)
    {
      for (k = 0; k < y; k++)
      {
        fprintf(o_afs, "%ld\t", af[i][k][0]);
        fprintf(dadi_afs, "%ld\t", af[i][k][0]);
      }

    }

    fprintf(o_afs, "\n");
    fprintf(dadi_afs, "\n");
    for (i = 0; i < (x * y); i++)
    {
      fprintf(dadi_afs, "0");
      if (i != (x * y))
      {
        fprintf(dadi_afs, " ");
      }

    }

    fprintf(dadi_afs, "\n");
  }
  else
    if (((p1 != (-1)) & (p2 == (-1))) & (p3 == (-1)))
  {
    fprintf(dadi_afs, "%ld unfolded\n", x);
    for (i = 0; i < x; i++)
    {
      fprintf(o_afs, "%ld\t", af[i][0][0]);
      fprintf(dadi_afs, "%ld\t", af[i][0][0]);
    }

    fprintf(o_afs, "\n");
    fprintf(dadi_afs, "\n");
    for (i = 0; i < x; i++)
    {
      fprintf(dadi_afs, "0");
      if (i != x)
      {
        fprintf(dadi_afs, " ");
      }

    }

    fprintf(dadi_afs, "\n");
  }



  free(allElements);
  for (i = 0; i < x; i++)
  {
    free(af[i]);
  }

  free(af);
  fclose(o_afs);
  fclose(dadi_afs);
  printf("[done]\n");
  return 0;
}

