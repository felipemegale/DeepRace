int dtrsm_unittest(unsigned int min_size, unsigned int max_size, FILE *output_file)
{
  printf("In utr_create_assemble_stiff_mat_openmp: Problem_id %d, Level_id %d\n", Problem_id, Level_id);
  printf("Comp_type %d, Mth_control %d, Nr_int_ent %d, Max_dofs_int_ent %d\n", Comp_type, Mth_control, Nr_int_ent, Max_dofs_int_ent);
  int nr_elems = 0;
  int int_entity;
  int previous_type = PDC_ELEMENT;
  int ok = 1;
  for (int_entity = 0; int_entity < Nr_int_ent; int_entity++)
  {
    if (L_int_ent_type[int_entity] == PDC_ELEMENT)
    {
      nr_elems++;
      if (previous_type != PDC_ELEMENT)
        ok = 0;

    }
    else
      previous_type = PDC_FACE;

  }

  int nr_faces = Nr_int_ent - nr_elems;
  printf("nr_elems %d, nr_faces %d, ok %d\n", nr_elems, nr_faces, ok);
  if (ok != 1)
  {
    printf("Elements are not first on the list to integrate. \nOpenMP is not optimized for that case.\n");
  }

  #pragma omp parallel if(Mth_control==PDC_MTH_OPENMP) default(none) firstprivate(Problem_id, Level_id, Comp_type, nr_elems, Nr_int_ent, L_int_ent_type, L_int_ent_id, Max_dofs_int_ent, L_dof_elem_to_struct, L_dof_face_to_struct, L_dof_edge_to_struct, L_dof_vert_to_struct )
  {
    int nrdofs_glob;
    int max_nrdofs;
    int nr_dof_ent;
    int nr_levels;
    int posglob;
    int nrdofs_int_ent;
    int l_dof_ent_id[PDC_MAX_DOF_PER_INT];
    int l_dof_ent_nrdof[PDC_MAX_DOF_PER_INT];
    int l_dof_ent_posglob[PDC_MAX_DOF_PER_INT];
    int l_dof_ent_type[PDC_MAX_DOF_PER_INT];
    double *x_ini;
    double normb;
    int i;
    int j;
    int k;
    int iaux;
    int kaux;
    int intent;
    int ibl;
    int ient;
    int nrdofbl;
    int ini_zero;
    int level_id = 0;
    char rewrite;
    max_nrdofs = Max_dofs_int_ent;
    double *stiff_mat = (double *) malloc((max_nrdofs * max_nrdofs) * (sizeof(double)));
    double *rhs_vect = (double *) malloc(max_nrdofs * (sizeof(double)));
    memset(stiff_mat, 0, (max_nrdofs * max_nrdofs) * (sizeof(double)));
    memset(rhs_vect, 0, max_nrdofs * (sizeof(double)));
    int flag = 0;
    #pragma omp for
    for (intent = 0; intent < nr_elems; intent++)
    {
      int nrdfobl;
      int idofent;
      int nr_dof_ent = PDC_MAX_DOF_PER_INT;
      int nrdofs_int_ent = max_nrdofs;
      int l_bl_id[PDC_MAX_DOF_PER_INT];
      int l_bl_nrdofs[PDC_MAX_DOF_PER_INT];
      if (flag == 0)
      {
        #pragma omp critical(printing)
        {
          printf("In utr_create_assemble_stiff_mat before calling pdr_comp_stiff_mat\n");
          printf("intent %d, last %d, type %d, id %d, thread_id %d, num_threads %d\n", intent, Nr_int_ent - 1, L_int_ent_type[intent], L_int_ent_id[intent], omp_get_thread_num(), omp_get_num_threads());
        }
      }

      flag = 1;
      {
        pdr_comp_stiff_mat(Problem_id, L_int_ent_type[intent], L_int_ent_id[intent], Comp_type, 0, &nr_dof_ent, l_dof_ent_type, l_dof_ent_id, l_dof_ent_nrdof, &nrdofs_int_ent, stiff_mat, rhs_vect, &rewrite);
      }
      nrdofbl = nr_dof_ent;
      for (idofent = 0; idofent < nr_dof_ent; idofent++)
      {
        int dof_ent_id = l_dof_ent_id[idofent];
        int dof_ent_type = l_dof_ent_type[idofent];
        int dof_ent_nrdofs = l_dof_ent_nrdof[idofent];
        int dof_struct_id;
        if (dof_ent_type == PDC_ELEMENT)
        {
          dof_struct_id = L_dof_elem_to_struct[dof_ent_id];
        }
        else
          if (dof_ent_type == PDC_FACE)
        {
          dof_struct_id = L_dof_face_to_struct[dof_ent_id];
        }
        else
          if (dof_ent_type == PDC_EDGE)
        {
          dof_struct_id = L_dof_edge_to_struct[dof_ent_id];
        }
        else
          if (dof_ent_type == PDC_VERTEX)
        {
          dof_struct_id = L_dof_vert_to_struct[dof_ent_id];
        }




        l_bl_id[idofent] = dof_struct_id + 1;
        l_bl_nrdofs[idofent] = dof_ent_nrdofs;
      }

      #pragma omp critical(assembling)
      {
        pdr_assemble_local_stiff_mat(Problem_id, level_id, Comp_type, nrdofbl, l_bl_id, l_bl_nrdofs, stiff_mat, rhs_vect, &rewrite);
      }
    }

    flag = 0;
    #pragma omp for
    for (intent = nr_elems; intent < Nr_int_ent; intent++)
    {
      int nrdfobl;
      int idofent;
      int nr_dof_ent = PDC_MAX_DOF_PER_INT;
      int nrdofs_int_ent = max_nrdofs;
      int l_bl_id[PDC_MAX_DOF_PER_INT];
      int l_bl_nrdofs[PDC_MAX_DOF_PER_INT];
      if (flag == 0)
      {
        printf("In utr_create_assemble_stiff_mat before calling pdr_comp_stiff_mat\n");
        printf("intent %d, type %d, id %d, thread_id %d, num_threads %d\n", intent, L_int_ent_type[intent], L_int_ent_id[intent], omp_get_thread_num(), omp_get_num_threads());
      }

      flag = 1;
      {
        pdr_comp_stiff_mat(Problem_id, L_int_ent_type[intent], L_int_ent_id[intent], Comp_type, 0, &nr_dof_ent, l_dof_ent_type, l_dof_ent_id, l_dof_ent_nrdof, &nrdofs_int_ent, stiff_mat, rhs_vect, &rewrite);
      }
      nrdofbl = nr_dof_ent;
      for (idofent = 0; idofent < nr_dof_ent; idofent++)
      {
        int dof_ent_id = l_dof_ent_id[idofent];
        int dof_ent_type = l_dof_ent_type[idofent];
        int dof_ent_nrdofs = l_dof_ent_nrdof[idofent];
        int dof_struct_id;
        if (dof_ent_type == PDC_ELEMENT)
        {
          dof_struct_id = L_dof_elem_to_struct[dof_ent_id];
        }
        else
          if (dof_ent_type == PDC_FACE)
        {
          dof_struct_id = L_dof_face_to_struct[dof_ent_id];
        }
        else
          if (dof_ent_type == PDC_EDGE)
        {
          dof_struct_id = L_dof_edge_to_struct[dof_ent_id];
        }
        else
          if (dof_ent_type == PDC_VERTEX)
        {
          dof_struct_id = L_dof_vert_to_struct[dof_ent_id];
        }




        l_bl_id[idofent] = dof_struct_id + 1;
        l_bl_nrdofs[idofent] = dof_ent_nrdofs;
      }

      #pragma omp critical(assembling)
      {
        pdr_assemble_local_stiff_mat(Problem_id, level_id, Comp_type, nrdofbl, l_bl_id, l_bl_nrdofs, stiff_mat, rhs_vect, &rewrite);
      }
    }

    free(stiff_mat);
    free(rhs_vect);
  }
  return 1;

  double *data;
  double *result;
  double *result_blas;
  dtrsm_initialize(&data, &result, &result_blas, max_size);
  int test_status = TEST_SUCCESS;
  unsigned char offseta;
  test_print_header(output_file);
  #pragma omp parallel default(shared)
  {
    struct test_statistics_t test_stat;
    test_papi_initialize(&test_stat);
    int tid = omp_get_thread_num();
    unsigned int i;
    unsigned int j;
    for (i = min_size; i < max_size; i++)
    {
      #pragma omp single
      {
        for (j = 0; j < (i * i); j++)
          result[j] = (result_blas[j] = ((double) rand()) / 32767);

        offseta = rand() % (max_size * max_size);
      }
      int retval;
      test_stat.elapsed_time = PAPI_get_real_usec();
      if ((retval = PAPI_reset(test_stat.event_set)) != PAPI_OK)
        test_fail("dtrsm_unittest.c", 68, "PAPI_reset", retval);

      dtrsm(i, i, data + offseta, result);
      if ((retval = PAPI_read(test_stat.event_set, test_stat.counters)) != PAPI_OK)
        test_fail("dtrsm_unittest.c", 73, "PAPI_read", retval);

      test_stat.elapsed_time = PAPI_get_real_usec() - test_stat.elapsed_time;
      test_print_statistic(tid, i, test_stat, output_file);
      #pragma omp single
      {
        cblas_dtrsm(CblasRowMajor, CblasLeft, CblasLower, CblasNoTrans, CblasNonUnit, i, i, 1.0, data + offseta, i, result_blas, i);
        double result_norm;
        double result_blas_norm;
        result_norm = LAPACKE_dlange(LAPACK_ROW_MAJOR, '1', i, i, result, i);
        result_blas_norm = LAPACKE_dlange(LAPACK_ROW_MAJOR, '1', i, i, result_blas, i);
        if (abs((result_norm - result_blas_norm) / result_norm) > MACH_ERROR)
          test_status = TEST_FAIL;

      }
    }

    test_papi_destroy(&test_stat);
  }
  free(data);
  free(result);
  free(result_blas);
  return test_status;
}

