int main(void)
{
  double count = 0.0;
  double pih = 0;
  int lim = 2147483647;
  double dlim = 2147483647.0;
  double x;
  double y;
  int i;
  #pragma omp parallel for num_threads(16)
  for (i = 0; i < lim; i++)
  {
    x = random_f();
    y = random_f();
    if (((x * x) + (y * y)) < 1)
    {
      count++;
    }

  }

  pih = (4.0 * count) / dlim;
  printf("%lf\n", pih);

  int i;
  int j;
  int numeros[6];
  int seeds[6];
  srand((int) time(0));
  for (j = 0; j < 6; ++j)
    seeds[j] = rand();

  omp_set_nested(1);
  #pragma omp parallel num_threads(2)
  {
    #pragma omp sections
    {
      #pragma omp section
      {
        #pragma omp critical
        {
          #pragma omp parallel shared(i) num_threads(4)
          {
            printf("Thread %d de %d\n", omp_get_thread_num(), omp_get_num_threads());
            #pragma omp atomic
            i++;
          }
        }
      }
      #pragma omp section
      {
        #pragma omp parallel shared(numeros, seeds) num_threads(6)
        {
          int seed = seeds[omp_get_thread_num()];
          numeros[omp_get_thread_num()] = rand_r(&seed) % 10000;
          #pragma omp barrier
          #pragma omp master
          {
            printf("\nIteraciones: %d\n", omp_get_num_threads());
            int sum = 0;
            for (j = 0; j < 6; ++j)
              sum += numeros[j];

            printf("Suma: %d\n", sum);
            printf("Promedio: %f\n", (sum + 0.0) / 6);
          }
        }
      }
    }
  }
  return 0;
}

