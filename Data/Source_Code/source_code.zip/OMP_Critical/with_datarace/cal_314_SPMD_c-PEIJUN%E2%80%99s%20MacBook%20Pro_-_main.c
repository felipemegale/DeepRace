static long NUM_STEP = 100000000;
double STEP;
void main()
{
  int i;
  int nthreads;
  double pi;
  double STEP = 1.00 / ((double) NUM_STEP);
  double start = omp_get_wtime();
  omp_set_num_threads(4);
  #pragma omp parallel
  {
    int i;
    int id;
    int nthrds;
    double x;
    double sum;
    nthrds = omp_get_num_threads();
    id = omp_get_thread_num();
    if (id == 0)
      nthreads = nthrds;

    for (i = id, sum = 0.0; i < NUM_STEP; i = i + nthrds)
    {
      x = (i + 0.5) * STEP;
      sum += 4.0 / (1.0 + (x * x));
    }

    pi += sum * STEP;
  }
  printf("Time for this omp process is : \t %f \n", omp_get_wtime() - start);
  printf("the simulated psi is %f\n", pi);

  double x;
  double area = 0;
  #pragma omp parallel for private(x)
  for (int i = 0; i < 100000000; i++)
  {
    x = (((double) i) + 0.5) / 100000000;
    #pragma omp critical
    area += 4.0 / (1.0 + (x * x));
  }

  double pi = area / 100000000;
  printf("pi = %llf\n", pi);
  return 0;
}

