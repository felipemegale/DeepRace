size_t n_threads;
void read_cells()
{
  unsigned long i;
  unsigned long j;
  unsigned long lines = 0;
  unsigned short dist;
  int fscan;
  char *filename = "cells";
  FILE *fp = fopen(filename, "r");
  char ch = 0;
  while (!feof(fp))
  {
    ch = fgetc(fp);
    if (ch == '\n')
    {
      lines++;
    }

  }

  rewind(fp);
  float cell_array[lines][3];
  unsigned long count_array[3466];
  memset(count_array, 0, 3466 * (sizeof(unsigned long)));
  for (i = 0; i < lines; i++)
  {
    fscan = fscanf(fp, "%f %f %f", &cell_array[i][0], &cell_array[i][1], &cell_array[i][2]);
  }

  fclose(fp);
  #pragma omp parallel shared(lines,cell_array)
  {
    unsigned long count_array_private[3466];
    memset(count_array_private, 0, 3466 * (sizeof(unsigned long)));
    #pragma omp for private(i,j,dist) schedule(static,32)
    for (i = 0; i < lines; i++)
    {
      for (j = i + 1; j < lines; j++)
      {
        dist = roundf(sqrtf((((cell_array[i][0] - cell_array[j][0]) * (cell_array[i][0] - cell_array[j][0])) + ((cell_array[i][1] - cell_array[j][1]) * (cell_array[i][1] - cell_array[j][1]))) + ((cell_array[i][2] - cell_array[j][2]) * (cell_array[i][2] - cell_array[j][2]))) * 100);
        count_array_private[dist]++;
      }

    }

    {
      for (i = 0; i < 3466; i++)
      {
        count_array[i] += count_array_private[i];
      }

    }
  }
  for (i = 0; i < 3466; i++)
  {
    printf("%05.2f %ld\n", (1.0f * i) / 100, count_array[i]);
  }

}

