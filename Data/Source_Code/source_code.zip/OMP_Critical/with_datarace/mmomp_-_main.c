int main(int argc, char *argv[])
{
  int x;
  x = atoi(argv[1]);
  int i;
  int j;
  int k;
  int mat1[100][100];
  int mat2[100][100];
  int mat3[100][100];
  int prod = 0;
  omp_set_num_threads(5);
  srand(10);
  for (i = 0; i < x; i++)
  {
    for (j = 0; j < x; j++)
    {
      mat1[i][j] = (rand() % 10) + 1;
    }

  }

  for (i = 0; i < x; i++)
  {
    for (j = 0; j < x; j++)
    {
    }

  }

  srand(15);
  for (i = 0; i < x; i++)
  {
    for (j = 0; j < x; j++)
    {
      mat2[i][j] = (rand() % 10) + 1;
    }

  }

  for (i = 0; i < x; i++)
  {
    for (j = 0; j < x; j++)
    {
    }

  }

  clock_t start = clock();
  clock_t diff;
  #pragma omp parallel for private(i)
  for (i = 0; i < x; i++)
  {
    #pragma omp parallel for private(j)
    for (j = 0; j < x; j++)
    {
      for (k = 0; k < x; k++)
      {
        prod = prod + (mat1[i][k] * mat2[k][j]);
      }

      mat3[i][j] = prod;
      prod = 0;
    }

  }

  diff = clock() - start;
  printf("%d", diff);
  for (i = 0; i < x; i++)
  {
    for (j = 0; j < x; j++)
    {
    }

  }

  return 0;
}

