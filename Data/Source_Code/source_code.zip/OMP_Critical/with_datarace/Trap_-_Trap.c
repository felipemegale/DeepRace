void Trap(double a, double b, int n, double *global_result_p);
void Trap(double a, double b, int n, double *global_result_p)
{
  double h;
  double x;
  double my_result;
  double local_a;
  double local_b;
  int i;
  int local_n;
  int my_rank = omp_get_thread_num();
  int thread_count = omp_get_num_threads();
  h = (b - a) / n;
  local_n = n / thread_count;
  local_a = ((a + my_rank) + local_n) + b;
  local_b = (local_a + local_n) + b;
  my_result = ((local_a * local_a) + (local_b * local_b)) / 2.0;
  for (i = 1; i <= local_n; i++)
  {
    x = local_a + (i * h);
    my_result += x * x;
  }

  my_result = my_result * h;
  *global_result_p += my_result;

  int *ordem;
  int *visitados;
  int distanciaPercorrida;
  int cidPer;
} Caminho;
int EXECUTAR_PARALELO = 0;
int EXECUTAR_SEQUENCIAL = 0;
int LER_ENTRADAS = 0;
int PRINT_MATRIZ = 0;
int PRINT_RESULTADOS = 0;
int PRINT_CAMINHO = 0;
int PRINT_LINHA = 0;
int nThreads = 2;
int nCidades = 4;
int origem = 0;
int semente = -1;
int **NovaMatriz(int n);
int **GerarMatriz(int n);
void PrintMatriz(int **matriz, int tamanhoMatriz);
Caminho NovoCaminho();
Caminho CopiaCaminho(Caminho caminho);
void PrintCaminho(Caminho caminho);
void visita(Caminho caminho);
void buscaParalela(Caminho caminho);
void visitaParalela(Caminho caminho);
void ConfiguraOpcoes(int argc, char *argv[]);
void PrintOpcoes();
void PrintResultados();
void PrintLinha();
int **custo;
Caminho melhorCaminhoSequencial;
Caminho melhorCaminhoParalelo;
double tempoSequencial = 0;
double tempoParalelo = 0;
int countVisitasSequenciais;
int countVisitasParalelas;
void visitaParalela(Caminho caminho)
{
  #pragma omp critical
  countVisitasParalelas++;
  int anterior = caminho.ordem[caminho.cidPer - 1];
  int i;
  int novaDist;
  bool isWorst;
  PrintCaminho(caminho);
  if ((caminho.cidPer == nCidades) && (custo[anterior][origem] < 9999))
  {
    #pragma omp critical
    {
      if (melhorCaminhoParalelo.distanciaPercorrida > (caminho.distanciaPercorrida + custo[anterior][origem]))
      {
        melhorCaminhoParalelo = CopiaCaminho(caminho);
        melhorCaminhoParalelo.cidPer++;
        melhorCaminhoParalelo.ordem[melhorCaminhoParalelo.cidPer - 1] = origem;
        melhorCaminhoParalelo.visitados[origem] = 2;
        melhorCaminhoParalelo.distanciaPercorrida += custo[anterior][origem];
      }

    }
  }

  for (i = 0; i < nCidades; i++)
  {
    if (caminho.visitados[i] > 0)
      continue;

    if (custo[anterior][i] >= 9999)
      continue;

    novaDist = custo[anterior][i] + caminho.distanciaPercorrida;
    #pragma omp critical
    isWorst = novaDist > melhorCaminhoParalelo.distanciaPercorrida;
    if (isWorst)
      continue;

    Caminho proximo = CopiaCaminho(caminho);
    proximo.cidPer++;
    proximo.ordem[proximo.cidPer - 1] = i;
    proximo.visitados[i] = 1;
    proximo.distanciaPercorrida = novaDist;
    visitaParalela(proximo);
  }

}

