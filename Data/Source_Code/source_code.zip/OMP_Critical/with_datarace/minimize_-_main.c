int main(int argc, char **argv)
{
  int N = 1024;
  if (argc > 1)
    N = atoi(argv[1]);

  srand(0);
  int *a = (int *) malloc(N * (sizeof(int)));
  for (int i = 0; i < N; ++i)
    a[i] = rand();

  int minimum = 32767;
  for (int i = 0; i < N; ++i)
    minimum = min(minimum, a[i]);

  printf("Serial min:   %d\n", minimum);
  minimum = 32767;
  #pragma omp parallel shared(a,minimum) num_threads(4)
  {
    int local_minimum = minimum;
    int temp;
    #pragma omp for nowait
    for (int i = 0; i < N; ++i)
      local_minimum = min(local_minimum, a[i]);

    {
      temp = min(local_minimum, minimum);
      for (int j = 0; j < 100000; ++j)
        local_minimum += 0.0001 * j;

      minimum = temp;
    }
  }
  printf("Parallel min: %d\n", minimum);
  free(a);
}

