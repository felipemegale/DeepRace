void SRbarrier5(int *count, int *sense, int *local_sense, unsigned int *local_spin_count)
{
  int sum;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  sum = 0;
  #pragma omp parallel
  {
    #pragma omp for lastprivate(prvt)
    for (prvt = 0; prvt < 103; prvt++)
    {
      #pragma omp critical
      sum += 1;
    }

  }
  if (sum != 103)
  {
    errors += 1;
  }

  if (prvt != 103)
  {
    errors += 1;
  }

  sum = 0;
  #pragma omp parallel
  {
    #pragma omp for schedule(static) lastprivate(prvt)
    for (prvt = 0; prvt < 103; prvt++)
    {
      #pragma omp critical
      sum += 1;
    }

  }
  if (sum != 103)
  {
    errors += 1;
  }

  if (prvt != 103)
  {
    errors += 1;
  }

  sum = 0;
  #pragma omp parallel
  {
    #pragma omp for schedule(dynamic) lastprivate(prvt)
    for (prvt = 0; prvt < 103; prvt++)
    {
      #pragma omp critical
      sum += 1;
    }

  }
  if (sum != 103)
  {
    errors += 1;
  }

  if (prvt != 103)
  {
    errors += 1;
  }

  sum = 0;
  #pragma omp parallel
  {
    #pragma omp for schedule(guided) lastprivate(prvt)
    for (prvt = 0; prvt < 103; prvt++)
    {
      #pragma omp critical
      sum += 1;
    }

  }
  if (sum != 103)
  {
    errors += 1;
  }

  if (prvt != 103)
  {
    errors += 1;
  }

  sum = 0;
  #pragma omp parallel
  {
    #pragma omp for schedule(runtime) lastprivate(prvt)
    for (prvt = 0; prvt < 103; prvt++)
    {
      #pragma omp critical
      sum += 1;
    }

  }
  if (sum != 103)
  {
    errors += 1;
  }

  if (prvt != 103)
  {
    errors += 1;
  }

  if (errors == 0)
  {
    printf("lastprivate 023 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("lastprivate 023 : FAILED\n");
    return 1;
  }


  *local_sense = !(*local_sense);
  {
    *count = (*count) - 1;
    if ((*count) == 0)
    {
      *count = omp_get_num_threads();
      *sense = *local_sense;
    }

  }
  int delay = EB_DELAY;
  while ((*sense) != (*local_sense))
  {
    (*local_spin_count)++;
    usleep(delay);
    delay = delay * delay;
  }

  ;
}

