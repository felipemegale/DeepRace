int main(int argc, char **argv)
{
  int size = atoi(argv[1]);
  int trans_x = 32;
  int trans_y = 32;
  float *rx_x;
  float *rx_y;
  float rx_z = 0;
  int data_len = 12308;
  int offset = 0;
  float *rx_data;
  float tx_x = 0;
  float tx_y = 0;
  float tx_z = -0.001;
  int point;
  float *point_x;
  float *point_y;
  float *point_z;
  int pts_r = 1560;
  int sls_t = size;
  int sls_p = size;
  float *image_pos;
  float *image;
  float x_comp;
  float y_comp;
  float z_comp;
  float *dist_tx;
  float dist;
  const float idx_const = 0.000009625;
  const int filter_delay = 140;
  int index;
  FILE *input;
  FILE *output;
  rx_x = (float *) malloc((trans_x * trans_y) * (sizeof(float)));
  if (rx_x == 0)
    fprintf(stderr, "Bad malloc on rx_x\n");

  rx_y = (float *) malloc((trans_x * trans_y) * (sizeof(float)));
  if (rx_y == 0)
    fprintf(stderr, "Bad malloc on rx_y\n");

  rx_data = (float *) malloc(((data_len * trans_x) * trans_y) * (sizeof(float)));
  if (rx_data == 0)
    fprintf(stderr, "Bad malloc on rx_data\n");

  point_x = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
  if (point_x == 0)
    fprintf(stderr, "Bad malloc on point_x\n");

  point_y = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
  if (point_y == 0)
    fprintf(stderr, "Bad malloc on point_y\n");

  point_z = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
  if (point_z == 0)
    fprintf(stderr, "Bad malloc on point_z\n");

  dist_tx = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
  if (dist_tx == 0)
    fprintf(stderr, "Bad malloc on dist_tx\n");

  image = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
  if (image == 0)
    fprintf(stderr, "Bad malloc on image\n");

  memset(image, 0, ((pts_r * sls_t) * sls_p) * (sizeof(float)));
  float *image_private = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
  memset(image_private, 0, ((pts_r * sls_t) * sls_p) * (sizeof(float)));
  if ((argc < 1) || (!((strcmp(argv[1], "16") || strcmp(argv[1], "32")) || strcmp(argv[1], "64"))))
  {
    printf("Usage: %s {16|32|64}\n", argv[0]);
    fflush(stdout);
    exit(-1);
  }

  char buff[128];
  sprintf(buff, "/n/typhon/home/eecs570/beamforming_input_%s.bin", argv[1]);
  input = fopen(buff, "rb");
  if (!input)
  {
    printf("Unable to open input file %s.\n", buff);
    fflush(stdout);
    exit(-1);
  }

  fread(rx_x, sizeof(float), trans_x * trans_y, input);
  fread(rx_y, sizeof(float), trans_x * trans_y, input);
  fread(point_x, sizeof(float), (pts_r * sls_t) * sls_p, input);
  fread(point_y, sizeof(float), (pts_r * sls_t) * sls_p, input);
  fread(point_z, sizeof(float), (pts_r * sls_t) * sls_p, input);
  fread(rx_data, sizeof(float), (data_len * trans_x) * trans_y, input);
  fclose(input);
  printf("Beginning computation\n");
  fflush(stdout);
  struct timeval tv;
  gettimeofday(&tv, 0);
  uint64_t start = (tv.tv_sec * ((uint64_t) 1000000)) + tv.tv_usec;
  int it_rx;
  int it_r;
  int it_t;
  int it_p;
  point = 0;
  int boundry = (sls_t * sls_p) * pts_r;
  int inner = (sls_t * sls_p) * pts_r;
  int outer = trans_y * trans_y;
  #pragma omp parallel for shared (boundry, dist_tx, point_x, point_y, point_z, tx_x, tx_y, tx_z) private (it_t, x_comp, y_comp, z_comp) schedule(static) default(none)
  for (it_t = 0; it_t < boundry; it_t++)
  {
    x_comp = tx_x - point_x[it_t];
    x_comp = x_comp * x_comp;
    y_comp = tx_y - point_y[it_t];
    y_comp = y_comp * y_comp;
    z_comp = tx_z - point_z[it_t];
    z_comp = z_comp * z_comp;
    dist_tx[it_t] = (float) sqrt((x_comp + y_comp) + z_comp);
  }

  #pragma omp parallel
  {
    float *image_private = (float *) malloc(((pts_r * sls_t) * sls_p) * (sizeof(float)));
    memset(image_private, 0, ((pts_r * sls_t) * sls_p) * (sizeof(float)));
    #pragma omp for
    for (point = 0; point < inner; point++)
    {
      image_private[point] = 0;
    }

    #pragma omp for schedule(guided)
    for (it_rx = 0; it_rx < outer; it_rx++)
    {
      #pragma loop count min(1000000)
      for (point = 0; point < inner; point++)
      {
        offset = it_rx * data_len;
        x_comp = rx_x[it_rx] - point_x[point];
        x_comp = x_comp * x_comp;
        y_comp = rx_y[it_rx] - point_y[point];
        y_comp = y_comp * y_comp;
        z_comp = rx_z - point_z[point];
        z_comp = z_comp * z_comp;
        dist = dist_tx[point] + ((float) sqrt((x_comp + y_comp) + z_comp));
        index = (int) (((dist / idx_const) + filter_delay) + 0.5);
        image_private[point] += +rx_data[index + offset];
      }

    }

    {
      for (point = 0; point < inner; point++)
      {
        image[point] += image_private[point];
      }

    }
  }
  gettimeofday(&tv, 0);
  uint64_t end = (tv.tv_sec * ((uint64_t) 1000000)) + tv.tv_usec;
  uint64_t elapsed = end - start;
  printf("@@@ Elapsed time (usec): %lld\n", elapsed);
  printf("Processing complete.  Preparing output.\n");
  fflush(stdout);
  char *out_filename;
  out_filename = "beamforming_output.bin";
  output = fopen(out_filename, "wb");
  fwrite(image, sizeof(float), (pts_r * sls_t) * sls_p, output);
  fclose(output);
  printf("Output complete.\n");
  fflush(stdout);
  free(rx_x);
  free(rx_y);
  free(rx_data);
  free(point_x);
  free(point_y);
  free(point_z);
  free(dist_tx);
  free(image);
  return 0;
}

