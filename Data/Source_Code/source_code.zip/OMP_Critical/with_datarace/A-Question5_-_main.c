int main(int argc, char *argv[])
{
  int nthreads = 1;
  if (argc == 2)
  {
    nthreads = argv[1][0] - '0';
  }

  int n = 100000000;
  long double dx = 1 / (((long double) n) + 1);
  long double x = 0;
  #pragma omp parallel for private(x)
  for (int i = 0; i < n; i++)
  {
    x = i * dx;
    long double y = ((exp(x) * cos(x)) * sin(x)) * sqrt((5 * x) + 6.0);
    if (((i % 1000000) == 0) && (i != 0))
    {
      {
      }
    }

  }

  return 0;

  double *cache[6];
  short a;
  short b;
  short c;
  short _padding;
} CacheJob;
size_t _ccsd_t_gen_jobs(CacheJob *jobs, int nocc, int nvir, int a0, int a1, int b0, int b1, double *cache_row_a, double *cache_col_a, double *cache_row_b, double *cache_col_b);
double _ccsd_t_permute_contract(double *z0, double *z1, double *z2, double *z3, double *z4, double *z5, double *w, int n);
void _ccsd_t_get_denorm(double *d3, double *mo_energy, int nocc, int a, int b, int c);
double CCuccsd_t_baa(double *mo_ea, double *mo_eb, double *t1aT, double *t1bT, double *t2aaT, double *t2abT, double *vooo, double *vOoO, double *VoOo, int nocca, int noccb, int nvira, int nvirb, int a0, int a1, int b0, int b1, double *cache_row_a, double *cache_col_a, double *cache_row_b, double *cache_col_b)
{
  int da = a1 - a0;
  int db = b1 - b0;
  CacheJob *jobs = malloc((((sizeof(CacheJob)) * da) * db) * b1);
  size_t njobs = gen_baa_jobs(jobs, nocca, noccb, nvira, nvirb, a0, a1, b0, b1, cache_row_a, cache_col_a, cache_row_b, cache_col_b);
  double *vs_ts[] = {mo_ea, mo_eb, vooo, vOoO, VoOo, t1aT, t1bT, t2aaT, t2abT};
  double e_tot = 0;
  #pragma omp parallel default(none) shared(njobs, nocca, noccb, nvira, nvirb, vs_ts, jobs, e_tot)
  {
    int a;
    int b;
    int c;
    size_t k;
    double *cache1 = malloc(((((sizeof(double)) * noccb) * nocca) * nocca) * 7);
    double e = 0;
    #pragma omp for schedule (dynamic, 32)
    for (k = 0; k < njobs; k++)
    {
      a = jobs[k].a;
      b = jobs[k].b;
      c = jobs[k].c;
      e += contract6_baa(nocca, noccb, nvira, nvirb, a, b, c, vs_ts, jobs[k].cache, cache1);
    }

    free(cache1);
    #pragma omp critical
    e_tot += e;
  }
  return e_tot;
}

