int main()
{
  const int n = 160;
  const int m = 10000;
  double a[n][n];
  double b[n][n];
  double dt;
  double xk;
  double xk2;
  int mts;
  int i;
  int j;
  int k;
  int j_update;
  struct timeval tstart;
  struct timeval tstop;
  omp_set_num_threads(8);
  for (i = 0; i < n; i++)
    for (j = 0; j <= i; j++)
    for (k = 1; k <= m; k++)
    a[i][j] += ((double) ((i + 1) * (j + 1))) / ((double) ((((i + 1) + j) + 1) + k));



  for (i = 0; i < n; i++)
    for (j = i + 1; j < n; j++)
    a[i][j] = a[j][i];


  gettimeofday(&tstart, 0);
  #pragma omp parallel default(none) private(i, j, k, xk, xk2) shared(a, b, j_update)
  {
    {
      j_update = 0;
    }
    #pragma omp for schedule(dynamic)
    for (i = 1; i <= (n - 2); i++)
      for (j = 1; j <= i; j++)
    {
      {
        j_update += 1;
      }
      for (k = 1; k <= m; k++)
      {
        xk = (double) k;
        xk2 = xk * xk;
        b[i][j] += ((((a[i - 1][j] + a[i + 1][j]) + a[i][j + 1]) + a[i][j - 1]) / xk) + ((((a[i - 1][j + 1] + a[i - 1][j - 1]) + a[i + 1][j + 1]) + a[i + 1][j - 1]) / xk2);
      }

    }


  }
  gettimeofday(&tstop, 0);
  dt = ((double) (tstop.tv_sec - tstart.tv_sec)) + (((double) (tstop.tv_usec - tstart.tv_usec)) * 1.e-6);
  printf("b(1,1), b(n-2,n-2) = %6.5e, %6.5e, ", b[1][1], b[n - 2][n - 2]);
  printf("Number of j updates = %d, ", j_update);
  printf("time = %4.3es\n", dt);
  return 0;
}

