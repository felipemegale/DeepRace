double dotp(double *x, double *y)
{
  double global_sum = 0.0;
  #pragma omp parallel
  {
    double sum = 0;
    #pragma omp for
    for (int i = 0; i < 1000000; i++)
      sum += x[i] * y[i];

    global_sum += sum;
  }
  return global_sum;
}

