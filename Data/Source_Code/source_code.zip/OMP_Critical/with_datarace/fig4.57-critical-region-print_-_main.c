int main()
{
  int TID;
  #pragma omp parallel
  {
    #pragma omp single
    printf("Number of threads is %d\n", 1);
  }
  #pragma omp parallel default(none) private(TID)
  {
    TID = 0;
    {
      printf("I am thread %d\n", TID);
    }
  }
  return 0;
}

