int main()
{
  srand(time(0));
  int *num = (int *) malloc(6 * (sizeof(int)));
  int sum = 0;
  int j = 0;
  #pragma omp parallel shared(sum) private(j)
  {
    #pragma omp sections
    {
      #pragma omp section
      {
        #pragma omp parallel for
        for (j = 0; j < 6; j++)
        {
          *(num + j) = rand() % 10;
          printf("num %d-->%d\n", j, *(num + j));
          sum += *(num + j);
        }

      }
      #pragma omp section
      {
        int i = 0;
        omp_set_nested(1);
        #pragma omp parallel num_threads(4) shared(i)
        {
          {
            printf("thread--->%d\n", i);
            i++;
          }
        }
      }
    }
  }
  printf("SUM :: %d\n", sum);
  return 0;
}

