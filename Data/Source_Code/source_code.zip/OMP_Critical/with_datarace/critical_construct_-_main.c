int main()
{
  int start;
  int end;
  int size;
};
struct Node
{
  struct Data *data;
  struct Node *next;
};
struct Q
{
  struct Node *front;
  struct Node *rear;
};
void process_own_Ql1(struct Q *list[])
{
  int out = 0.0;
  int ID = omp_get_thread_num();
  struct Data *tempdat;
  struct Data *tempdatothers;
  #pragma omp critical
  {
    tempdat = deq(list[ID]);
  }
  while (tempdat != 0)
  {
    loop1(tempdat->start, tempdat->end);
    #pragma omp critical
    {
      tempdat = deq(list[ID]);
    }
  }


  int x;
  x = 0;
  #pragma omp parallel shared(x)
  {
    x = x + 1;
  }
  printf("%d\n", x);
}

