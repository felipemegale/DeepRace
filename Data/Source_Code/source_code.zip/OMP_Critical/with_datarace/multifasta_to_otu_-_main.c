int main(int argc, char **argv)
{
  int id = omp_get_thread_num();
  *prvt1 = id;
  *prvt2 = id;
  *prvt3 = id;
  #pragma omp barrier
  if ((((*prvt1) != id) || ((*prvt2) != id)) || ((*prvt3) != id))
  {
    #pragma omp critical
    errors += 1;
  }


  int c;
  char *input_fasta_directory = 0;
  char *sensing_matrix_filename = 0;
  char *sensing_fasta_filename = 0;
  char *output_filename = 0;
  double *sensing_matrix;
  long int width = 0;
  long int sequences = 0;
  int kmer = 6;
  int lambda = 10000;
  int x = 0;
  int y = 0;
  int jobs = 1;
  int verbose = 0;
  DIR * input_directory_dh;
  struct dirent *entry;
  while (1)
  {
    static struct option long_options[] = {{"input-directory", required_argument, 0, 'i'}, {"kmer", required_argument, 0, 'k'}, {"lambda", required_argument, 0, 'l'}, {"jobs", required_argument, 0, 'j'}, {"output", required_argument, 0, 'o'}, {"sensing-fasta", required_argument, 0, 'f'}, {"sensing-matrix", required_argument, 0, 's'}, {"verbose", no_argument, 0, 'v'}, {0, 0, 0, 0}};
    int option_index = 0;
    c = getopt_long(argc, argv, "k:l:f:s:i:o:j:hv", long_options, &option_index);
    if (c == (-1))
      break;

    switch (c)
    {
      case 'k':
        kmer = atoi(optarg);
        break;

      case 'l':
        lambda = atoi(optarg);
        break;

      case 'f':
        sensing_fasta_filename = optarg;
        break;

      case 's':
        sensing_matrix_filename = optarg;
        break;

      case 'j':
        jobs = atoi(optarg);
        break;

      case 'i':
        input_fasta_directory = optarg;
        break;

      case 'o':
        output_filename = optarg;
        break;

      case 'v':
        verbose = 1;
        break;

      case 'h':
        puts("Usage:\n\tmultifasta_to_otu [OPTION...] - create a QIIME OTU table based on Quikr results. \n\nOptions:\n\n-i, --input-directory\n\tthe directory containing the samples' fasta files of reads (note each file should correspond to a separate sample)\n\n-f, --sensing-fasta\n\tlocation of the fasta file database used to create the sensing matrix (fasta format)\n\n-s, --sensing-matrix\n\t location of the sensing matrix. (sensing from quikr_train)\n\n-k, --kmer\n\tspecify what size of kmer to use. (default value is 6)\n\n-l, --lambda\n\tlambda value to use. (default value is 10000)\n\n-j, --jobs\n\t specifies how many jobs to run at once. (default value is the number of CPUs)\n\n-o, --output\n\tthe OTU table, with OTU_FRACTION_PRESENT for each sample which is compatible with QIIME's convert_biom.py (or a sequence table if not OTU's)\n\n-v, --verbose\n\tverbose mode.");
        exit(0);
        break;

      default:
        break;

    }

  }

  if (sensing_matrix_filename == 0)
  {
    fprintf(stderr, "Error: sensing matrix filename (-s) must be specified\n\n");
    fprintf(stderr, "%s\n", "Usage:\n\tmultifasta_to_otu [OPTION...] - create a QIIME OTU table based on Quikr results. \n\nOptions:\n\n-i, --input-directory\n\tthe directory containing the samples' fasta files of reads (note each file should correspond to a separate sample)\n\n-f, --sensing-fasta\n\tlocation of the fasta file database used to create the sensing matrix (fasta format)\n\n-s, --sensing-matrix\n\t location of the sensing matrix. (sensing from quikr_train)\n\n-k, --kmer\n\tspecify what size of kmer to use. (default value is 6)\n\n-l, --lambda\n\tlambda value to use. (default value is 10000)\n\n-j, --jobs\n\t specifies how many jobs to run at once. (default value is the number of CPUs)\n\n-o, --output\n\tthe OTU table, with OTU_FRACTION_PRESENT for each sample which is compatible with QIIME's convert_biom.py (or a sequence table if not OTU's)\n\n-v, --verbose\n\tverbose mode.");
    exit(1);
  }

  if (sensing_fasta_filename == 0)
  {
    fprintf(stderr, "Error: sensing fasta filename (-f) must be specified\n\n");
    fprintf(stderr, "%s\n", "Usage:\n\tmultifasta_to_otu [OPTION...] - create a QIIME OTU table based on Quikr results. \n\nOptions:\n\n-i, --input-directory\n\tthe directory containing the samples' fasta files of reads (note each file should correspond to a separate sample)\n\n-f, --sensing-fasta\n\tlocation of the fasta file database used to create the sensing matrix (fasta format)\n\n-s, --sensing-matrix\n\t location of the sensing matrix. (sensing from quikr_train)\n\n-k, --kmer\n\tspecify what size of kmer to use. (default value is 6)\n\n-l, --lambda\n\tlambda value to use. (default value is 10000)\n\n-j, --jobs\n\t specifies how many jobs to run at once. (default value is the number of CPUs)\n\n-o, --output\n\tthe OTU table, with OTU_FRACTION_PRESENT for each sample which is compatible with QIIME's convert_biom.py (or a sequence table if not OTU's)\n\n-v, --verbose\n\tverbose mode.");
    exit(1);
  }

  if (output_filename == 0)
  {
    fprintf(stderr, "Error: Output Filename (-o) must be specified\n\n");
    fprintf(stderr, "%s\n", "Usage:\n\tmultifasta_to_otu [OPTION...] - create a QIIME OTU table based on Quikr results. \n\nOptions:\n\n-i, --input-directory\n\tthe directory containing the samples' fasta files of reads (note each file should correspond to a separate sample)\n\n-f, --sensing-fasta\n\tlocation of the fasta file database used to create the sensing matrix (fasta format)\n\n-s, --sensing-matrix\n\t location of the sensing matrix. (sensing from quikr_train)\n\n-k, --kmer\n\tspecify what size of kmer to use. (default value is 6)\n\n-l, --lambda\n\tlambda value to use. (default value is 10000)\n\n-j, --jobs\n\t specifies how many jobs to run at once. (default value is the number of CPUs)\n\n-o, --output\n\tthe OTU table, with OTU_FRACTION_PRESENT for each sample which is compatible with QIIME's convert_biom.py (or a sequence table if not OTU's)\n\n-v, --verbose\n\tverbose mode.");
    exit(1);
  }

  if (input_fasta_directory == 0)
  {
    fprintf(stderr, "Error: input fasta directory (-i) must be specified\n\n");
    fprintf(stderr, "%s\n", "Usage:\n\tmultifasta_to_otu [OPTION...] - create a QIIME OTU table based on Quikr results. \n\nOptions:\n\n-i, --input-directory\n\tthe directory containing the samples' fasta files of reads (note each file should correspond to a separate sample)\n\n-f, --sensing-fasta\n\tlocation of the fasta file database used to create the sensing matrix (fasta format)\n\n-s, --sensing-matrix\n\t location of the sensing matrix. (sensing from quikr_train)\n\n-k, --kmer\n\tspecify what size of kmer to use. (default value is 6)\n\n-l, --lambda\n\tlambda value to use. (default value is 10000)\n\n-j, --jobs\n\t specifies how many jobs to run at once. (default value is the number of CPUs)\n\n-o, --output\n\tthe OTU table, with OTU_FRACTION_PRESENT for each sample which is compatible with QIIME's convert_biom.py (or a sequence table if not OTU's)\n\n-v, --verbose\n\tverbose mode.");
    exit(1);
  }

  if (verbose)
  {
    printf("kmer: %d\n", kmer);
    printf("lambda: %d\n", lambda);
    printf("input directory: %s\n", input_fasta_directory);
    printf("sensing database: %s\n", sensing_matrix_filename);
    printf("sensing database fasta: %s\n", sensing_fasta_filename);
    printf("output: %s\n", output_filename);
    printf("number of jobs to run at once: %d\n", jobs);
  }

  if (access(sensing_matrix_filename, F_OK) == (-1))
  {
    fprintf(stderr, "Error: could not find %s\n", sensing_matrix_filename);
    exit(1);
  }

  if (access(sensing_fasta_filename, F_OK) == (-1))
  {
    fprintf(stderr, "Error: could not find %s\n", sensing_fasta_filename);
    exit(1);
  }

  input_directory_dh = opendir(input_fasta_directory);
  if (input_fasta_directory == 0)
  {
    fprintf(stderr, "could not open %s\n", input_fasta_directory);
    exit(1);
  }

  int dir_count = -2;
  while (entry = readdir(input_directory_dh))
    dir_count++;

  rewinddir(input_directory_dh);
  if (dir_count == 0)
  {
    fprintf(stderr, "%s is empty\n", input_fasta_directory);
    exit(1);
  }

  width = pow(4, kmer) + 1;
  sequences = count_sequences(sensing_fasta_filename);
  if (sequences == 0)
  {
    fprintf(stderr, "Error: %s contains 0 fasta sequences\n", sensing_fasta_filename);
  }

  if (verbose)
  {
    printf("directory count: %d\n", dir_count);
    printf("width: %ld\nsequences %ld\n", width, sequences);
  }

  sensing_matrix = load_sensing_matrix(sensing_matrix_filename, sequences, width);
  for (x = 0; x < sequences; x++)
  {
    for (y = 0; y < width; y++)
    {
      sensing_matrix[(width * x) + y] = sensing_matrix[(width * x) + y] * lambda;
    }

  }

  for (x = 0; x < sequences; x++)
  {
    sensing_matrix[(width * x) + 0] = 1.0;
  }

  double *solutions = malloc((dir_count * sequences) * (sizeof(double)));
  if (solutions == 0)
  {
    fprintf(stderr, "Could not allocate enough memory for solutions vector\n");
    exit(1);
  }

  char **filenames = malloc(dir_count * (sizeof(char *)));
  if (filenames == 0)
  {
    fprintf(stderr, "Could not allocate enough memory\n");
    exit(1);
  }

  int *file_sequence_count = malloc(dir_count * (sizeof(int)));
  if (file_sequence_count == 0)
  {
    fprintf(stderr, "Could not allocate enough memory\n");
    exit(1);
  }

  struct dirent result;
  omp_set_num_threads(jobs);
  int done = 0;
  printf("Beginning to process samples\n");
  #pragma omp parallel for shared(solutions, sequences, width, result, done)
  for (int i = 0; i < dir_count; i++)
  {
    int z = 0;
    struct dirent *directory_entry;
    char *filename = malloc(256 * (sizeof(char)));
    char *base_filename = malloc(256 * (sizeof(char)));
    if ((filename == 0) || (base_filename == 0))
    {
      fprintf(stderr, "Could not allocate enough memory\n");
      exit(1);
    }

    readdir_r(input_directory_dh, &result, &directory_entry);
    if ((strcmp(directory_entry->d_name, "..") == 0) || (strcmp(directory_entry->d_name, ".") == 0))
    {
      i--;
      continue;
    }

    strcpy(base_filename, directory_entry->d_name);
    filenames[i] = base_filename;
    sprintf(filename, "%s/%s", input_fasta_directory, directory_entry->d_name);
    file_sequence_count[i] = count_sequences(filename);
    double *count_matrix = load_count_matrix(filename, width, kmer);
    normalize_matrix(count_matrix, 1, width);
    for (z = 0; z < width; z++)
      count_matrix[z] = count_matrix[z] * lambda;

    double *sensing_matrix_copy = malloc(((sizeof(double)) * sequences) * width);
    if (sensing_matrix_copy == 0)
    {
      fprintf(stderr, "Could not allocate enough memory\n");
      exit(1);
    }

    memcpy(sensing_matrix_copy, sensing_matrix, (sequences * width) * (sizeof(double)));
    double *solution = nnls(sensing_matrix_copy, count_matrix, sequences, width);
    normalize_matrix(solution, 1, sequences);
    for (z = 0; z < sequences; z++)
    {
      solutions[(sequences * i) + z] = solution[z];
    }

    done++;
    printf("%d/%d samples processed\n", done, dir_count);
    free(solution);
    free(count_matrix);
    free(filename);
    free(sensing_matrix_copy);
  }

  char **headers = load_headers(sensing_fasta_filename, sequences);
  FILE *output_fh = fopen(output_filename, "w");
  if (output_fh == 0)
  {
    fprintf(stderr, "Could not open %s for writing\n", output_filename);
    exit(1);
  }

  fprintf(output_fh, "# QIIME vQuikr OTU table\n");
  fprintf(output_fh, "#OTU_ID\t");
  for (x = 0; x < (dir_count - 1); x++)
  {
    fprintf(output_fh, "%s\t", filenames[x]);
  }

  fprintf(output_fh, "%s\n", filenames[dir_count - 1]);
  for (y = 0; y < sequences; y++)
  {
    for (x = 0; x < dir_count; x++)
    {
      solutions[(sequences * x) + y] = round(solutions[(sequences * x) + y] * file_sequence_count[x]);
    }

  }

  for (y = 0; y < sequences; y++)
  {
    double column_sum = 0.;
    for (x = 0; x < dir_count; x++)
    {
      column_sum += solutions[(sequences * x) + y];
    }

    if (column_sum != 0)
    {
      fprintf(output_fh, "%s\t", headers[y]);
      for (x = 0; x < (dir_count - 1); x++)
      {
        fprintf(output_fh, "%d\t", (int) solutions[(sequences * x) + y]);
      }

      fprintf(output_fh, "%d\n", (int) solutions[(sequences * (dir_count - 1)) + y]);
    }

  }

  fclose(output_fh);
  return 0;
}

