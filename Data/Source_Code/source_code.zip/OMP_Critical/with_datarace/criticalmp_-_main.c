double A[1000000L];
int main()
{
  int shrd1;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  shrd0 = 0;
  shrd1 = 0;
  #pragma omp parallel
  {
    #pragma omp critical
    {
      shrd0 += 1;
      shrd1 += 1;
    }
  }
  if ((shrd0 != thds) || (shrd1 != thds))
  {
    errors++;
  }

  shrd0 = 0;
  shrd1 = 0;
  #pragma omp parallel
  func(&shrd1);
  if ((shrd0 != thds) || (shrd1 != thds))
  {
    errors++;
  }

  if (errors == 0)
  {
    printf("attribute 001 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("attribute 001 : FAILED\n");
    return 1;
  }


  int i;
  volatile double sum;
  volatile double globsum;
  for (i = 0; i < 1000000L; i++)
  {
    A[i] = (double) i;
  }

  globsum = 0.0;
  omp_set_num_threads(100);
  #pragma omp parallel private(sum)
  {
    sum = 0.0;
    #pragma omp for
    for (i = 0; i < 1000000L; i++)
    {
      sum += A[i];
    }

    globsum += sum;
  }
  printf("Global sum is: %f\n", globsum);
  return 0;
}

