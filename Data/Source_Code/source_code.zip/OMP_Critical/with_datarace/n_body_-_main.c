{
  double x;
  double y;
  double z;
} triple;
{
  double m;
  position pos;
  velocity v;
} body;
body B[100];
force F[100];
force pF[100];
#pragma omp threadprivate (pF);
int main()
{
  for (int i = 0; i < 100; i++)
  {
    B[i].m = (i < 1000) ? (1) : (0);
    B[i].pos = triple_rand();
    B[i].v = triple_zero();
  }

  #pragma omp parallel
  for (int i = 0; i < 100; i++)
  {
    #pragma omp for
    for (int j = 0; j < 100; j++)
    {
      F[j] = triple_zero();
    }

    for (int j = 0; j < 100; j++)
    {
      pF[j] = triple_zero();
    }

    #pragma omp for
    for (int j = 0; j < ((100 < 1000) ? (100) : (1000)); j++)
    {
      for (int k = 0; k < 100; k++)
      {
        if (j != k)
        {
          triple dist = (triple){B[k].pos.x - B[j].pos.x, B[k].pos.y - B[j].pos.y, B[k].pos.z - B[j].pos.z};
          double r = sqrt(((dist.x * dist.x) + (dist.y * dist.y)) + (dist.z * dist.z));
          double f = (B[j].m * B[k].m) / (r * r);
          double s = f / r;
          force cur = (triple){dist.x * s, dist.y * s, dist.z * s};
          pF[j] = (triple){pF[j].x + cur.x, pF[j].y + cur.y, pF[j].z + cur.z};
        }

      }

    }

    for (int j = 0; j < 100; j++)
    {
      F[j] = (triple){pF[j].x + F[j].x, pF[j].y + F[j].y, pF[j].z + F[j].z};
    }

    #pragma omp for
    for (int j = 0; j < ((100 < 1000) ? (100) : (1000)); j++)
    {
      B[j].v = (triple){B[j].v.x + ((triple){F[j].x / B[j].m, F[j].y / B[j].m, F[j].z / B[j].m}).x, B[j].v.y + ((triple){F[j].x / B[j].m, F[j].y / B[j].m, F[j].z / B[j].m}).y, B[j].v.z + ((triple){F[j].x / B[j].m, F[j].y / B[j].m, F[j].z / B[j].m}).z};
      B[j].pos = (triple){B[j].pos.x + B[j].v.x, B[j].pos.y + B[j].v.y, B[j].pos.z + B[j].v.z};
    }

  }

  impulse sum = triple_zero();
  for (int i = 0; i < 100; i++)
  {
    sum = (triple){sum.x + ((triple){B[i].v.x * B[i].m, B[i].v.y * B[i].m, B[i].v.z * B[i].m}).x, sum.y + ((triple){B[i].v.x * B[i].m, B[i].v.y * B[i].m, B[i].v.z * B[i].m}).y, sum.z + ((triple){B[i].v.x * B[i].m, B[i].v.y * B[i].m, B[i].v.z * B[i].m}).z};
  }

  int success = (((((sum.x - triple_zero().x) < 0) ? (-(sum.x - triple_zero().x)) : (sum.x - triple_zero().x)) < 0.0001) && ((((sum.y - triple_zero().y) < 0) ? (-(sum.y - triple_zero().y)) : (sum.y - triple_zero().y)) < 0.0001)) && ((((sum.z - triple_zero().z) < 0) ? (-(sum.z - triple_zero().z)) : (sum.z - triple_zero().z)) < 0.0001);
  printf("Verification: %s\n", (success) ? ("OK") : ("ERR"));
  if (!success)
  {
    triple_print(sum);
    printf(" should be (0,0,0)\n");
    return 1;
  }

  return 0;
}

