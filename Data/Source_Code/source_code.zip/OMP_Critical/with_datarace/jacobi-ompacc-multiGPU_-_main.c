int mits = 5000;
double tol = 0.0000000001;
double relax = 1.0;
double alpha = 0.0543;
double error_ref = 9.213041E-04;
double resid_ref = 2.355794E-08;
int main(int argc, char *argv[])
{
  int m;
  int n;
  int idev;
  int num_threads;
  double *u;
  double *uold;
  double *f;
  double dx;
  double dy;
  double seq_elapsed;
  double omp_for_elapsed;
  double acc_elapsed;
  int halosize = 1;
  m = 512;
  n = 512;
  u = (double *) malloc((m * n) * (sizeof(double)));
  uold = (double *) malloc((m * n) * (sizeof(double)));
  f = (double *) malloc((m * n) * (sizeof(double)));
  initialize(u, uold, f, &dx, &dy, m, n);
  omp_for_elapsed = omp_get_wtime();
  jacobi_omp(u, uold, f, dx, dy, m, n);
  omp_for_elapsed = omp_get_wtime() - omp_for_elapsed;
  initialize(u, uold, f, &dx, &dy, m, n);
  int GPU_N = 0;
  cudaGetDeviceCount(&GPU_N);
  if (GPU_N > 4)
  {
    GPU_N = 4;
  }

  printf("CUDA-capable device count: %i\n", GPU_N);
  omp_set_num_threads(GPU_N);
  #pragma omp parallel
  {
    #pragma omp master
    {
      num_threads = omp_get_num_threads();
    }
  }
  double ompacc_time = omp_get_wtime();
  acc_elapsed = omp_get_wtime();
  double *tmp;
  double *error;
  double error_sum;
  error = (double *) malloc((sizeof(double)) * GPU_N);
  #pragma omp parallel shared (GPU_N, u, uold, f, m, n, error,error_sum) private(idev)
  {
    int tid = omp_get_thread_num();
    cudaSetDevice(tid);
    int size = n / GPU_N;
    int offset = size * tid;
    if (tid < (n % GPU_N))
    {
      size++;
    }

    if (tid >= (n % GPU_N))
      offset += n % GPU_N;
    else
      offset += tid;

    if (tid != 0)
      offset = offset - halosize;

    size = size + halosize;
    if ((tid != (GPU_N - 1)) && (tid != 0))
      size = size + halosize;

    printf("thread %d working on GPU devices %d with size %d copying data from y_ompacc with offset %d\n", tid, tid, size, offset);
    int i;
    int j;
    int k;
    k = 1;
    error_sum = 10.0 * tol;
    while ((k <= mits) && (error_sum > tol))
    {
      #pragma omp barrier
      #pragma omp master
      {
        tmp = u;
        u = uold;
        uold = tmp;
        error_sum = 0.0;
      }
      error[tid] = 0.0;
      #pragma omp barrier
      jacobi_GPU(u, uold, f, dx, dy, offset, m, size, &error[tid]);
      k = k + 1;
      #pragma omp master
      {
        if ((k % 500) == 0)
          printf("GPU_run: finished %d iteration.\n", k);

      }
      {
        error_sum += error[tid];
      }
      #pragma omp barrier
      #pragma omp master
      {
        error_sum = sqrt(error_sum) / (n * m);
      }
    }

    #pragma omp master
    {
      printf("Total Number of Iterations:%d\n", k);
      printf("Residual:%E\n", error_sum);
      printf("Residual_ref :%E\n", resid_ref);
      printf("Diff ref=%E\n", fabs(error_sum - resid_ref));
      assert((fabs(error_sum - resid_ref) / resid_ref) < 1E-5);
    }
  }
  acc_elapsed = omp_get_wtime() - acc_elapsed;
  free(error);
  printf("=======================================================================\n");
  printf("\t\tmatmul(%dx%d) example on %d threads(cores)\n", n, n, num_threads);
  printf("-----------------------------------------------------------------------\n");
  printf("Performance:  Runtime (s)\t MFLOPS\t\t\t Error\n");
  printf("-----------------------------------------------------------------------\n");
  printf("OMP For         :  %4f \t\t %4f\t\t\n", omp_for_elapsed, (((2.0 * n) * n) * n) / (1.0e6 * omp_for_elapsed));
  printf("ACC For         :  %4f \t\t %4f\t\t\n", acc_elapsed, (((2.0 * n) * n) * n) / (1.0e6 * acc_elapsed));
  free(u);
  free(uold);
  free(f);
  return 0;
}

