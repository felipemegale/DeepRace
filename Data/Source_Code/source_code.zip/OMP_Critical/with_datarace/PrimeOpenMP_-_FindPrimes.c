static int gProgress = 0;
static int gPrimesFound = 0;
long globalPrimes[1000000];
int CLstart;
int CLend;
void FindPrimes(int start, int end)
{
  int range = (end - start) + 1;
  int i;
  #pragma omp parallel for
  for (i = start; i <= end; i += 2)
  {
    if (TestForPrime(i))
    {
      globalPrimes[gPrimesFound++] = i;
    }

    ShowProgress(i, range);
  }

}

