static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt;
void func2(int magicno)
{
  static int err;
  int id = omp_get_thread_num();
  if (prvt != magicno)
  {
    errors += 1;
  }

  #pragma omp barrier
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    errors++;
  }


  int i;
  int j;
  int b;
  int ii;
  int jj;
  int bb;
  int iii;
  int jjj;
  int bbb;
  int bbbb;
  int n_comp_all;
  int n_comp_last;
  int iii_count;
  int aux;
  int best_bee;
  int n_proc;
  int it_over;
  int R;
  int pass_count;
  int loy[MAX_BEES_NO];
  int sum;
  int av_sum;
  char f_name[200];
  char pom_name[100];
  char stat_name[200];
  char broj[5];
  int stop_ind;
  int num_iter;
  double run_time;
  int n_it;
  int n_nonimp_it;
  int terminate;
  int n_tasks[MAX_BEES_NO];
  int roulete[MAX_BEES_NO];
  int Iroulete[MAX_BEES_NO][MAX_TASK_NO];
  int first[MAX_BEES_NO];
  int max_y;
  int min_y;
  int min_y_p;
  int value;
  int bingo;
  double dvalue;
  double dbingo;
  double maxV_norm;
  double sum_V_loy;
  double V_norm[MAX_BEES_NO];
  double p_loy[MAX_BEES_NO];
  double Droulete[MAX_BEES_NO];
  double V[MAX_BEES_NO][MAX_PROC_NO];
  double sum_V[MAX_BEES_NO];
  double p_proc[MAX_BEES_NO][MAX_PROC_NO];
  int ID;
  int total_threads;
  time_t timer;
  char *timeline;
  clock_t t1;
  clock_t t2;
  double t;
  double min_t;
  double t_op;
  struct rusage r;
  time_t ctime;
  time(&ctime);
  srand(ctime);
  FILE *fin = fopen("input.dat", "r");
  strcpy(f_name, "");
  fscanf(fin, "%s %*s\n", pom_name);
  strcat(f_name, pom_name);
  strcat(f_name, ".dat");
  fscanf(fin, "%d %*s\n", &stop_ind);
  if (stop_ind < 2)
    fscanf(fin, "%d %*s \n", &num_iter);
  else
    fscanf(fin, "%lf %*s \n", &run_time);

  fscanf(fin, "%d %*s\n", &bees);
  fscanf(fin, "%d %*s\n", &NC);
  fclose(fin);
  strcpy(stat_name, pom_name);
  strcat(stat_name, "_bco_greedy1_B");
  sprintf(broj, "%d", bees);
  strcat(stat_name, broj);
  strcat(stat_name, "NC");
  sprintf(broj, "%d", NC);
  strcat(stat_name, broj);
  strcat(stat_name, "it");
  if (stop_ind == 2)
    num_iter = 500;

  sprintf(broj, "%d", num_iter);
  strcat(stat_name, broj);
  strcat(stat_name, ".dat");
  FILE *name = fopen(f_name, "r");
  fscanf(name, "%*s %*s %*s\n %*s %*s %*s %*s %*s %*s\n");
  fscanf(name, "%*s %*s %*s %d;\n", &n);
  fscanf(name, "%*s %*s %*s %d;\n", &p);
  if ((L = (int *) malloc(n * (sizeof(int)))) == 0)
    exit(MEM_ERROR);

  fscanf(name, "%*s %*s %*s %*s\n");
  for (i = 0; i < n; i++)
    fscanf(name, "%*d %d;\n", &L[i]);

  fclose(name);
  if ((aux = bco_init()) == MEM_ERROR)
    exit(MEM_ERROR);

  sum = 0;
  for (i = 0; i < n; i++)
    sum += L[i];

  av_sum = ((int) (((double) sum) / ((double) p))) + 1;
  y_gmin = sum;
  n_comp_all = n / NC;
  if ((NC * n_comp_all) < n)
    n_comp_all += 1;

  iii_count = n_comp_all;
  n_comp_last = n - (n_comp_all * (NC - 1));
  n_it = (n_nonimp_it = 0);
  terminate = 0;
  t1 = clock();
  #pragma omp parallel default(shared) private(b,bb,bbb,bbbb,i,j,ID,iii,aux,bingo,dbingo,value,ii,jj,min_y_p,t_op)
  {
    ID = omp_get_thread_num();
    t_op = omp_get_wtime();
    while (!terminate)
    {
      #pragma omp barrier
      pass_count = 0;
      n_it++;
      #pragma omp for
      for (b = 0; b < bees; b++)
      {
        roulete[b] = sum;
        n_tasks[b] = n;
        first[b] = 1;
        for (i = 0; i < n; i++)
          Iroulete[b][i] = i;

        for (j = 0; j < p; j++)
          y[b][j] = 0;

        for (j = 0; j < p; j++)
          o[b][j] = 0;

        for (j = 0; j < MAX_PROC_NO; j++)
          for (i = 0; i < MAX_TASK_NO; i++)
          s[b][j][i] = -1;


      }

      i = 0;
      it_over = 0;
      iii_count = n_comp_all;
      #pragma omp barrier
      do
      {
        if ((i + n_comp_all) <= n)
          i += n_comp_all;
        else
        {
          i += n_comp_last;
          iii_count = n_comp_last;
        }

        pass_count++;
        #pragma omp barrier
        #pragma omp for
        for (b = 0; b < bees; b++)
        {
          for (iii = 0; iii < iii_count; iii++)
          {
            aux = rand();
            bingo = normal(aux, 1, roulete[b]);
            ii = 0;
            value = L[Iroulete[b][0]];
            while ((ii < n_tasks[b]) && (bingo > value))
              value += L[Iroulete[b][++ii]];

            if (first[b])
            {
              aux = rand();
              jj = normal(aux, 0, p - 1);
              first[b] = 0;
            }
            else
            {
              {
                min_y_p = sum;
                for (j = 0; j < p; j++)
                  if (((av_sum - (y[b][j] + L[Iroulete[b][ii]])) > 0) && ((av_sum - (y[b][j] + L[Iroulete[b][ii]])) < min_y_p))
                {
                  min_y_p = av_sum - (y[b][j] + L[Iroulete[b][ii]]);
                  jj = j;
                }


              }
            }

            s[b][jj][o[b][jj]++] = Iroulete[b][ii];
            y[b][jj] += L[Iroulete[b][ii]];
            roulete[b] -= L[Iroulete[b][ii]];
            Iroulete[b][ii] = Iroulete[b][--n_tasks[b]];
          }

        }

        #pragma omp for
        for (b = 0; b < bees; b++)
          y_max[b] = 0;

        #pragma omp for
        for (b = 0; b < bees; b++)
        {
          max_y = 0;
          min_y = sum;
          for (j = 0; j < p; j++)
            if (y_max[b] < y[b][j])
            y_max[b] = y[b][j];


        }

        #pragma omp master
        {
          for (b = 0; b < bees; b++)
          {
            if (max_y < y_max[b])
              max_y = y_max[b];

            if (min_y > y_max[b])
            {
              best_bee = b;
              min_y = y_max[b];
            }

          }

        }
        #pragma omp barrier
        if (i < (n * NC))
        {
          if (max_y == min_y)
          {
            #pragma omp for
            for (b = 0; b < bees; b++)
              loy[b] = -1;

          }
          else
          {
            dvalue = (double) (max_y - min_y);
            maxV_norm = (double) 0.0;
            #pragma omp barrier
            #pragma omp master
            {
              for (b = 0; b < bees; b++)
              {
                loy[b] = 0;
                V_norm[b] = ((double) (max_y - y_max[b])) / dvalue;
                {
                  if (maxV_norm < V_norm[b])
                    maxV_norm = V_norm[b];

                }
              }

            }
            sum_V_loy = (double) 0.0;
            R = 0;
            #pragma omp barrier
            #pragma omp for
            for (b = 0; b < bees; b++)
            {
              if (y_max[b] > y_gmin)
                p_loy[b] = (double) 0.0;
              else
                p_loy[b] = exp(-(((double) (maxV_norm - V_norm[b])) / ((double) pass_count)));

              aux = rand();
              dbingo = ((double) aux) / ((double) 32767);
              if (dbingo < p_loy[b])
              {
                #pragma omp critical
                {
                  R++;
                  sum_V_loy += V_norm[b];
                }
                loy[b] = -1;
              }

            }

            if (R > 0)
            {
              #pragma omp master
              {
                bb = 0;
                for (b = 0; b < bees; b++)
                  if (loy[b] == (-1))
                {
                  Droulete[bb++] = ((double) V_norm[b]) / ((double) sum_V_loy);
                }


              }
              #pragma omp barrier
              for (b = 0; b < bees; b++)
                if (!loy[b])
              {
                #pragma omp master
                {
                  aux = rand();
                  dbingo = ((double) aux) / ((double) 32767);
                  bb = 0;
                  dvalue = Droulete[0];
                  while ((bb < R) && (dbingo > dvalue))
                    dvalue += Droulete[++bb];

                  bbb = -1;
                  bbbb = -1;
                  while ((bbbb < bb) && (bbb < bees))
                    if (loy[++bbb] == (-1))
                    bbbb++;


                  for (j = 0; j < p; j++)
                  {
                    for (ii = 0; ii < o[bbb][j]; ii++)
                      s[b][j][ii] = s[bbb][j][ii];

                    if (o[b][j] > o[bbb][j])
                      for (ii = o[bbb][j]; ii < o[b][j]; ii++)
                      s[b][j][ii] = -1;


                    o[b][j] = o[bbb][j];
                    y[b][j] = y[bbb][j];
                  }

                  y_max[b] = y_max[bbb];
                  n_tasks[b] = n_tasks[bbb];
                  roulete[b] = roulete[bbb];
                  for (iii = 0; iii < n; iii++)
                    Iroulete[b][iii] = Iroulete[bbb][iii];

                }
              }


            }
            else
              it_over = 1;

          }

        }

      }
      while ((i < n) && (!it_over));
      #pragma omp barrier
      #pragma omp master
      {
        if (y_max[best_bee] < y_gmin)
        {
          y_gmin = y_max[best_bee];
          av_sum = y_gmin;
          n_nonimp_it = 0;
          for (j = 0; j < p; j++)
          {
            for (i = 0; i < o[best_bee][j]; i++)
              sgmin[j][i] = s[best_bee][j][i];

            ogmin[j] = o[best_bee][j];
            ygmin[j] = y[best_bee][j];
          }

          min_t = omp_get_wtime() - t_op;
        }
        else
          n_nonimp_it++;

        switch (stop_ind)
        {
          case 0:
            if (n_it >= num_iter)
            terminate = 1;

            break;

          case 1:
            if (n_nonimp_it >= num_iter)
            terminate = 1;

            break;

          case 2:
            t2 = clock();
            t = ((double) (t2 - t1)) / CLOCKS_PER_SEC;
            if (t > run_time)
            terminate = 1;

            break;

        }

      }
      #pragma omp barrier
    }

    total_threads = omp_get_num_threads();
    t_op = omp_get_wtime() - t_op;
    printf("\n: OpenMP time_th(%d) - %lf", ID, t_op);
  }
  printf("\nNumber of threads: %d \n", total_threads);
  printf("Bees = %d \n", bees);
  printf("NC = %d \n", NC);
  printf("------------------------------------------------------------------ \n");
  printf("Pronadjena minimalna duzina raspodele je: %d\n", y_gmin);
  printf("matrica raspodele zadatka je:\n");
  for (j = 0; j < p; j++)
  {
    for (i = 0; i < ogmin[j]; i++)
      printf("%d  ", sgmin[j][i]);

    printf("\n");
  }

  t2 = clock();
  t = ((double) (t2 - t1)) / CLOCKS_PER_SEC;
  printf("BCO radio %lf sekundi i izvrsio %d itercija.\n", t, n_it);
  printf("Vreme do pronalazenja minimalne raspodele: %lf\n", min_t);
  printf("------------------------------------------------------------------ \n");
  printf("------------------------------------------------------------------ \n");
  FILE *stat = fopen(stat_name, "a");
  fprintf(stat, "%d    %lf\n", y_gmin, min_t);
  fclose(stat);
  exit(OK);
}

