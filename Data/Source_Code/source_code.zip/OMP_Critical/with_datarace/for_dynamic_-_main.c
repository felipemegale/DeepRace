int A[20];
int main()
{
  int nthreads;
  #pragma omp parallel
  #pragma omp master
  nthreads = omp_get_num_threads();
  printf("Number of threads = %d\n", nthreads);
  int gi = 0;
  #pragma omp parallel
  {
    int i;
    while (1)
    {
      {
        i = gi;
        gi++;
      }
      if (i >= 20)
        break;

      A[i] = work(i);
    }

  }
  return 0;
}

