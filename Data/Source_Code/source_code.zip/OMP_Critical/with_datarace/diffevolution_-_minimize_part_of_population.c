extern const struct training_set ts;
extern const struct settings s;
extern const float ionenergies[];
extern const float affinities[];
int minimize_part_of_population(struct subset *ss, int *good_indices)
{
  assert(ss != 0);
  assert(good_indices != 0);
  int quite_good = 0;
  int i = 0;
  #pragma omp parallel for num_threads(s.om_threads) shared(ss, quite_good, good_indices) private(i)
  for (i = 0; i < ss->kappa_data_count; i++)
  {
    if ((ss->data[i].full_stats.R2 > 0.2) && (ss->data[i].full_stats.R > 0))
    {
      {
        good_indices[quite_good] = i;
        quite_good++;
      }
      struct kappa_data *m = (struct kappa_data *) malloc(sizeof(struct kappa_data));
      kd_init(m);
      m->parent_subset = ss;
      kd_copy_parameters(&ss->data[i], m);
      minimize_locally(m, 1000);
      kd_copy_parameters(m, &ss->data[i]);
      kd_destroy(m);
      free(m);
    }

  }

  if (s.verbosity >= VERBOSE_KAPPA)
  {
    printf("Out of %d in population, we minimized %d\n", ss->kappa_data_count, quite_good);
  }

  return quite_good;

  int threads;
  int i;
  int lasttid;
  int *tids;
  int *tids2;
  int notout;
  int maxiter;
  int chunk_size;
  int counter = 0;
  int tmp_count = 1;
  int lastthreadsstarttid = -1;
  int result = 1;
  chunk_size = 7;
  tids = (int *) malloc((sizeof(int)) * (1000 + 1));
  notout = 1;
  maxiter = 0;
  #pragma omp parallel shared(tids,counter)
  {
    #pragma omp single
    {
      threads = omp_get_num_threads();
    }
  }
  if (threads < 2)
  {
    omp_set_num_threads(2);
    threads = 2;
  }

  fprintf(stderr, "Using an internal count of %d\nUsing a specified chunksize of %d\n", 1000, chunk_size);
  tids[1000] = -1;
  #pragma omp parallel shared(tids)
  {
    double count;
    int tid;
    int j;
    tid = omp_get_thread_num();
    #pragma omp for nowait schedule(static,chunk_size)
    for (j = 0; j < 1000; ++j)
    {
      count = 0.;
      #pragma omp flush(maxiter)
      if (j > maxiter)
      {
        #pragma omp critical
        {
          maxiter = j;
        }
      }

      while ((notout && (count < 0.01)) && (maxiter == j))
      {
        #pragma omp flush(maxiter,notout)
        my_sleep(SLEEPTIME);
        count += SLEEPTIME;
        printf(".");
      }

      if (count > 0.)
        printf(" waited %lf s\n", count);

      tids[j] = tid;
      printf("%d finished by %d\n", j, tid);
    }

    notout = 0;
    #pragma omp flush(maxiter,notout)
  }
  lasttid = tids[0];
  tmp_count = 0;
  for (i = 0; i < (1000 + 1); ++i)
  {
    if (tids[i] == lasttid)
    {
      tmp_count++;
      fprintf(stderr, "%d: %d \n", i, tids[i]);
      continue;
    }

    if ((tids[i] == ((lasttid + 1) % threads)) || (tids[i] == (-1)))
    {
      if (tmp_count == chunk_size)
      {
        tmp_count = 1;
        lasttid = tids[i];
        fprintf(stderr, "OK\n");
      }
      else
      {
        if (tids[i] == (-1))
        {
          if (i == 1000)
          {
            fprintf(stderr, "Last thread had chunk size %d\n", tmp_count);
            break;
          }
          else
          {
            fprintf(stderr, "ERROR: Last thread (thread with number -1) was found before the end.\n");
            result = 0;
          }

        }
        else
        {
          fprintf(stderr, "ERROR: chunk size was %d. (assigned was %d)\n", tmp_count, chunk_size);
          result = 0;
        }

      }

    }
    else
    {
      fprintf(stderr, "ERROR: Found thread with number %d (should be inbetween 0 and %d).", tids[i], threads - 1);
      result = 0;
    }

    fprintf(stderr, "%d: %d \n", i, tids[i]);
  }

  free(tids);
  tids = (int *) malloc((sizeof(int)) * LOOPCOUNT);
  tids2 = (int *) malloc((sizeof(int)) * LOOPCOUNT);
  #pragma omp parallel
  {
    {
      int n;
      #pragma omp for schedule(static) nowait
      for (n = 0; n < LOOPCOUNT; n++)
      {
        if (LOOPCOUNT == (n + 1))
          my_sleep(SLEEPTIME);

        tids[n] = omp_get_thread_num();
      }

    }
    {
      int m;
      #pragma omp for schedule(static) nowait
      for (m = 1; m <= LOOPCOUNT; m++)
      {
        tids2[m - 1] = omp_get_thread_num();
      }

    }
  }
  for (i = 0; i < LOOPCOUNT; i++)
    if (tids[i] != tids2[i])
  {
    fprintf(stderr, "Chunk no. %d was assigned once to thread %d and later to thread %d.\n", i, tids[i], tids2[i]);
    result = 0;
  }


  free(tids);
  free(tids2);
  return result;
}

