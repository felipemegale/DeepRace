char *timestamp_watchdog_local;
char timestamp_file_local[] = "timestamp.txt";
char vardir_key_local[] = "vardir";
unsigned long int max_errors_per_iter_local = 500;
char config_file_local[] = "/etc/radiation-benchmarks.conf";
char *absolute_path;
char logdir_key[] = "logdir";
int log_error_detail_count = 0;
int iter_interval_print_local = 1;
char log_file_name_local[200] = "";
char full_log_file_name_local[300] = "";
unsigned long int last_iter_errors_local = 0;
unsigned long int last_iter_with_errors_local = 0;
unsigned long int kernels_total_errors_local = 0;
unsigned long int iteration_number_local = 0;
double kernel_time_local_acc_local = 0;
double kernel_time_local = 0;
long long it_time_start_local;
int log_error_detail_local(char *string)
{
  FILE *file = 0;
  #pragma omp parallel shared(log_error_detail_count)
  {
    log_error_detail_count++;
  }
  if (((unsigned long) log_error_detail_count) > max_errors_per_iter_local)
    return 0;

  file = fopen(full_log_file_name_local, "a");
  if (file == 0)
  {
    fprintf(stderr, "[ERROR in log_string(char *)] Unable to open file %s\n", full_log_file_name_local);
    return 1;
  }

  fputs("#ERR ", file);
  fputs(string, file);
  fprintf(file, "\n");
  fflush(file);
  fclose(file);
  return 0;

  double h;
  double x;
  double my_result;
  double local_a;
  double local_b;
  int i;
  int local_n;
  int my_rank = omp_get_thread_num();
  int thread_count = omp_get_num_threads();
  h = (b - a) / n;
  local_n = n / thread_count;
  local_a = a + ((my_rank * local_n) * h);
  local_b = local_a + (local_n * h);
  my_result = f(local_a + f(local_b)) / 2.0;
  for (i = 1; i <= (local_n - 1); i++)
  {
    x = local_a + (i * h);
    my_result += f(x);
  }

  my_result = my_result * h;
  #pragma omp critical
  *global_result_p += my_result;
}

