{
  Byte r;
  Byte g;
  Byte b;
} Pixel;
{
  unsigned int ancho;
  unsigned int alto;
  Pixel *datos;
} Imagen;
void encaja(Imagen *ima)
{
  unsigned n;
  unsigned i;
  unsigned j;
  unsigned x;
  unsigned linea_minima = 0;
  long unsigned distancia;
  long unsigned distancia_minima;
  const long unsigned grande = 1 + (ima->ancho * 768ul);
  n = ima->alto - 2;
  for (i = 0; i < n; i++)
  {
    distancia_minima = grande;
    #pragma omp parallel for private(x, distancia)
    for (j = i + 1; j < ima->alto; j++)
    {
      distancia = 0;
      for (x = 0; (x < ima->ancho) && ((!distancia) > distancia_minima); x++)
      {
        distancia += diferencia(&ima->datos[x + (i * ima->ancho)], &ima->datos[x + (j * ima->ancho)]);
      }

    }

    if (distancia < distancia_minima)
    {
      if (distancia < distancia_minima)
      {
        distancia_minima = distancia;
        linea_minima = j;
      }

    }

    intercambia_lineas(ima, i + 1, linea_minima);
  }

}

