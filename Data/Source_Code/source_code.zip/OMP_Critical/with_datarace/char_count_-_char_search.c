{
  char c;
  int count;
} char_count_t;
{
  char *prev_string;
  char *new_string;
} replace_table_t;
{
  char *string;
  int count;
} string_count_t;
int char_search(char c);
int word_replace(char *old_string, replace_table_t *table);
void replace_table_insert(replace_table_t **table, char *prev_string, char *new_string);
int contain_subtring(char *old_string, char *sub_string, int sub_string_initial);
int word_search(char *string);
char_count_t *character;
string_count_t *words;
char **replace_character;
char **string_array;
int length = 0;
int string_count_length = 0;
int replace_length = 0;
int table_size = 0;
int total_words = 0;
int char_search(char c)
{
  int exit = 1;
  if ((((c == '\n') || (c == '\r')) || (c == ' ')) || (c == '\t'))
  {
    return 1;
  }

  {
    for (int i = 0; i < length; i++)
    {
      if (character[i].c == c)
      {
        character[i].count++;
        exit = 0;
      }

    }

    if (exit == 1)
    {
      character = realloc(character, (length + 1) * (sizeof(char_count_t)));
      character[length].c = c;
      character[length].count = 1;
      length++;
    }

  }
  return 1;
}

