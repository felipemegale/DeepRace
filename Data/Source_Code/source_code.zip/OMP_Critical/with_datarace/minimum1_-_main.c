int main(int argc, const char *argv[])
{
  int i;
  int n;
  int chunk;
  float a[100];
  float b[100];
  float prod;
  float minval;
  n = 100;
  chunk = 10;
  for (i = 0; i < n; i++)
  {
    a[i] = i * 1.0;
    b[i] = i * 2.0;
  }

  minval = FLT_MAX;
  #pragma omp parallel for default(shared) private(i,prod) schedule(static,chunk)
  for (i = 0; i < n; i++)
  {
    prod = a[i] * b[i];
    minval = (prod < minval) ? (prod) : (minval);
  }

  printf("Minimum value = %f\n", minval);

  int i;
  struct node_ *p;
  int processed[350000];
  int v;
  int w;
  int weight;
  int dist;
  #pragma omp parallel for schedule(static)
  for (i = 0; i <= graph->num_of_vertices; ++i)
  {
    processed[i] = 0;
    distance[i] = 32767;
  }

  distance[start] = 0;
  v = start;
  while (processed[v] == 0)
  {
    processed[v] = 1;
    p = graph->vertices[v];
    while (p != 0)
    {
      w = p->adjacent_index;
      weight = p->weight;
      if (distance[w] > (distance[v] + weight))
        distance[w] = distance[v] + weight;

      p = p->next;
    }

    v = 0;
    dist = 32767;
    #pragma omp parallel shared (dist,v) private(i)
    {
      int local_dist = 32767;
      int local_v = 0;
      int id = omp_get_thread_num();
      int N = graph->num_of_vertices + 1;
      int Nthr = omp_get_num_threads();
      int istart = (id * N) / Nthr;
      int iend = ((id + 1) * N) / Nthr;
      for (i = istart; i < iend; ++i)
      {
        if ((processed[i] == 0) && (local_dist > distance[i]))
        {
          local_dist = distance[i];
          local_v = i;
        }

      }

      #pragma omp critical
      {
        if (local_dist < dist)
        {
          dist = local_dist;
          v = local_v;
        }

      }
    }
  }

}

