int main()
{
  int test;
  for (test = 1; test <= 100; test++)
  {
    int i;
    int count = 0;
    #pragma omp parallel for
    for (i = 1; i <= 10000; i++)
    {
      if (omp_get_thread_num() % 2)
      {
        count++;
      }
      else
      {
        count--;
      }

    }

    printf("%d ", count);
    if (!(test % 10))
      printf("\n");

  }

  return 0;
}

