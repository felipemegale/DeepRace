void unlock(int i, bool *locks)
{
  {
    locks[i - 1] = 0;
    locks[i] = 0;
    locks[i + 1] = 0;
  }
}

