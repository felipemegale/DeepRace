double cur_distance;
double cluster_mean[4];
long long cluster_count[4];
int points[100000][2];
void main()
{
  int nt;
  int cluster_index;
  int j;
  double t;
  double min_dist;
  double cur_dist;
  long long i;
  printf("\en enter the number of threads : ");
  scanf("%d", &nt);
  printf("\n");
  populate_points();
  t = omp_get_wtime();
  #pragma omp parallel for private(i,j,min_dist,cur_dist,cluster_index) num_threads(nt)
  for (i = 0; i < 100000; i++)
  {
    min_dist = 1000, cur_dist = -1;
    cluster_index = -1;
    for (j = 0; j < 4; j++)
    {
      cur_dist = get_distance((double) points[i][0], cluster_mean[j]);
      if (cur_dist < min_dist)
      {
        min_dist = cur_dist;
        cluster_index = j;
      }

    }

    if (0 != 0)
      printf("\n%d belongs to cluster %d", points[i][0], cluster_index + 1);

    points[i][1] = cluster_index;
    {
      cluster_mean[cluster_index] = ((cluster_mean[cluster_index] * cluster_count[cluster_index]) + points[i][0]) / (cluster_count[cluster_index] + 1);
      cluster_count[cluster_index]++;
    }
  }

  t = omp_get_wtime() - t;
  printf("\n\nTime taken :%lf\n", t);
}

