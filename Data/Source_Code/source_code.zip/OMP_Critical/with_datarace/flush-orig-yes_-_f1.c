void f1(int *q)
{
  *q = 1;
  #pragma omp flush
}

