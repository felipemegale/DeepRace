int mpi_self;
int mpi_processors;
int a_min = 0;
int a_max = 0;
int n_max = (2 << 7) - 1;
int n_min = 0;
int *image;
int maxcolor;
int rows;
int cols;
enum pnm_kind kind;
int m_printf(char *format, ...);
void execute(double (*determineMinMax)(), double (*rescale)(), char *input_path, int count);
double sequential_determineMinMax();
double sequential_rescale();
double sequential_load(char *input_path);
double openmp_determineMinMax();
double openmp_rescale();
void mpi(char *input_path, int count);
void print(double load, double reduction, double min_max, double rescale, double gather);
int *mpi_read_part(enum pnm_kind kind, int rows, int columns, int *offset, int *length);
void printhelp();
void mpi(char *input_path, int count)
{
  int i;
  int serial_sum;
  double start_time;
  double end_time;
  printf("\nParallel sum\n\nSize %d\n", 10000000);
  if (allocate_vectors() == 1)
    return 1;

  ;
  random_init();
  start_time = omp_get_wtime();
  serial_sum = 0;
  for (i = 0; i < 10000000; i++)
  {
    serial_sum += a[i];
  }

  end_time = omp_get_wtime();
  printf("Serial run time: %f msec\n", (end_time - start_time) * 1000);
  int *partial_sum;
  if ((partial_sum = (int *) malloc(8 * (sizeof(int)))) == 0)
    return 1;

  ;
  memset(partial_sum, 0, 8 * (sizeof(int)));
  start_time = omp_get_wtime();
  #pragma omp parallel shared(a, partial_sum) private(i)
  {
    int nthreads = omp_get_num_threads();
    int id = omp_get_thread_num();
    for (i = (id * 10000000) / nthreads; i < (((id + 1) * 10000000) / nthreads); i++)
    {
      partial_sum[id] += a[i];
    }

  }
  for (i = 1; i < 8; i++)
    partial_sum[0] += partial_sum[i];

  end_time = omp_get_wtime();
  printf("Parallel run time, false sharing: %f msec\n", (end_time - start_time) * 1000);
  printf("Comparing results: ");
  if (partial_sum[0] != serial_sum)
    printf("FAILURE\n");
  else
    printf("SUCCESS\n");

  start_time = omp_get_wtime();
  int sum = 0;
  #pragma omp parallel shared(a, sum) private(i)
  {
    int nthreads = omp_get_num_threads();
    int id = omp_get_thread_num();
    int partial_sum;
    for (i = (id * 10000000) / nthreads; i < (((id + 1) * 10000000) / nthreads); i++)
    {
      partial_sum += a[i];
    }

    #pragma omp critical
    sum += partial_sum;
  }
  end_time = omp_get_wtime();
  printf("Parallel run time, no false sharing: %f msec\n", (end_time - start_time) * 1000);
  printf("Comparing results: ");
  if (partial_sum[0] != serial_sum)
    printf("FAILURE\n");
  else
    printf("SUCCESS\n");

  free(a);
  return 0;

  int i;
  int x;
  int max_min_buf_s[2];
  int max_min_buf_r[2];
  int *image_part;
  int recvcounts[mpi_processors];
  int displs[mpi_processors];
  int tmp;
  int a_min_l;
  int a_max_l;
  int n_min_l;
  int n_max_l;
  double load_s = 0;
  double min_max_s = 0;
  double rescale_s = 0;
  double reduction_s = 0;
  double gather_s = 0;
  double start;
  for (i = 0; i < count; i++)
  {
    MPI_Barrier(MPI_COMM_WORLD);
    start = seconds();
    image_part = ppp_pnm_read_part(input_path, &kind, &rows, &cols, &maxcolor, mpi_read_part);
    MPI_Barrier(MPI_COMM_WORLD);
    load_s += seconds() - start;
    tmp = (rows * cols) % mpi_processors;
    for (x = 0; x < mpi_processors; x++)
    {
      recvcounts[x] = (x < tmp) ? (((rows * cols) / mpi_processors) + 1) : ((rows * cols) / mpi_processors);
      displs[x] = (x < tmp) ? (x * recvcounts[x]) : ((x * recvcounts[x]) + tmp);
    }

    if ((image_part == 0) || (kind != PNM_KIND_PGM))
    {
      m_printf("Error while reading image.");
      MPI_Finalize();
      exit(1);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    start = seconds();
    a_min = maxcolor;
    #pragma omp parallel
    {
      int a_min_t = maxcolor;
      int a_max_t = 0;
      #pragma omp for
      for (x = 0; x < recvcounts[mpi_self]; x++)
      {
        a_min_t = MIN(image_part[x], a_min_t);
        a_max_t = MAX(image_part[x], a_max_t);
      }

      {
        a_min = MIN(a_min, a_min_t);
      }
      {
        a_max = MAX(a_max, a_max_t);
      }
    }
    MPI_Barrier(MPI_COMM_WORLD);
    min_max_s += seconds() - start;
    MPI_Barrier(MPI_COMM_WORLD);
    start = seconds();
    max_min_buf_s[0] = a_max;
    max_min_buf_s[1] = (-1) * a_min;
    MPI_Allreduce(max_min_buf_s, max_min_buf_r, 2, MPI_INT, MPI_MAX, MPI_COMM_WORLD);
    a_max = max_min_buf_r[0];
    a_min = (-1) * max_min_buf_r[1];
    MPI_Barrier(MPI_COMM_WORLD);
    reduction_s += seconds() - start;
    a_min_l = a_min, a_max_l = a_max, n_min_l = n_min, n_max_l = n_max;
    MPI_Barrier(MPI_COMM_WORLD);
    start = seconds();
    #pragma omp parallel for
    for (x = 0; x < recvcounts[mpi_self]; x++)
    {
      image_part[x] = ((((image_part[x] - a_min_l) * (n_max_l - n_min_l)) + ((a_max_l - a_min_l) / 2)) / (a_max_l - a_min_l)) + n_min_l;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    rescale_s += seconds() - start;
    if (mpi_self == 0)
    {
      image = (int *) malloc((rows * cols) * (sizeof(int)));
    }

    MPI_Barrier(MPI_COMM_WORLD);
    start = seconds();
    MPI_Gatherv(image_part, recvcounts[mpi_self], MPI_INT, image, recvcounts, displs, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Barrier(MPI_COMM_WORLD);
    gather_s += seconds() - start;
    free(image_part);
    if (((i + 1) < count) && (mpi_self == 0))
    {
      free(image);
    }

  }

  print(load_s / count, reduction_s / count, min_max_s / count, rescale_s / count, gather_s / count);
}

