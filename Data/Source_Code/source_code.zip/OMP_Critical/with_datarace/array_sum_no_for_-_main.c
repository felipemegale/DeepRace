void main(int argc, char *argv[])
{
  if (argc != 2)
  {
    printf("Usage: ./a.out no_of_elements\n");
    exit(0);
  }

  int n = atoi(argv[1]);
  int i;
  int sum = 0;
  int *arr = (int *) malloc(n * (sizeof(int)));
  printf("enter %d array elements \n", n);
  for (i = 0; i < n; i++)
  {
    scanf("%d", &arr[i]);
  }

  i = 0;
  sum = 0;
  #pragma omp parallel num_threads(n) default(shared)
  {
    {
      sum += arr[omp_get_thread_num()];
      printf("sum=%d and arr_element= %d and tid : %d\n", sum, arr[omp_get_thread_num()], omp_get_thread_num());
    }
  }

  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  shrd = 0;
  #pragma omp parallel shared(shrd)
  {
    #pragma omp critical
    shrd += 1;
    #pragma omp barrier
    if (shrd != thds)
    {
      #pragma omp critical
      errors += 1;
    }

    if ((sizeof(shrd)) != (sizeof(float)))
    {
      #pragma omp critical
      errors += 1;
    }

  }
  shrd = 0;
  #pragma omp parallel shared(shrd)
  func1(&shrd);
  shrd = 0;
  #pragma omp parallel shared(shrd)
  func2();
  if (errors == 0)
  {
    printf("shared 010 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("shared 010 : FAILED\n");
    return 1;
  }

}

