struct City
{
  int index;
  int x;
  int y;
};
struct Thread_Param
{
  int rank;
  int start_depth;
  int skip_depth;
  int max_depth;
};
void print_route();
void *read_coord(void *fp);
void *read_route(void *fp);
inline dist_type distance(dist_type x1, dist_type y1, dist_type x2, dist_type y2);
void parallel_2opt();
void check_time();
dist_type get_city_distance(int index_1, int index_2);
dist_type get_total_route_distance(int *);
dist_type get_partial_route_distance(int *, int, int);
inline dist_type get_swapped_total_route_distance(int *route_index_list, int start, int end);
inline dist_type get_swapped_partial_route_distance(int *route_index_list, int start, int end);
void two_opt_swap(int start, int end);
dist_type two_opt_check(int start, int end);
int available_threads = 12;
int num_city;
dist_type default_distance;
int *route_index_list;
struct City *city_list;
int go_flag = 1;
time_t start_time;
long long *opt_check_counter_list;
long long *opt_swap_counter_list;
long long *contention_counter_list;
int depth_reached = 0;
int round_reached = 0;
int race_cond_counter = 0;
double total_swap_length = 0;
double total_reduced_distance = 0;
void check_time()
{
  go_flag = time(0) < ((start_time + (10 * 30)) - 0);
  static time_t last_time = 0;
  time_t current_time = time(0);
  if (((current_time != last_time) && (((current_time - start_time) % 30) == 0)) && ((current_time - start_time) > 0))
  {
    #pragma omp flush(route_index_list)
    printf("Distance @ %2lu:%02lu = %lf\n", ((unsigned long) (current_time - start_time)) / 60, ((unsigned long) (current_time - start_time)) % 60, get_total_route_distance(route_index_list));
    fflush(stdout);
    last_time = current_time;
  }

}

