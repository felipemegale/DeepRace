struct crompstruct
{
  struct piter pi;
  char *P;
  char *Pmax;
  char *Pmin;
  ptrdiff_t *C;
  ptrdiff_t *CLT;
  ptrdiff_t *CLE;
  ptrdiff_t *GL_CLT;
  ptrdiff_t *GL_CLE;
  ptrdiff_t *GL_C;
};
static void _setup_mpsort_omp(struct crompstruct *o, struct crstruct *d);
static void _cleanup_mpsort_omp(struct crompstruct *o, struct crstruct *d);
static void mpsort_omp_single(void *base, size_t nmemb, struct crstruct *d, struct crompstruct *o);
static void mpsort_omp_single(void *base, size_t nmemb, struct crstruct *d, struct crompstruct *o)
{
  int NTask = omp_get_num_threads();
  int ThisTask = omp_get_thread_num();
  ptrdiff_t myCLT[NTask + 1];
  ptrdiff_t myCLE[NTask + 1];
  int i;
  #pragma omp single
  {
    o->C[0] = 0;
    for (i = 0; i < NTask; i++)
    {
      o->C[i + 1] = (nmemb * (i + 1)) / NTask;
    }

  }
  double t0 = omp_get_wtime();
  char *mybase = ((char *) base) + (((nmemb * ThisTask) / NTask) * d->size);
  size_t mynmemb = ((nmemb * (ThisTask + 1)) / NTask) - ((nmemb * ThisTask) / NTask);
  radix_sort(mybase, mynmemb, d->size, d->radix, d->rsize, d->arg);
  if (mynmemb > 0)
  {
    char myPmax[d->rsize];
    char myPmin[d->rsize];
    d->radix(mybase + ((mynmemb - 1) * d->size), myPmax, d->arg);
    d->radix(mybase, myPmin, d->arg);
    {
      if (d->compar(myPmax, o->Pmax, d->rsize) > 0)
      {
        memcpy(o->Pmax, myPmax, d->rsize);
      }

      if (d->compar(myPmin, o->Pmin, d->rsize) < 0)
      {
        memcpy(o->Pmin, myPmin, d->rsize);
      }

    }
  }

  #pragma omp barrier
  double t1 = omp_get_wtime();
  printf("Initial sort took %g\n", t1 - t0);
  #pragma omp single
  piter_init(&o->pi, o->Pmin, o->Pmax, NTask - 1, d);
  int iter = 0;
  int done = 0;
  while (!done)
  {
    iter++;
    #pragma omp barrier
    #pragma omp single
    piter_bisect(&o->pi, o->P);
    _histogram(o->P, NTask - 1, mybase, mynmemb, myCLT, myCLE, d);
    _reduce_sum(myCLT, o->CLT, NTask + 1);
    _reduce_sum(myCLE, o->CLE, NTask + 1);
    #pragma omp single
    piter_accept(&o->pi, o->P, o->C, o->CLT, o->CLE);
    done = piter_all_done(&o->pi);
  }

  #pragma omp barrier
  #pragma omp single
  piter_destroy(&o->pi);
  double t2 = omp_get_wtime();
  printf("counting took %g\n", t2 - t1);
  _histogram(o->P, NTask - 1, mybase, mynmemb, myCLT, myCLE, d);
  _gather(myCLT, NTask + 1, o->GL_CLT, sizeof(ptrdiff_t));
  _gather(myCLE, NTask + 1, o->GL_CLE, sizeof(ptrdiff_t));
  #pragma omp single
  _solve_for_layout(NTask, o->C, o->GL_CLT, o->GL_CLE, o->GL_C);
  double t3 = omp_get_wtime();
  printf("find split took %g\n", t3 - t2);
  char *buffer = malloc(d->size * mynmemb);
  int NTask1 = NTask + 1;
  char *recv = buffer;
  for (i = 0; i < NTask; i++)
  {
    char *sendbuf = ((char *) base) + (d->size * ((i * nmemb) / NTask));
    size_t size = (o->GL_C[((i * NTask1) + ThisTask) + 1] - o->GL_C[(i * NTask1) + ThisTask]) * d->size;
    char *ptr = &sendbuf[d->size * o->GL_C[(i * NTask1) + ThisTask]];
    memcpy(recv, ptr, size);
    recv += size;
  }

  #pragma omp barrier
  memcpy(mybase, buffer, mynmemb * d->size);
  free(buffer);
  double t4 = omp_get_wtime();
  printf("exchange took %g\n", t4 - t3);
  radix_sort(mybase, mynmemb, d->size, d->radix, d->rsize, d->arg);
  double t5 = omp_get_wtime();
  printf("final sort %g\n", t5 - t4);
  #pragma omp barrier
}

