int num_threads;
int num_rounds;
{
  int myflags[2][10000];
  int *partnerflags[2][10000];
} flags;
int main(int argc, char **argv)
{
  if (argc == 0)
  {
    printf("Too less args\n");
  }

  num_threads = atoi(argv[1]);
  omp_set_num_threads(num_threads);
  flags all_nodes[num_threads];
  num_rounds = ceil(log(num_threads) / log(2));
  double *thread_times = (double *) calloc(num_threads, sizeof(double));
  #pragma omp parallel shared(all_nodes,num_rounds)
  {
    int my_id;
    int i;
    int j;
    int k;
    int r;
    int val;
    my_id = omp_get_thread_num();
    int parity = 0;
    int sense = 1;
    flags *local_flags = &all_nodes[my_id];
    #pragma omp single
    {
      for (i = 0; i < num_threads; i++)
      {
        for (r = 0; r < 2; r++)
        {
          for (k = 0; k < num_rounds; k++)
          {
            all_nodes[i].myflags[r][k] = 0;
          }

        }

      }

    }
    {
      for (j = 0; j < num_threads; j++)
      {
        for (k = 0; k < num_rounds; k++)
        {
          val = pow(2, k);
          if (j == ((my_id + val) % num_threads))
          {
            for (r = 0; r < 2; r++)
            {
              all_nodes[my_id].partnerflags[r][k] = &all_nodes[j].myflags[r][k];
            }

          }

        }

      }

    }
    double t1;
    double t2;
    int iter;
    int barriers = 10;
    t1 = omp_get_wtime();
    for (iter = 0; iter < barriers; iter++)
    {
      dissemination_barrier(local_flags, &parity, &sense);
    }

    t2 = omp_get_wtime();
    double time_taken = (t2 - t1) * 1000000;
    thread_times[omp_get_thread_num()] = time_taken / barriers;
  }
  int j;
  for (j = 0; j < num_threads; j++)
  {
    printf("%lf\n", thread_times[j]);
  }

  free(thread_times);
  return 0;
}

