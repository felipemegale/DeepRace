static int gProgress = 0;
static int gPrimesFound = 0;
long globalPrimes[1000000];
int CLstart;
int CLend;
void ShowProgress(int val, int range)
{
  int percentDone = 0;
  {
    gProgress++;
    percentDone = (int) (((((float) gProgress) / ((float) range)) * 200.0f) + 0.5f);
  }
  if ((percentDone % 10) == 0)
    printf("\b\b\b\b%3d%%", percentDone);

}

