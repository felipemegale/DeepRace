int bucketSort(int n, int b)
{
  int *buckets = (int *) malloc((sizeof(int)) * n);
  int i;
  int k;
  for (i = 0; i < n; i++)
  {
    buckets[i] = 0;
  }

  int sharedStart = 0;
  double t1;
  double t2;
  double tt;
  int *sharedBSize = (int *) malloc((sizeof(int)) * b);
  int *sharedBIndex = (int *) malloc((sizeof(int)) * b);
  int *sharedBStart = (int *) malloc((sizeof(int)) * b);
  for (i = 0; i < b; i++)
  {
    sharedBSize[i] = 0;
    sharedBIndex[i] = 0;
    sharedBStart[i] = 0;
  }

  #pragma omp parallel private(i,k)
  {
    int *elemCore = (int *) malloc((sizeof(int)) * (n / b));
    int *bucketsCore = (int *) malloc((sizeof(int)) * (n / b));
    int ID = omp_get_thread_num();
    unsigned int seed = omp_get_thread_num();
    int i;
    int toSum = 0;
    int range = 100000;
    int *bucketSize = (int *) malloc((sizeof(int)) * b);
    int *currentBIndex = (int *) malloc((sizeof(int)) * b);
    int *currentBIndexBak = (int *) malloc((sizeof(int)) * b);
    {
      for (i = 0; i < (n / b); i++)
      {
        elemCore[i] = rand_r(&seed) % range;
      }

    }
    for (i = 0; i < b; i++)
    {
      bucketSize[i] = 0;
      currentBIndex[i] = 0;
    }

    t1 = omp_get_wtime();
    for (i = 0; i < (n / b); i++)
    {
      bucketSize[(elemCore[i] * b) / range]++;
    }

    for (i = 0; i < b; i++)
    {
      currentBIndex[i] = toSum;
      {
        sharedBStart[i] += toSum;
      }
      currentBIndexBak[i] = toSum;
      toSum = toSum + bucketSize[i];
    }

    for (i = 0; i < (n / b); i++)
    {
      int bucketToPut = (elemCore[i] * b) / range;
      bucketsCore[currentBIndex[bucketToPut]] = elemCore[i];
      currentBIndex[bucketToPut]++;
    }

    #pragma omp barrier
    for (i = 0; i < b; i++)
    {
      {
        for (k = sharedStart; k < (sharedStart + bucketSize[i]); k++)
        {
          buckets[k] = bucketsCore[currentBIndexBak[i]];
          currentBIndexBak[i]++;
        }

        sharedStart = sharedStart + bucketSize[i];
        sharedBSize[i] += bucketSize[i];
      }
      #pragma omp barrier
    }

    qsort(&buckets[sharedBStart[ID]], sharedBSize[ID], sizeof(int), cmpfunc);
    #pragma omp barrier
  }
  t2 = omp_get_wtime();
  tt = t2 - t1;
  for (int i = 0; i < (n - 1); i++)
  {
    if (buckets[i] > buckets[i + 1])
    {
      printf("Array is not sorted! Index %d bigger than next.", i);
      break;
    }

  }

  printf("Time to sort %d elements in %d buckets was %f\n", n, b, tt);
}

