void bar();
void foo()
{
  bar();
  #pragma omp master
  bar();
  #pragma omp single
  bar();
  #pragma omp for
  for (int i = 0; i < 10; ++i)
    bar();

  #pragma omp sections
  {
    bar();
  }
  #pragma omp parallel
  bar();
  #pragma omp parallel for
  for (int i = 0; i < 10; ++i)
    bar();

  #pragma omp parallel sections
  {
    {
      bar();
      bar();
    }
    #pragma omp section
    bar();
  }
}

