static long seed = 123456789;
{
  double x;
  double y;
  double z;
  double mass;
} Particle;
{
  double xold;
  double yold;
  double zold;
  double fx;
  double fy;
  double fz;
} ParticleV;
void InitParticles(Particle [], ParticleV [], int);
double ComputeForces(Particle [], Particle [], ParticleV [], int);
double ComputeNewPos(Particle [], ParticleV [], int, double);
void InitParticles(Particle particles[], ParticleV pv[], int npart)
{
  int i;
  #pragma omp parallel for default(none) private(i) shared(particles, pv, npart)
  for (i = 0; i < npart; i++)
  {
    {
      particles[i].x = Random();
      particles[i].y = Random();
      particles[i].z = Random();
    }
    particles[i].mass = 1.0;
    pv[i].xold = particles[i].x;
    pv[i].yold = particles[i].y;
    pv[i].zold = particles[i].z;
    pv[i].fx = 0;
    pv[i].fy = 0;
    pv[i].fz = 0;
  }

}

