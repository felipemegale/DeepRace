double start_time;
double end_time;
int gmin = 32767;
int gmax = INT_MIN;
int gminx = -1;
int gminy = -1;
int gmaxx = -1;
int gmaxy = -1;
int gsum = 0;
int numWorkers;
int size;
int matrix[10000][10000];
void *Worker(void *);
int main(int argc, char *argv[])
{
  int i;
  int j;
  int total = 0;
  size = (argc > 1) ? (atoi(argv[1])) : (10000);
  numWorkers = (argc > 2) ? (atoi(argv[2])) : (100);
  if (size > 10000)
    size = 10000;

  if (numWorkers > 100)
    numWorkers = 100;

  omp_set_num_threads(numWorkers);
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      matrix[i][j] = rand() % 99;
    }

  }

  start_time = omp_get_wtime();
  #pragma omp parallel for reduction (+:total) private(j) shared(gmin,gmax,gminx,gminy,gmaxx,gmaxy)
  for (i = 0; i < size; i++)
    for (j = 0; j < size; j++)
  {
    total += matrix[i][j];
    if (matrix[i][j] < gmin)
    {
      {
        if (matrix[i][j] < gmin)
        {
          gminx = i;
          gminy = j;
          gmin = matrix[i][j];
        }

      }
    }

    if (matrix[i][j] > gmax)
    {
      {
        if (matrix[i][j] > gmax)
        {
          gmaxx = i;
          gmaxy = j;
          gmax = matrix[i][j];
        }

      }
    }

  }


  end_time = omp_get_wtime();
  printf("MIN => %d x: %d y: %d\n", gmin, gminx, gminy);
  printf("MAX => %d x: %d y: %d\n", gmax, gmaxx, gmaxy);
  printf("the total is %d\n", total);
  printf("it took %g seconds\n", end_time - start_time);
}

