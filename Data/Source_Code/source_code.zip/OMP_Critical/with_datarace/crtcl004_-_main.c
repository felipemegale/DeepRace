static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int flag;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  flag = 0;
  #pragma omp parallel
  {
    int id = omp_get_thread_num();
    switch (id)
    {
      case 0:
      {
        flag = 1;
        while (flag != 2)
        {
          #pragma omp flush
        }

      }
        break;

      case 1:
      {
        while (flag != 1)
        {
          #pragma omp flush
        }

        flag = 2;
      }
        break;

      default:
        break;

    }

  }
  if (flag != 2)
  {
    errors += 1;
  }

  flag = 0;
  #pragma omp parallel
  {
    func_critical();
  }
  if (flag != 2)
  {
    errors += 1;
  }

  if (errors == 0)
  {
    printf("critical 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("critical 004 : FAILED\n");
    return 1;
  }


  unsigned long int i;
  unsigned long int k;
  unsigned long int N;
  char *prime;
  unsigned long int primecount = 0;
  unsigned long int maxprime = 0;
  unsigned long int max = 0;
  double startTime;
  double endTime;
  if (argc != 2)
  {
    printf("Usage: %s N\n", argv[0]);
    printf("Usage: N is any positive integer number larger than 2\n");
    exit(1);
  }

  startTime = omp_get_wtime();
  N = atoi(argv[1]);
  prime = (char *) malloc((N + 1) * (sizeof(char)));
  if (prime == 0)
  {
    printf("malloc failed!");
    exit(1);
  }

  #pragma omp parallel private(i, k) shared(prime, maxprime) firstprivate(max)
  {
    #pragma omp for
    for (i = 0; i < (N + 1); i++)
      prime[i] = unmarked;

    #pragma omp for schedule(dynamic)
    for (i = 2; i <= ((int) sqrt(N)); i++)
    {
      if (prime[i] == unmarked)
      {
        for (k = i * i; k <= N; k += i)
          prime[k] = marked;

      }

    }

    #pragma omp for
    for (i = 2; i < (N + 1); i++)
    {
      if (prime[i] == unmarked)
      {
        #pragma omp atomic
        primecount++;
        if (i > max)
          max = i;

        #pragma omp critical
        {
          if (max > maxprime)
            maxprime = max;

        }
      }

    }

  }
  printf("The number of primes: %ld\n", primecount);
  printf("The largest prime: %ld\n", maxprime);
  endTime = omp_get_wtime();
  printf("%.6f ms\n", (endTime - startTime) * 1e3);
  free(prime);
  return 0;
}

