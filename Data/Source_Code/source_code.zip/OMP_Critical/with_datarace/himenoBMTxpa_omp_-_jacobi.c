struct Mat
{
  float *m;
  int mnums;
  int mrows;
  int mcols;
  int mdeps;
};
int newMat(Matrix *Mat, int mnums, int mrows, int mcols, int mdeps);
void clearMat(Matrix *Mat);
void dumpMat(Matrix *Mat, int l);
void set_param(int i[], char *size);
void mat_set(Matrix *Mat, int l, float z);
void mat_set_init(Matrix *Mat);
float jacobi(int n, Matrix *M1, Matrix *M2, Matrix *M3, Matrix *M4, Matrix *M5, Matrix *M6, Matrix *M7);
double second();
float omega = 0.8;
Matrix a;
Matrix b;
Matrix c;
Matrix p;
Matrix bnd;
Matrix wrk1;
Matrix wrk2;
float jacobi(int nn, Matrix *a, Matrix *b, Matrix *c, Matrix *p, Matrix *bnd, Matrix *wrk1, Matrix *wrk2)
{
  int i;
  int j;
  int k;
  int n;
  int imax;
  int jmax;
  int kmax;
  float gosa;
  float gosa1;
  float s0;
  float ss;
  imax = p->mrows - 1;
  jmax = p->mcols - 1;
  kmax = p->mdeps - 1;
  #pragma omp parallel shared(a,p,b,c,bnd,wrk1,wrk2,nn,imax,jmax,kmax,omega,gosa) private(i,j,k,s0,ss,gosa1,n)
  {
    for (n = 0; n < nn; n++)
    {
      #pragma omp barrier
      #pragma omp master
      {
        gosa = 0.0;
      }
      gosa1 = 0.0;
      #pragma omp for nowait
      for (i = 1; i < imax; i++)
        for (j = 1; j < jmax; j++)
        for (k = 1; k < kmax; k++)
      {
        s0 = (((((((((a->m[(((((0 * a->mrows) * a->mcols) * a->mdeps) + ((i * a->mcols) * a->mdeps)) + (j * a->mdeps)) + k] * p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i + 1) * p->mcols) * p->mdeps)) + (j * p->mdeps)) + k]) + (a->m[(((((1 * a->mrows) * a->mcols) * a->mdeps) + ((i * a->mcols) * a->mdeps)) + (j * a->mdeps)) + k] * p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + ((j + 1) * p->mdeps)) + k])) + (a->m[(((((2 * a->mrows) * a->mcols) * a->mdeps) + ((i * a->mcols) * a->mdeps)) + (j * a->mdeps)) + k] * p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + (j * p->mdeps)) + (k + 1)])) + (b->m[(((((0 * b->mrows) * b->mcols) * b->mdeps) + ((i * b->mcols) * b->mdeps)) + (j * b->mdeps)) + k] * (((p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i + 1) * p->mcols) * p->mdeps)) + ((j + 1) * p->mdeps)) + k] - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i + 1) * p->mcols) * p->mdeps)) + ((j - 1) * p->mdeps)) + k]) - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i - 1) * p->mcols) * p->mdeps)) + ((j + 1) * p->mdeps)) + k]) + p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i - 1) * p->mcols) * p->mdeps)) + ((j - 1) * p->mdeps)) + k]))) + (b->m[(((((1 * b->mrows) * b->mcols) * b->mdeps) + ((i * b->mcols) * b->mdeps)) + (j * b->mdeps)) + k] * (((p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + ((j + 1) * p->mdeps)) + (k + 1)] - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + ((j - 1) * p->mdeps)) + (k + 1)]) - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + ((j + 1) * p->mdeps)) + (k - 1)]) + p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + ((j - 1) * p->mdeps)) + (k - 1)]))) + (b->m[(((((2 * b->mrows) * b->mcols) * b->mdeps) + ((i * b->mcols) * b->mdeps)) + (j * b->mdeps)) + k] * (((p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i + 1) * p->mcols) * p->mdeps)) + (j * p->mdeps)) + (k + 1)] - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i - 1) * p->mcols) * p->mdeps)) + (j * p->mdeps)) + (k + 1)]) - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i + 1) * p->mcols) * p->mdeps)) + (j * p->mdeps)) + (k - 1)]) + p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i - 1) * p->mcols) * p->mdeps)) + (j * p->mdeps)) + (k - 1)]))) + (c->m[(((((0 * c->mrows) * c->mcols) * c->mdeps) + ((i * c->mcols) * c->mdeps)) + (j * c->mdeps)) + k] * p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + (((i - 1) * p->mcols) * p->mdeps)) + (j * p->mdeps)) + k])) + (c->m[(((((1 * c->mrows) * c->mcols) * c->mdeps) + ((i * c->mcols) * c->mdeps)) + (j * c->mdeps)) + k] * p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + ((j - 1) * p->mdeps)) + k])) + (c->m[(((((2 * c->mrows) * c->mcols) * c->mdeps) + ((i * c->mcols) * c->mdeps)) + (j * c->mdeps)) + k] * p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + (j * p->mdeps)) + (k - 1)])) + wrk1->m[(((((0 * wrk1->mrows) * wrk1->mcols) * wrk1->mdeps) + ((i * wrk1->mcols) * wrk1->mdeps)) + (j * wrk1->mdeps)) + k];
        ss = ((s0 * a->m[(((((3 * a->mrows) * a->mcols) * a->mdeps) + ((i * a->mcols) * a->mdeps)) + (j * a->mdeps)) + k]) - p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + (j * p->mdeps)) + k]) * bnd->m[(((((0 * bnd->mrows) * bnd->mcols) * bnd->mdeps) + ((i * bnd->mcols) * bnd->mdeps)) + (j * bnd->mdeps)) + k];
        gosa1 += ss * ss;
        wrk2->m[(((((0 * wrk2->mrows) * wrk2->mcols) * wrk2->mdeps) + ((i * wrk2->mcols) * wrk2->mdeps)) + (j * wrk2->mdeps)) + k] = p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + (j * p->mdeps)) + k] + (omega * ss);
      }



      #pragma omp barrier
      #pragma omp for nowait
      for (i = 1; i < imax; i++)
        for (j = 1; j < jmax; j++)
        for (k = 1; k < kmax; k++)
        p->m[(((((0 * p->mrows) * p->mcols) * p->mdeps) + ((i * p->mcols) * p->mdeps)) + (j * p->mdeps)) + k] = wrk2->m[(((((0 * wrk2->mrows) * wrk2->mcols) * wrk2->mdeps) + ((i * wrk2->mcols) * wrk2->mdeps)) + (j * wrk2->mdeps)) + k];



      {
        gosa += gosa1;
      }
    }

  }
  return gosa;
}

