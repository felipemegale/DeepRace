struct cell_t
{
  int size = TOTAL / THREAD_SIZE;
  int local_sum = 0;
  srand(time(0));
  for (unsigned int i = 0; i < size; ++i)
  {
    double X = (((double) (rand() % LIMITE)) / N) - 1;
    double Y = (((double) (rand() % LIMITE)) / N) - 1;
    double distancia = (X * X) + (Y * Y);
    if (distancia <= 1)
      ++local_sum;

  }

  #pragma omp critical
  radio_ += local_sum;

  int row;
  int col;
  int *list;
  int *base_array;
  int n_allowed;
  int value;
};
int is_allowed(cell_t *this, int val);
int add_allowed(cell_t *, int);
int remove_allowed(cell_t *this, int val);
int set_value(cell_t *, int);
struct pool_t;
struct pool_t
{
  cell_t **arr_boards;
  int sz_alloc;
  int sz;
};
workpool_t *workpool;
board_store_t *store;
cell_t *solved_board;
int solved;
int copy_mat2board(int **mat, cell_t *board);
int restore_invariants(cell_t *board);
int get_branchon(cell_t *board);
int populate_workpool(workpool_t *pool, cell_t *board, int nsize);
int hdfs(cell_t **ptr_board);
int dfs_recursive(cell_t *board);
int dfs_iterative(cell_t *board);
int heuristic_solve(cell_t *board);
int branch(cell_t *board, workpool_t *pool, int max_branches);
int hdfs(cell_t **ptr_board)
{
  cell_t *oldboard;
  {
    oldboard = pop_mem(store);
  }
  copy_board(oldboard, *ptr_board);
  int solv_state = -1;
  solv_state = heuristic_solve(*ptr_board);
  if (solv_state == 0)
  {
    {
      push_mem(store, oldboard);
    }
    return 0;
  }
  else
    if (solv_state == 2)
  {
    {
      push_mem(store, *ptr_board);
    }
    *ptr_board = oldboard;
    return 2;
  }


  int bon;
  int nal;
  int lst_iter;
  bon = get_branchon(*ptr_board);
  nal = (*ptr_board)[bon].n_allowed;
  int *alters;
  int nalters;
  alters = malloc(((SIZE * SIZE) + 1) * (sizeof(int)));
  for (lst_iter = 1; lst_iter <= nal; ++lst_iter)
  {
    nalters = -1;
    int val = (*ptr_board)[bon].list[lst_iter];
    set_board_value_idx(*ptr_board, bon, val, alters, &nalters);
    if (solved == 0)
    {
      {
        push_mem(store, *ptr_board);
      }
      *ptr_board = oldboard;
      free(alters);
      return 42;
    }

    solv_state = hdfs(ptr_board);
    if (solv_state == 0)
    {
      {
        push_mem(store, oldboard);
      }
      free(alters);
      return 0;
    }
    else
      if (solv_state == 42)
    {
      {
        push_mem(store, *ptr_board);
      }
      *ptr_board = oldboard;
      free(alters);
      return 42;
    }


    undo_alterations(*ptr_board, val, alters, &nalters);
  }

  free(alters);
  {
    push_mem(store, *ptr_board);
  }
  *ptr_board = oldboard;
  return 2;
}

