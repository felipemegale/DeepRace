int thread_size;
int tam_vec;
int random_ini;
int random_fin;
int *random_array = 0;
int *contador = 0;
void histogram()
{
  if (random_array && contador)
  {
    int size = tam_vec / thread_size;
    int id = omp_get_thread_num();
    int init = id * size;
    int fin = init + size;
    for (int i = init; i < fin; ++i)
    {
      ++contador[random_array[i]];
    }

  }

}

