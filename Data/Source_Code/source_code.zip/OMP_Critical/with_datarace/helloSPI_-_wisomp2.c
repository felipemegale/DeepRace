static double num_steps = 1000000000;
double step;
double start;
double end;
int noomp();
int wiomp();
int wisomp();
int wisomp1();
int wisomp2();
int wisomp3();
int itr = 0;
int wisomp2()
{
  int n;
  int nthreads = 1;
  int i;
  int j;
  int seed;
  double x;
  double sum = 0.0;
  double t0;
  double t1;
  struct drand48_data drand_buf;
  if (argc > 1)
  {
    nthreads = atoi(argv[1]);
  }

  n = 100000000;
  t0 = omp_get_wtime();
  #pragma omp parallel for num_threads(nthreads) private(seed, drand_buf, x)
  for (i = 0; i < n; i++)
  {
    seed = 1202107158 + (omp_get_thread_num() * 1999);
    srand48_r(seed, &drand_buf);
    drand48_r(&drand_buf, &x);
    #pragma omp critical
    sum += x;
  }

  t1 = omp_get_wtime();
  printf("time: %7.3f\n", t1 - t0);
  printf("sum: %f\n", sum);

  int n = 0;
  for (n = 8; n < 9; n++)
  {
    omp_set_num_threads(n);
    int i = 0;
    double pi = 0.0;
    step = 1.0 / ((double) num_steps);
    start = omp_get_wtime();
    #pragma omp parallel
    {
      double sum = 0.0;
      double x = 0.0;
      #pragma omp for schedule(guided,itr)
      for (i = 0; i < ((int) num_steps); i++)
      {
        x = (i + 0.5) * step;
        sum += 4.0 / (1.0 + (x * x));
      }

      pi += sum * step;
    }
    end = omp_get_wtime();
    printf("%d threads takes %f seconds to process guided, result is %f\n", n, end - start, pi);
  }

  return 0;
}

