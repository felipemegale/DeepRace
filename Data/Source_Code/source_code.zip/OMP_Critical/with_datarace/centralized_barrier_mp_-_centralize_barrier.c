{
  bool sense;
  int count;
  int nthds;
} sense_count_t;
void centralize_barrier(sense_count_t *sc)
{
  bool curr_sense;
  {
    assert(sc->count > 0);
    curr_sense = !sc->sense;
    if (__sync_fetch_and_sub(&sc->count, 1) == 1)
    {
      sc->count = sc->nthds;
      sc->sense = curr_sense;
    }

  }
  ;
  while (sc->sense != curr_sense)
    ;

  ;

  int i;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    #pragma omp for schedule(static,1) lastprivate (prvt1,prvt2) lastprivate (prvt3)
    for (i = 0; i < thds; i++)
    {
      prvt1 = i;
      prvt2 = i;
      prvt3 = i;
      barrier(thds);
      if (prvt1 != i)
      {
        #pragma omp critical
        errors += 1;
      }

      if (prvt2 != i)
      {
        #pragma omp critical
        errors += 1;
      }

      if (prvt3 != i)
      {
        #pragma omp critical
        errors += 1;
      }

      if (i == 0)
      {
        waittime(1);
      }

      prvt1 = i;
      prvt2 = i;
      prvt3 = i;
    }

    if (prvt1 != (thds - 1))
    {
      #pragma omp critical
      errors += 1;
    }

    if (prvt2 != (thds - 1))
    {
      #pragma omp critical
      errors += 1;
    }

    if (prvt3 != (thds - 1))
    {
      #pragma omp critical
      errors += 1;
    }

  }
  #pragma omp parallel
  func(thds);
  func(1);
  if (errors == 0)
  {
    printf("lastprivate 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("lastprivate 004 : FAILED\n");
    return 1;
  }

}

