static void *(*real_malloc)(size_t size) = 0;
static void (*real_free)(void *p) = 0;
static size_t used_mem[1];
static char size_pow[6] = {'B', 'K', 'M', 'G', 'T', 'P'};
static void hread_size(float *out_size, char *unit, const size_t in_size);
static void init_alloc(void);
static int memtr_printf(const char *format, ...);
static void print_backtrace(unsigned int max_frames);
static void reset_used_mem(void);
static void splash(void);
void free(void *p)
{
  size_t size;
  int thread;
  if (p != 0)
  {
    thread = 0;
    size = malloc_usable_size(p);
    if (thread >= 1)
    {
      memtr_printf("error: MemTrack built with insufficient thread support (MAX_THREADS=%d)\n", 1);
      exit(1);
    }

    real_free(p);
    used_mem[thread] -= size;
    {
      memtr_printf("%6s @ %p | -%luB\n", "free", p, (long unsigned int) size, (long unsigned int) used_mem[thread]);
    }
  }


  long int n;
  long int a;
  long int b;
  long int s;
  int x;
  int y;
  int sgn;
  int bits = 0;
  int facing;
  int f_facing;
  int marker;
  double pt_int[3];
  double origin[3];
  double r_o[3];
  double o_n[3];
  double dv[3];
  double d_o[3];
  double r_v[3];
  double vert[4][3];
  double tet[3];
  double v_x[3][3];
  double v_list[6][3];
  double f;
  double dx_dz;
  double dy_dz;
  double dx_dy;
  double dz_dx;
  double dy_dx;
  double dz_dy;
  double dx;
  double dy;
  double dz;
  double hex[3][2][3] = {{{-2, -2, -2}, {-2, -2, -2}}, {{-2, -2, -2}, {-2, -2, -2}}, {{-2, -2, -2}, {-2, -2, -2}}};
  const double vertex_list[8][3] = {{0, 0, 0}, {0, 1, 0}, {1, 1, 0}, {1, 0, 0}, {0, 0, 1}, {1, 0, 1}, {1, 1, 1}, {0, 1, 1}};
  const double normals[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
  const double del[3] = {mesh->delx, mesh->dely, mesh->delz};
  const double emf = 0.000001;
  origin[0] = mesh->origin[0] + (mesh->delx * i);
  origin[1] = mesh->origin[1] + (mesh->dely * j);
  origin[2] = mesh->origin[2] + (mesh->delz * k);
  marker = -1;
  for (s = 0; s < 8; s++)
  {
    for (x = 0; x < 3; x++)
    {
      r_o[x] = origin[x] + (del[x] * vertex_list[s][x]);
      for (a = 0; a < 2; a++)
      {
        hex[x][a][0] = -2;
        hex[x][a][1] = -2;
        hex[x][a][2] = -2;
      }

    }

    bits = 0;
    for (a = 0; a < 3; a++)
    {
      vert[a][0] = vertex_list[s][0];
      vert[a][1] = vertex_list[s][1];
      vert[a][2] = vertex_list[s][2];
      if (vertex_list[s][0] < emf)
      {
        r_v[0] = r_o[0] + (normals[a][0] * del[0]);
        vert[a][0] = vert[a][0] + normals[a][0];
      }
      else
      {
        r_v[0] = r_o[0] - (normals[a][0] * del[0]);
        vert[a][0] = vert[a][1] - normals[a][0];
      }

      if (vertex_list[s][1] < emf)
      {
        r_v[1] = r_o[1] + (normals[a][1] * del[1]);
        vert[a][1] = vert[a][1] + normals[a][1];
      }
      else
      {
        r_v[1] = r_o[1] - (normals[a][1] * del[1]);
        vert[a][1] = vert[a][1] - normals[a][1];
      }

      if (vertex_list[s][2] < emf)
      {
        r_v[2] = r_o[2] + (normals[a][2] * del[2]);
        vert[a][2] = vert[a][2] + normals[a][2];
      }
      else
      {
        r_v[2] = r_o[2] - (normals[a][2] * del[2]);
        vert[a][2] = vert[a][2] - normals[a][2];
      }

      d_o[0] = r_v[0] - origin[0];
      d_o[1] = r_v[1] - origin[1];
      d_o[2] = r_v[2] - origin[2];
      ;
      dv[0] = fabs(r_o[0] - r_v[0]);
      dv[1] = fabs(r_o[1] - r_v[1]);
      dv[2] = fabs(r_o[2] - r_v[2]);
      x = 0;
      for (b = 0; b < 3; b++)
      {
        if ((((dv[0] * normals[b][0]) + (dv[1] * normals[b][1])) + (dv[2] * normals[b][2])) > emf)
          continue;

        sgn = ((((d_o[0] * normals[b][0]) + (d_o[1] * normals[b][1])) + (d_o[2] * normals[b][2])) > emf) ? (-1) : (1);
        o_n[0] = normals[b][0];
        o_n[1] = normals[b][1];
        o_n[2] = normals[b][2];
        for (n = 0; n < stl->facets; n++)
        {
          if ((facing = moller_trumbore(r_v, o_n, stl->v_1[n], stl->v_2[n], stl->v_3[n], pt_int)) != 0)
          {
            f = (((pt_int[0] - r_v[0]) / del[0]) + ((pt_int[1] - r_v[1]) / del[1])) + ((pt_int[2] - r_v[2]) / del[2]);
            f *= sgn;
            if ((f > ((-1.0) * emf)) && (f < (1 + emf)))
            {
              hex[a][x][0] = (pt_int[0] - r_v[0]) / del[0];
              hex[a][x][1] = (pt_int[1] - r_v[1]) / del[1];
              hex[a][x][2] = (pt_int[2] - r_v[2]) / del[2];
              bits |= 1 << ((a * 2) + x);
              f_facing = facing * sgn;
            }

          }

        }

        x++;
      }

    }

    if (count_bits(bits) == 4)
    {
      for (b = 0; b < 3; b++)
      {
        if ((((((hex[b][0][0] == (-2)) && (hex[b][0][1] == (-2))) && (hex[b][0][2] == (-2))) && (hex[b][1][0] == (-2))) && (hex[b][1][1] == (-2))) && (hex[b][1][2] == (-2)))
        {
          marker = b;
          d_o[0] = r_o[0] - origin[0];
          d_o[1] = r_o[1] - origin[1];
          d_o[2] = r_o[2] - origin[2];
          ;
          sgn = ((((d_o[0] * normals[b][0]) + (d_o[1] * normals[b][1])) + (d_o[2] * normals[b][2])) > emf) ? (-1) : (1);
          o_n[0] = normals[b][0];
          o_n[1] = normals[b][1];
          o_n[2] = normals[b][2];
          for (n = 0; n < stl->facets; n++)
          {
            if ((facing = moller_trumbore(r_o, o_n, stl->v_1[n], stl->v_2[n], stl->v_3[n], pt_int)) != 0)
            {
              f = (((pt_int[0] - r_o[0]) / del[0]) + ((pt_int[1] - r_o[1]) / del[1])) + ((pt_int[2] - r_o[2]) / del[2]);
              f *= sgn;
              if ((f > ((-1.0) * emf)) && (f < (1 + emf)))
              {
                hex[b][0][0] = (pt_int[0] - r_o[0]) / del[0];
                hex[b][0][1] = (pt_int[1] - r_o[1]) / del[1];
                hex[b][0][2] = (pt_int[2] - r_o[2]) / del[2];
                f_facing = facing * sgn;
              }
              else
                marker = -1;

            }

          }

        }

      }

    }

    if (marker != (-1))
    {
      vert[3][0] = vertex_list[s][0];
      vert[3][1] = vertex_list[s][1];
      vert[3][2] = vertex_list[s][2];
      break;
    }

  }

  if (marker != (-1))
  {
    switch (marker)
    {
      case 0:
        v_x[0][0] = vert[3][0] + hex[0][0][0];
        v_x[0][1] = vert[3][1];
        v_x[0][2] = vert[3][2];
        dy = 1;
        dx = fabs(hex[1][0][0] - hex[0][0][0]);
        dy_dx = dy / dx;
        if (vert[1][1] > emf)
        v_x[1][1] = (dy_dx * fabs(hex[1][0][0])) + vert[1][1];
      else
        v_x[1][1] = (dy_dx * fabs(hex[1][0][0])) * (-1.0);

        v_x[1][0] = vert[1][0];
        v_x[1][2] = vert[1][2];
        dz = 1;
        dx = fabs(hex[2][0][0] - hex[0][0][0]);
        dz_dx = dz / dx;
        if (vert[2][2] > emf)
        v_x[2][2] = (dz_dx * fabs(hex[2][0][0])) + vert[2][2];
      else
        v_x[2][2] = (dz_dx * fabs(hex[2][0][0])) * (-1.0);

        v_x[2][0] = vert[2][0];
        v_x[2][1] = vert[2][1];
        break;

      case 1:
        dx = 1;
        dy = fabs(hex[0][0][1] - hex[1][0][1]);
        dx_dy = dx / dy;
        if (vert[0][0] > emf)
        v_x[0][0] = (dx_dy * fabs(hex[0][0][1])) + vert[0][0];
      else
        v_x[0][0] = (dx_dy * fabs(hex[0][0][1])) * (-1.0);

        v_x[0][1] = vert[0][1];
        v_x[0][2] = vert[0][2];
        v_x[1][0] = vert[3][0];
        v_x[1][1] = vert[3][1] + hex[1][0][1];
        v_x[1][2] = vert[3][2];
        dz = 1;
        dy = fabs(hex[2][1][1] - hex[1][0][1]);
        dz_dy = dz / dy;
        if (vert[2][2] > emf)
        v_x[2][2] = (dz_dy * fabs(hex[2][1][1])) + vert[2][2];
      else
        v_x[2][2] = (dz_dy * fabs(hex[2][1][1])) * (-1.0);

        v_x[2][0] = vert[2][0];
        v_x[2][1] = vert[2][1];
        break;

      case 2:
        dx = 1;
        dz = fabs(hex[0][1][2] - hex[2][0][2]);
        dx_dz = dx / dz;
        if (vert[0][0] > emf)
        v_x[0][0] = (dx_dz * fabs(hex[0][1][2])) + vert[0][0];
      else
        v_x[0][0] = (dx_dz * fabs(hex[0][1][2])) * (-1.0);

        v_x[0][1] = vert[0][1];
        v_x[0][2] = vert[0][2];
        dy = 1;
        dz = fabs(hex[1][1][2] - hex[2][0][2]);
        dy_dz = dy / dz;
        if (vert[1][1] > emf)
        v_x[1][1] = (dy_dz * fabs(hex[1][1][2])) + vert[1][1];
      else
        v_x[1][1] = (dy_dz * fabs(hex[1][1][2])) * (-1.0);

        v_x[1][0] = vert[1][0];
        v_x[1][2] = vert[1][2];
        v_x[2][0] = vert[3][0];
        v_x[2][1] = vert[3][1];
        v_x[2][2] = vert[3][2] + hex[2][0][2];
        break;

    }

    y = 0;
    for (x = 0; x < 3; x++)
    {
      if (x == marker)
        continue;

      hex[x][0][0] = hex[x][0][0] + vert[x][0];
      hex[x][0][1] = hex[x][0][1] + vert[x][1];
      hex[x][0][2] = hex[x][0][2] + vert[x][2];
      ;
      hex[x][1][0] = hex[x][1][0] + vert[x][0];
      hex[x][1][1] = hex[x][1][1] + vert[x][1];
      hex[x][1][2] = hex[x][1][2] + vert[x][2];
      ;
      tet[y] = fabs(tet_volume(v_x[x], hex[x][0], hex[x][1], vert[x]));
      v_list[2 * y][0] = hex[x][0][0];
      v_list[2 * y][1] = hex[x][0][1];
      v_list[2 * y][2] = hex[x][0][2];
      v_list[(2 * y) + 1][0] = hex[x][1][0];
      v_list[(2 * y) + 1][1] = hex[x][1][1];
      v_list[(2 * y) + 1][2] = hex[x][1][2];
      y++;
    }

    tet[y] = fabs(tet_volume(v_x[0], v_x[1], v_x[2], vert[3]));
    if (check_coplanar(v_x[marker], v_list[0], v_list[1], v_list[2]) && check_coplanar(v_x[marker], v_list[0], v_list[1], v_list[3]))
      mesh->fv[mesh_index(mesh, i, j, k)] = tet[2] - (tet[0] + tet[1]);
    else
    {
      y = 0;
      for (x = 0; x < 3; x++)
      {
        if (x == marker)
          continue;

        v_list[4 + y][0] = vert[x][0];
        v_list[4 + y][1] = vert[x][1];
        v_list[4 + y][2] = vert[x][2];
        y++;
      }

      #pragma omp critical(qhull_fraction)
      {
        f = qhull_get_pent_volume(v_list[0], v_list[1], v_list[2], v_list[3], v_list[4], v_list[5], vert[3], v_x[marker]);
      }
      if (f == (-1.0))
      {
        printf("error in qhull_get_pent_volume for cell %ld %ld %ld. ignoring and will set volume to 0.0\n", i, j, k);
        f = 0.0;
      }

      mesh->fv[mesh_index(mesh, i, j, k)] = f;
    }

    if (f_facing < 0)
      mesh->fv[mesh_index(mesh, i, j, k)] = 1 - mesh->fv[mesh_index(mesh, i, j, k)];

    return 1;
  }

  return 0;
}

