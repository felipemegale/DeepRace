{
  float val;
  int lvl;
  struct node *left;
  struct node *right;
} Node;
{
  float val;
  int lvl;
  struct node *left;
  struct node *right;
} *NodePtr;
NodePtr create_tree_par(const int maxlvl, int curlvl, const int remnum, int *remcount)
{
  if (curlvl >= maxlvl)
  {
    return 0;
  }
  else
    if (curlvl == (maxlvl - 1))
  {
    if ((*remcount) >= remnum)
    {
      return 0;
    }

    NodePtr pnode = (NodePtr) malloc(sizeof(Node));
    if (!pnode)
    {
      perror("Failed to malloc memory!\n");
      exit(-1);
    }

    pnode->val = ((float) rand()) / 32767;
    pnode->lvl = curlvl;
    pnode->left = 0;
    pnode->right = 0;
    {
      if ((*remcount) < remnum)
      {
        (*remcount)++;
      }
      else
      {
        curlvl = maxlvl;
      }

    }
    return pnode;
  }
  else
  {
    NodePtr pnode = (NodePtr) malloc(sizeof(Node));
    if (!pnode)
    {
      perror("Failed to malloc memory!\n");
      exit(-1);
    }

    pnode->val = ((float) rand()) / 32767;
    pnode->lvl = curlvl;
    curlvl++;
    if (curlvl <= 5)
    {
      #pragma omp task
      pnode->left = create_tree_par(maxlvl, curlvl, remnum, remcount);
      #pragma omp task
      pnode->right = create_tree_par(maxlvl, curlvl, remnum, remcount);
      #pragma omp taskwait
    }
    else
    {
      pnode->left = create_tree_par(maxlvl, curlvl, remnum, remcount);
      pnode->right = create_tree_par(maxlvl, curlvl, remnum, remcount);
    }

    return pnode;
  }


}

