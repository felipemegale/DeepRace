int NUM_THREADS;
int NUM_BARRIERS;
static void centralized_barrier(int *count, int *sense, int *local_sense)
{
  int i;
  for (i = 0; i < 5000; i++)
    ;

  *local_sense = !(*local_sense);
  {
    *count = (*count) - 1;
  }
  if ((*count) == 0)
  {
    *count = NUM_THREADS;
    *sense = *local_sense;
  }
  else
  {
    while ((*sense) != (*local_sense))
    {
    }

  }


  long long int v1;
  long long int v2;
  double weight;
  struct adj_list_node *v1_next;
  struct adj_list_node *v2_next;
};
long long int *n;
long long int vertices;
long long int n_len;
long long int c_mask;
long long int d_mask;
int c_len;
int n_blen;
int r;
double initial_weight;
long long int initial_number_edges;
struct adj_list_node **adj_list;
int number_threads = 1;
static int parse_graph(char *filename);
static void print_adj_matrix(void);
static double get_rank(long long int v);
static long long int select_codeword(void);
static void remove_complementary(long long int c);
static void print_code(void);
static void usage(void);
static void add_adj_list_entry(struct adj_list_node *new);
static void del_adj_list_entry(long long int vertex);
long long int select_codeword()
{
  long long int best;
  long long int i;
  double best_rank;
  double rank;
  double local_best;
  double local_best_rank;
  best = -1;
  best_rank = -1;
  #pragma omp parallel num_threads(number_threads) private(rank, local_best, local_best_rank, i)
  {
    local_best = -1;
    local_best_rank = -1;
    #pragma omp for schedule(guided)
    for (i = 0; i < vertices; i++)
    {
      rank = get_rank(i);
      if (rank > local_best_rank)
      {
        local_best = i;
        local_best_rank = rank;
      }

    }

    #pragma omp critical
    if (local_best_rank > best_rank)
    {
      best = local_best;
      best_rank = local_best_rank;
    }

  }
  return best;
}

