void going_up()
{
  {
    barrier_entry_count[omp_get_thread_num()]++;
  }
  int no_of_children = 0;
  int i = 0;
  int sp = (omp_get_thread_num() * 4) + 1;
  while (((sp + no_of_children) < numthreads) && (no_of_children < 4))
  {
    no_of_children++;
  }

  if (!no_of_children)
  {
  }
  else
  {
    int val;
    while (1)
    {
      val = 0;
      for (i = sp; i < (sp + no_of_children); i++)
      {
        if ((going_up_tree[i] == 'e') && (barrier_entry_count[i] == barrier_entry_count[omp_get_thread_num()]))
        {
          val = val + 0;
        }
        else
        {
          val = val + 1;
          break;
        }

      }

      if (!val)
        break;

    }

  }

  {
    going_up_tree[omp_get_thread_num()] = 'e';
  }
  return;
}

