static char rcsid[] = "$Id$";
int errors = 0;
int thds;
short prvt;
void func(int t)
{
  int i;
  #pragma omp for schedule(static,1) lastprivate (prvt)
  for (i = 0; i < thds; i++)
  {
    prvt = i;
    barrier(t);
    if (prvt != i)
    {
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(short)))
    {
      errors += 1;
    }

    if (i == 0)
    {
      waittime(1);
    }

    prvt = i;
  }

  if (prvt != (thds - 1))
  {
    errors += 1;
  }

}

