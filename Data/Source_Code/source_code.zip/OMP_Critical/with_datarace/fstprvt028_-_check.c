static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int *buff;
int prvt;
void check(int s)
{
  int i;
  int j;
  int id;
  for (i = 0; i < (100 * thds); i += s)
  {
    id = (i / s) % thds;
    for (j = 0; j < s; j++)
    {
      if ((i + j) < (100 * thds))
      {
        if (buff[i + j] != id)
        {
          errors += 1;
        }

      }

    }

  }

}

