int main()
{
  double a[13][13];
  int n;
  int i;
  int j;
  for (i = 0; i < 13; i++)
    for (j = 0; j < 13; j++)
    a[i][j] = (1.02 * i) + (1.01 * j);


  n = 13;
  double suma = 0.0;
  for (i = 0; i < 13; i++)
  {
    for (j = 0; j < 13; j++)
    {
      suma += a[i][j];
    }

  }

  printf("Suma wyrazów tablicy: %lf\n", suma);
  omp_set_nested(1);
  double suma_parallel = 0.0;
  #pragma omp parallel for ordered shared(a, suma_parallel) private(i, j) schedule(dynamic,2)
  for (i = 0; i < 13; i++)
  {
    int id_w = omp_get_thread_num();
    for (j = 0; j < 13; j++)
    {
      {
        suma_parallel += a[j][i];
      }
      #pragma omp ordered
      {
        printf("(%2d,%2d)-W(%1d,%1d) ", i, j, id_w, omp_get_thread_num());
      }
    }

    printf("\n");
  }

  printf("Suma wyrazów tablicy równolegle: %lf\n", suma_parallel);
}

