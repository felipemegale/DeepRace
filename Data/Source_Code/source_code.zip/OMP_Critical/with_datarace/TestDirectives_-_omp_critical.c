void omp_critical()
{
  int tid;
  #pragma omp parallel
  {
    printf("Test Directives Critical\n");
    {
      tid = omp_get_thread_num();
      printf("tid: %d\n", tid);
    }
  }
}

