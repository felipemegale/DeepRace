int main(int argc, char *argv[])
{
  int x = 0;
  #pragma omp parallel num_threads(2)
  {
    #pragma omp single
    {
      x++;
    }
    print_fuzzy_address();
    #pragma omp critical
    {
      x++;
    }
  }
  return 0;

  double area;
  double pi;
  double x;
  int i;
  int n = 10000;
  area = 0.0;
  #pragma omp parallel for private(x)
  for (i = 0; i < n; i++)
  {
    x = (i + 0.5) / n;
    area += 4.0 / (1.0 + (x * x));
  }

  pi = area / n;
  printf("pi: %lf\n", pi);
}

