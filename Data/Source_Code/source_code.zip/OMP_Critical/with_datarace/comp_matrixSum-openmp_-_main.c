double start_time;
double end_time;
int numWorkers;
int size;
int matrix[20000][20000];
int main(int argc, char *argv[])
{
  int i;
  int j;
  double s_start_time;
  double s_end_time;
  double s_timeElapsed;
  double timeElapsed;
  double speedup;
  printf("#	speedup parallel matrixsum\n");
  printf("#processors\tsize\tspeedup\n");
  for (numWorkers = 2; numWorkers < 5; numWorkers++)
  {
    for (size = 100; size <= 20000; size += size / 4)
    {
      initialize_matrix();
      s_start_time = omp_get_wtime();
      serial_matrixsum();
      s_end_time = omp_get_wtime();
      s_timeElapsed = s_end_time - s_start_time;
      initialize_matrix();
      unsigned long total = 0;
      int min = 32767;
      int max = 0;
      int min_i;
      int min_j;
      int max_i;
      int max_j;
      start_time = omp_get_wtime();
      #pragma omp parallel num_threads(numWorkers)
      {
        int my_min = 32767;
        int my_max = 0;
        int mmin_i;
        int mmin_j;
        int mmax_i;
        int mmax_j;
        #pragma omp for reduction (+:total) private(j)
        for (i = 0; i < size; i++)
        {
          for (j = 0; j < size; j++)
          {
            total += matrix[i][j];
            if (matrix[i][j] > my_max)
            {
              my_max = matrix[i][j];
              mmax_i = i;
              mmax_j = j;
            }

            if (matrix[i][j] < my_min)
            {
              my_min = matrix[i][j];
              mmin_i = i;
              mmin_j = j;
            }

          }

        }

        if (my_min < min)
        {
          {
            min = my_min;
            min_i = mmin_i;
            min_j = mmin_j;
          }
        }

        if (my_max > max)
        {
          {
            max = my_max;
            max_i = mmax_i;
            max_j = mmax_j;
          }
        }

      }
      end_time = omp_get_wtime();
      check_results(total, min, max);
      timeElapsed = end_time - start_time;
      speedup = s_timeElapsed / timeElapsed;
      printf("%d\t\t%d\t%g\n", numWorkers, size, speedup);
    }

  }


  int nombre_thread = 0;
  int id_thread = 0;
  int nombre = 0;
  int diviseur = 0;
  int est_premier = 0;
  int nombre_de_premier = 0;
  #pragma omp parallel for private(diviseur,est_premier,id_thread) schedule(static) reduction(+:nombre_de_premier)
  for (nombre = nombre_min; nombre <= nombre_max; nombre++)
  {
    est_premier = 1;
    diviseur = nombre_min;
    while ((diviseur < nombre) && est_premier)
    {
      if ((nombre % diviseur) == 0)
        est_premier = 0;

      diviseur++;
    }

    id_thread = omp_get_thread_num();
    if (est_premier)
    {
      #pragma omp critical
      {
        printf("Thread N° %d a trouve: %d\n", id_thread, nombre);
      }
      nombre_de_premier++;
    }

  }

}

