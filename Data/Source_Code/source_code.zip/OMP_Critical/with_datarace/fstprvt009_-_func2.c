static char rcsid[] = "$Id$";
int errors = 0;
int thds;
long long prvt;
void func2(int magicno)
{
  long npix = he_nside2npix(nside);
  double thmax_rad = thmax * DTOR;
  double *pos_pix = my_malloc((3 * npix) * (sizeof(double)));
  long ip;
  for (ip = 0; ip < npix; ip++)
  {
    double *v = &pos_pix[3 * ip];
    he_pix2vec_ring(nside, ip, v);
  }

  for (ip = 0; ip < nth; ip++)
  {
    hf_th[ip] = 0;
    hm_th[ip] = 0;
  }

  #pragma omp parallel default(none) shared(ngal,pos,fld,msk,nside,thmin,thmax,nth,do_log) shared(hf_th,hm_th,npix,thmax_rad,pos_pix)
  {
    int i;
    double thmin_rad = thmin * DTOR;
    double cthmax = cos(thmax_rad);
    double *hf_th_thr = my_calloc(nth, sizeof(double));
    double *hm_th_thr = my_calloc(nth, sizeof(double));
    int lenlist0 = (int) ((4 * npix) * (1 - cos(2 * thmax_rad)));
    int *listpix = my_malloc(lenlist0 * (sizeof(int)));
    int logbin = do_log;
    double log_th_max = log10(thmax_rad);
    double i_theta_max = 1. / thmax_rad;
    double n_logint = -1;
    if (do_log)
      n_logint = nth / log10(thmax_rad / thmin_rad);

    #pragma omp for
    for (i = 0; i < ngal; i++)
    {
      int j;
      double pos_g[3];
      int lenlist_half = lenlist0 / 2;
      double cth_g = pos[(3 * i) + 0];
      double phi_g = pos[(3 * i) + 1];
      double wei_g = pos[(3 * i) + 2];
      pos_g[0] = sqrt(1 - (cth_g * cth_g)) * cos(phi_g);
      pos_g[1] = sqrt(1 - (cth_g * cth_g)) * sin(phi_g);
      pos_g[2] = cth_g;
      he_query_disc(nside, cth_g, phi_g, 1.2 * thmax_rad, listpix, &lenlist_half, 1);
      for (j = 0; j < lenlist_half; j++)
      {
        int ipx = listpix[j];
        double *pos_p = &pos_pix[3 * ipx];
        double prod = ((pos_g[0] * pos_p[0]) + (pos_g[1] * pos_p[1])) + (pos_g[2] * pos_p[2]);
        if (prod > cthmax)
        {
          int ith = th2bin(prod, logbin, n_logint, log_th_max, nth, i_theta_max);
          if ((ith < nth) && (ith >= 0))
          {
            hf_th_thr[ith] += wei_g * fld[ipx];
            hm_th_thr[ith] += wei_g * msk[ipx];
          }

        }

      }

    }

    #pragma omp critical
    {
      for (i = 0; i < nth; i++)
      {
        hf_th[i] += hf_th_thr[i];
        hm_th[i] += hm_th_thr[i];
      }

    }
    free(hf_th_thr);
    free(hm_th_thr);
  }
  free(pos_pix);

  static int err;
  int id = omp_get_thread_num();
  if (prvt != magicno)
  {
    errors += 1;
  }

  #pragma omp barrier
  prvt = id;
  err = 0;
  #pragma omp barrier
  if (prvt != id)
  {
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    errors++;
  }

}

