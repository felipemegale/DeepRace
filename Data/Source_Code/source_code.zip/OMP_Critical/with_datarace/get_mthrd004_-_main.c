static char rcsid[] = "$Id$";
int main()
{
  int thds;
  int i;
  int errors = 0;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("omp_get_max_threads return 1.\n");
    printf("please, run this program on multi thread environment.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel sections
  {
    #pragma omp section
    {
      if (omp_get_max_threads() != thds)
      {
        errors += 1;
      }

    }
    #pragma omp section
    {
      if (omp_get_max_threads() != thds)
      {
        errors += 1;
      }

    }
  }
  for (i = 1; i <= thds; i++)
  {
    omp_set_num_threads(i);
    #pragma omp parallel sections
    {
      #pragma omp section
      {
        if (omp_get_max_threads() != i)
        {
          errors += 1;
        }

      }
      #pragma omp section
      {
        if (omp_get_max_threads() != i)
        {
          errors += 1;
        }

      }
    }
  }

  if (errors == 0)
  {
    printf("omp_get_max_threads 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("omp_get_max_threads 004 : FAILED\n");
    return 1;
  }


  int i;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel for schedule(static,1) lastprivate (prvt)
  for (i = 0; i < thds; i++)
  {
    prvt = i;
    barrier(thds);
    if (prvt != i)
    {
      #pragma omp critical
      errors += 1;
    }

    if (i == 0)
    {
      waittime(1);
    }

    prvt = i;
  }

  if (prvt != (thds - 1))
  {
    #pragma omp critical
    errors += 1;
  }

  if (errors == 0)
  {
    printf("lastprivate 019 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("lastprivate 019 : FAILED\n");
    return 1;
  }

}

