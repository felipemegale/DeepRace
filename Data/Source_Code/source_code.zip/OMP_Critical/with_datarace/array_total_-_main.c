int main()
{
  double *a = (double *) malloc((sizeof(double)) * 20000000);
  int i;
  int j;
  double start_time;
  double run_time;
  for (i = 0; i < 20000000; i++)
    a[i] = 1;

  printf("total secs nthreads\n");
  for (j = 1; j <= 16; j++)
  {
    omp_set_num_threads(j);
    start_time = omp_get_wtime();
    double total = 0.0;
    #pragma omp parallel
    {
      double my_sum = 0.0;
      #pragma omp for
      for (i = 0; i < 20000000; i++)
      {
        my_sum += a[i];
      }

      total += my_sum;
    }
    run_time = omp_get_wtime() - start_time;
    printf("%f %f %d\n", total, run_time, j);
  }

}

