int main()
{
  int a[9800][9800];
  int b[9800][9800];
  int c[9800][9800];
  int chunk = 10;
  int i;
  int j;
  int k;
  int tmp;
  int tid;
  int nthreads;
  double start;
  double end;
  start = MPI_Wtime();
  omp_set_dynamic(0);
  omp_set_num_threads(2);
  #pragma omp parallel shared(a,b,c,chunk) private(i,j,k)
  {
    tid = omp_get_thread_num();
    if (tid == 0)
      nthreads = omp_get_num_threads();

    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 9800; i++)
    {
      for (j = 0; j < 9800; j++)
      {
        a[i][j] = i + j;
        b[i][j] = i * j;
        c[i][j] = 0;
      }

    }

    #pragma omp for schedule (static, chunk)
    for (i = 0; i < 9800; i++)
    {
      for (j = 0; j < 9800; j++)
      {
        tmp = 0;
        for (k = 0; k < 9800; k++)
        {
          c[i][j] += a[i][k] * b[j][k];
        }

      }

    }

  }
  end = MPI_Wtime();
  printf("%f\n", end - start);
  return 0;

  int Ah;
  int Aw;
  int Bh;
  int Bw;
  int x;
  int cases = 0;
  while (scanf("%d %d %d %d", &Ah, &Aw, &Bh, &Bw) == 4)
  {
    for (int i = 0; i < Ah; i++)
      for (int j = 0; j < Aw; j++)
      scanf("%d", &x), A[i][j] = x;


    for (int i = 0; i < Bh; i++)
      for (int j = 0; j < Bw; j++)
      scanf("%d", &x), B[i][j] = x;


    int Ch = Ah - Bh;
    int Cw = Aw - Bw;
    int bx = -1;
    int by = -1;
    long long diff = LONG_MAX;
    int chunk = 8;
    #pragma omp parallel for schedule(dynamic, chunk) shared(A, B)
    for (int i = 0; i <= Ch; i++)
    {
      for (int j = 0; j <= Cw; j++)
      {
        long long d = 0;
        for (int p = 0; p < Bh; p++)
        {
          for (int q = 0; q < Bw; q++)
          {
            d += ((long long) (B[p][q] - A[i + p][j + q])) * (B[p][q] - A[i + p][j + q]);
          }

        }

        if (d < diff)
        {
          #pragma omp critical
          if (d < diff)
            diff = d, bx = i, by = j;

        }

      }

    }

    printf("%d %d\n", bx + 1, by + 1);
  }

  return 0;
}

