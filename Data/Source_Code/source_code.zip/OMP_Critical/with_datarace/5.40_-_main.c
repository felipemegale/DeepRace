int amountOfPoints = 0;
int totalPoints = 0;
int main()
{
  printf("Monte Carlo method for calculating PI(openmp with critical section)\n");
  srand(time(0));
  do
  {
    printf("Amount of random Points : \n");
    scanf("%d", &amountOfPoints);
  }
  while (amountOfPoints <= 0);
  #pragma omp parallel
  {
    int i;
    #pragma omp for
    for (i = 0; i < amountOfPoints; i++)
    {
      double X = ((double) rand()) / 32767;
      double Y = ((double) rand()) / 32767;
      if (((X * X) + (Y * Y)) <= 1)
      {
        totalPoints++;
      }

    }

  }
  double points = 4.0 * totalPoints;
  double pi = points / amountOfPoints;
  printf("The approximating value of pi for the amount of points (%d) is: %f\n\n", amountOfPoints, pi);
  return 0;
}

