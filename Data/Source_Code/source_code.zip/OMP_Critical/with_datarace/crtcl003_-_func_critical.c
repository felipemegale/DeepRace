static char rcsid[] = "$Id$";
int thds;
int errors = 0;
int data;
void func_critical()
{
  {
    int i;
    i = read_data();
    waittime(1);
    write_data(i + 1);
  }
}

