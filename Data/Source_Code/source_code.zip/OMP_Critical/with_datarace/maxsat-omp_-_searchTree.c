void searchTree(int node, int n_clauses, int mat[][20], int *status, int imp_clauses, int *maxsat, int *maxsat_count, int n_vars, int *best, int *current, int *n_threads)
{
  (*n_threads)--;
  int i;
  int j;
  for (i = 0; i < n_clauses; i++)
  {
    if (status[i] != 0)
    {
      continue;
    }

    for (j = 0; mat[i][j] != 0; j++)
    {
      if (mat[i][j] == node)
      {
        status[i] = 1;
      }

    }

    if ((maxVar(mat[i]) <= abs(node)) && (status[i] == 0))
    {
      status[i] = -1;
      imp_clauses++;
    }

  }

  int a;
  a = *maxsat;
  if ((n_clauses - imp_clauses) < a)
  {
    return;
  }

  int mscount = 0;
  for (i = 0; i < n_clauses; i++)
  {
    if (status[i] == 0)
    {
      mscount = -1;
      break;
    }

    if (status[i] == 1)
    {
      mscount++;
    }

  }

  a = *maxsat;
  if (mscount > a)
  {
    *maxsat = mscount;
    for (i = 0; i < n_vars; i++)
    {
      best[i] = current[i];
    }

    *maxsat_count = (int) pow(2.0, n_vars - abs(node));
    return;
  }

  a = *maxsat;
  if (mscount == a)
  {
    *maxsat_count += (int) pow(2.0, n_vars - abs(node));
    return;
  }

  a = *maxsat;
  if ((mscount < a) && (mscount >= 0))
  {
    return;
  }

  int status_c[n_clauses];
  for (i = 0; i < n_clauses; i++)
  {
    status_c[i] = status[i];
  }

  int current2[n_vars];
  for (i = 0; i < n_vars; i++)
  {
    current2[i] = current[i];
  }

  current[abs(node)] = (-abs(node)) - 1;
  current2[abs(node)] = abs(node) + 1;
  (*n_threads)++;
  #pragma omp parallel if((*n_threads)>1) num_threads(2)
  {
    #pragma omp single nowait
    searchTree((-abs(node)) - 1, n_clauses, mat, status, imp_clauses, &(*maxsat), &(*maxsat_count), n_vars, best, current, n_threads);
    #pragma omp single nowait
    searchTree(abs(node) + 1, n_clauses, mat, status_c, imp_clauses, &(*maxsat), &(*maxsat_count), n_vars, best, current2, n_threads);
  }
}

