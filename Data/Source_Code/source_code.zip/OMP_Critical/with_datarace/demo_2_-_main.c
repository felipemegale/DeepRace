int main(int argc, char *argv[])
{
  int num = 0;
  int thread_num;
  int nthreads = 16;
  printf("Testing OpenMP, you should see each thread print...\n");
  #pragma omp parallel
  {
    {
    }
  }
  return 0;

  int id = omp_get_thread_num();
  i = id;
  #pragma omp barrier
  if (i != id)
  {
    #pragma omp critical
    errors += 1;
  }

}

